package com.draft.kshitijDemo1.util;

public enum ErrorResponse {

	RECORD_NOT_FOUND(1000, "Record Not Found"), UNKNOWN_ERROR_OCCURED(1001, "Unknown Error Occured"),
	VALIDATION_ERROR_OCCURED(1002, "Validation Error Kindly Retry Once!"),
	CREATE_ERROR_OCCURRED(1003, "Creation failed"), UPDATE_ERROR_OCCURRED(1003, "Update failed");

	private final int code;

	private final String message;

	private ErrorResponse(int code, String description) {

		this.code = code;

		this.message = description;

	}

	public String getMessage() {

		return message;

	}

	public int getCode() {

		return code;

	}

	public String getMessage(String params) {

		return message + params;

	}

	@Override

	public String toString() {

		return code + ": " + message;

	}

}