package com.draft.kshitijDemo1.model;

import java.math.BigDecimal;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "PRODUCT_TABLE")
public class Product {
	@Id
	@Column(name = "id", updatable = false)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long productId;

	@Column(name = "Item_Name")
	private String name;

	@Column(name = "Price")
	private BigDecimal price;

	@Column(name = "Category")
	private String category;
	// getters and setters
}