package com.draft.kshitijDemo1.requestDto;

import lombok.Data;

@Data

public class OrderProductRequestDto {

	private Long id;
	private Long orderId;
	private Long productId;
	private String properties;
	private float discount;
	private float amount;
	private Integer quantity;
	private String unit;
	private float rate;
	private Long status;
}