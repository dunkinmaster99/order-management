package com.draft.kshitijDemo1.AuthDao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.draft.kshitijDemo1.userModel.User;



@Repository
public interface UserDao extends CrudRepository<User, String> {
@Query("SELECT DISTINCT a.category FROM User a WHERE a.category IS NOT NULL")
List<String> getAllCategories();
}