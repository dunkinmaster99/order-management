package com.draft.kshitijDemo1.responseDto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class OrderResponseDto {
	private Long id;
	private String orderId;
	private String orderNumber;
	private String narration;
	private String priority;
	private BigDecimal discount;
	private BigDecimal finalAmount;
	private String status;
	private List<Map<Integer, String>> listOfStatus;
	private String gst;
	private CustomerDto customer;
	private char isDeliveryAddressSame;
	private String d_AddressLine1;
	private String d_AddressLine2;
	private String d_AddressLine3;
	private String d_AddressLine4;
	private String d_State;
	private String d_Country;
	private Integer d_Pincode;
	private char isPushedInTally;
	private Date orderDate;
	// private List<CommunicationLogDto> communicationLogs;
	private List<OrderProductResponseDto> orderProducts;

	// Constructors, getters, and setters

}