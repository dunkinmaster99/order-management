package com.draft.kshitijDemo1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.draft.kshitijDemo1.requestDto.CustomerRequestDto;
import com.draft.kshitijDemo1.service.CustomException;
import com.draft.kshitijDemo1.service.CustomerService;
import com.draft.kshitijDemo1.util.ApiResponse;
import com.draft.kshitijDemo1.util.ErrorResponse;
import com.draft.kshitijDemo1.util.MsgConstant;
import com.draft.kshitijDemo1.util.ResponseBodyUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:4200/")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@PostMapping("/create")
	public ResponseEntity<String> createCustomer(@RequestBody CustomerRequestDto dto) throws CustomException {

		try {
			customerService.createOrUpdateCustomer(dto);
			return ResponseEntity.ok().body(ResponseBodyUtil.createResponseBody(HttpStatus.CREATED.value(),
					MsgConstant.RECORDS_CREATED_SUCCESS));
		} catch (Exception e) {
			log.error("Error occured in Class : " + this.getClass().getSimpleName() + " and Method : " + new Object() {
			}.getClass().getEnclosingMethod().getName(), e);
			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
		}

	}

	@PutMapping("/update")
	public ResponseEntity<String> updateCustomer(@RequestBody CustomerRequestDto dto) throws CustomException {

		try {
			customerService.createOrUpdateCustomer(dto);
			return ResponseEntity.ok().body(ResponseBodyUtil.createResponseBody(HttpStatus.CREATED.value(),
					MsgConstant.RECORDS_CREATED_SUCCESS));
		} catch (Exception e) {
			log.error("Error occured in Class : " + this.getClass().getSimpleName() + " and Method : " + new Object() {
			}.getClass().getEnclosingMethod().getName(), e);
			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
		}

	}

	@GetMapping("/getAllCustomers")
	public ResponseEntity<ApiResponse> listAllCustomers() throws CustomException {
		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					customerService.listAllCustomers()));

		} catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@PostMapping("/changeTallyPushedStatus")
	public ResponseEntity<String> changeTallyPushedStatus(@RequestParam Long id) throws CustomException {
		try {

			customerService.changeTallyPushedStatus(id);

			return ResponseEntity.ok().body(ResponseBodyUtil.createResponseBody(HttpStatus.CREATED.value(),
					MsgConstant.RECORDS_CREATED_SUCCESS));
		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}
	}

	@GetMapping("/getAllCustomersOnly")

	public ResponseEntity<ApiResponse> listAllCustomerListOnly() throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					customerService.listCustomerListOnly()));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/getByCustomerId")

	public ResponseEntity<ApiResponse> getByCustomerId(@RequestParam Long id) throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					customerService.getByCustomerId(id)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/getById")

	public ResponseEntity<ApiResponse> getById(@RequestParam Long id) throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					customerService.getById(id)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/ListNewCustomerListNotinTally")

	public ResponseEntity<ApiResponse> ListNewCustomerListNotinTally() throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					customerService.listNewCustomerListNotinTally()));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

}