package com.draft.kshitijDemo1.util;

import org.json.JSONObject;

public class ResponseBodyUtil {

	public static String createResponseBody(int status, String message) {

		JSONObject json = new JSONObject();

		json.put("status", status);

		json.put("message", message);

		return json.toString();

	}

	public static String createErrorResponseBody(int status, String errorType, String message) {

		JSONObject json = new JSONObject();

		json.put("status", status);

		json.put("errorType", errorType);

		json.put("message", message);

		return json.toString();

	}

}