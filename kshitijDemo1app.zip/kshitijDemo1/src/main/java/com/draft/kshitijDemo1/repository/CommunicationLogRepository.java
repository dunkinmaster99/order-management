package com.draft.kshitijDemo1.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.draft.kshitijDemo1.model.CommunicationLog;

public interface CommunicationLogRepository extends JpaRepository<CommunicationLog, Long> {

	@Query(value = "Select * from communication_logs where order_id=?1", nativeQuery = true)
	List<CommunicationLog> findCommunicationLogsByOrderId(Long orderId);

	List<CommunicationLog> findByCreatedDateBetween(Date startDate, Date endDate);

	List<CommunicationLog> findByCreatedDate(Date date);
}
