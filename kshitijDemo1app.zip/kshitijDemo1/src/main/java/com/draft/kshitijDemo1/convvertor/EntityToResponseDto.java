package com.draft.kshitijDemo1.convvertor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.draft.kshitijDemo1.model.CommunicationLog;
import com.draft.kshitijDemo1.model.Customer;
import com.draft.kshitijDemo1.model.Order;
import com.draft.kshitijDemo1.model.OrderProduct;
import com.draft.kshitijDemo1.repository.CommunicationLogRepository;
import com.draft.kshitijDemo1.repository.OrderProductRepository;
import com.draft.kshitijDemo1.repository.OrderRepository;
import com.draft.kshitijDemo1.responseDto.CommunicationLogDto;
import com.draft.kshitijDemo1.responseDto.CustomerDto;
import com.draft.kshitijDemo1.responseDto.CustomerResponseDto;
import com.draft.kshitijDemo1.responseDto.OrderProductResponseDto;
import com.draft.kshitijDemo1.responseDto.OrderResponseDto;
import com.draft.kshitijDemo1.responseDto.OrderResponseWithLogsDto;

@Component
public class EntityToResponseDto {
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private OrderProductRepository orderProductRepository;
	@Autowired
	private CommunicationLogRepository communicationLogRepository;

	public CommunicationLogDto EntityToLogDto(CommunicationLog entity) {
		CommunicationLogDto dto = new CommunicationLogDto();
		BeanUtils.copyProperties(entity, dto);
		if (entity.getStatus() != null) {
			dto.setStatusId(entity.getStatus().getStatusId());
		}
		if (entity.getOrder() != null) {
			dto.setOrderId(entity.getOrder().getId());
		}
		return dto;
	}

	public CustomerDto EntityToCustomerDto(Customer entity) {
		CustomerDto dto = new CustomerDto();
		BeanUtils.copyProperties(entity, dto);
		return dto;
	}

	public CustomerResponseDto EntitytoCustomerWithProductsDto(Customer entity) {
		CustomerResponseDto dto = new CustomerResponseDto();
		BeanUtils.copyProperties(entity, dto);
		List<OrderResponseDto> orderList = new ArrayList<>();
		for (Order orderEntity : orderRepository.findOrdersByCustomerId(entity.getId())) {
			OrderResponseDto orderDto = EntityToOrderDto(orderEntity);
			orderList.add(orderDto);
		}
		return dto;
	}

	public OrderResponseDto EntityToOrderDto(Order entity) {
		OrderResponseDto dto = new OrderResponseDto();
		List<Map<Integer, String>> orderProductStatuses = new ArrayList<>();
		BeanUtils.copyProperties(entity, dto);
		if (entity.getStatus() != null) {
			dto.setStatus(entity.getStatus().getValue());
		}
		if (entity.getCustomer() != null) {
			dto.setCustomer(EntityToCustomerDto(entity.getCustomer()));
		}
		List<OrderProductResponseDto> orderProductsList = new ArrayList<OrderProductResponseDto>();
		for (OrderProduct orderProduct : orderProductRepository.findOrderProductsByOrderId(entity.getId())) {
			Map<Integer, String> orderProductStatus = new HashMap<>();
			orderProductStatus.put(orderProduct.getId().intValue(), orderProduct.getStatus().getValue());
			orderProductStatuses.add(orderProductStatus);
			System.out.println(orderProduct);
			OrderProductResponseDto orderProductDto = EntityToOrderProductDto(orderProduct);
			System.out.println(orderProductDto);
			orderProductsList.add(orderProductDto);
		}
		dto.setListOfStatus(orderProductStatuses);
		dto.setOrderProducts(orderProductsList);
		return dto;
	}

	public OrderResponseWithLogsDto EntityToOrderWithLogs(Order entity) {
		OrderResponseWithLogsDto dto = new OrderResponseWithLogsDto();
		BeanUtils.copyProperties(entity, dto);
		if (entity.getStatus() != null) {
			dto.setStatus(entity.getStatus().getValue());
		}
		if (entity.getCustomer() != null) {
			dto.setCustomerName(entity.getCustomer().getName());
		}
		List<OrderProductResponseDto> orderProductsList = new ArrayList<OrderProductResponseDto>();
		for (OrderProduct orderProduct : orderProductRepository.findOrderProductsByOrderId(entity.getId())) {
			OrderProductResponseDto orderProductDto = EntityToOrderProductDto(orderProduct);
			orderProductsList.add(orderProductDto);
		}
		List<CommunicationLogDto> logList = new ArrayList<CommunicationLogDto>();
		for (CommunicationLog logEntity : communicationLogRepository.findCommunicationLogsByOrderId(entity.getId())) {
			CommunicationLogDto logDto = EntityToLogDto(logEntity);
			logList.add(logDto);
		}
		return dto;
	}

	public OrderProductResponseDto EntityToOrderProductDto(OrderProduct entity) {
		OrderProductResponseDto dto = new OrderProductResponseDto();
		BeanUtils.copyProperties(entity, dto);
		if (entity.getProduct() != null) {
			dto.setProductName(entity.getProduct().getName());
			dto.setCategory(entity.getProduct().getCategory());
		}
		if (entity.getOrder() != null) {
			dto.setOrderId(entity.getOrder().getId());
		}
		if (entity.getStatus() != null) {
			dto.setStatus(entity.getStatus().getValue());
		}
		return dto;
	}

}
