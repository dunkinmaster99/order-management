package com.draft.kshitijDemo1.tallyModel;

public class DutyHeadDetail {

}
