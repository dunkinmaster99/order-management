package com.draft.kshitijDemo1.AuthDao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.draft.kshitijDemo1.userModel.Role;



@Repository
public interface RoleDao extends CrudRepository<Role, String> {

}