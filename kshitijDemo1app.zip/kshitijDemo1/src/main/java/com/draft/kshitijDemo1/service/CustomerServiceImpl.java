package com.draft.kshitijDemo1.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.draft.kshitijDemo1.convvertor.DtoToEntityConvertor;
import com.draft.kshitijDemo1.convvertor.EntityToResponseDto;
import com.draft.kshitijDemo1.model.Customer;
import com.draft.kshitijDemo1.repository.CustomerRepository;
import com.draft.kshitijDemo1.requestDto.CustomerRequestDto;
import com.draft.kshitijDemo1.responseDto.CustomerDto;
import com.draft.kshitijDemo1.responseDto.CustomerResponseDto;

@Service("CustomerService")
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private DtoToEntityConvertor dtoToEntityConvertor;
	@Autowired
	private EntityToResponseDto entityToResponseDto;

	@Override
	public Optional<CustomerResponseDto> getByCustomerId(Long id) {
// TODO Auto-generated method stub
		Optional<Customer> entity = customerRepository.findById(id);
		if (entity.isPresent()) {
			CustomerResponseDto dto = entityToResponseDto.EntitytoCustomerWithProductsDto(entity.get());
			return Optional.of(dto);
		}
		return Optional.empty();
	}

	@Override
	public Optional<Customer> getById(Long id) {
// TODO Auto-generated method stub
		return customerRepository.findById(id);
	}

	@Override
	public List<CustomerResponseDto> listAllCustomers() {
// TODO Auto-generated method stub
		List<Customer> entities = customerRepository.findAll();
		List<CustomerResponseDto> dtos = new ArrayList<>();

		for (Customer entity : entities) {
			CustomerResponseDto dto = entityToResponseDto.EntitytoCustomerWithProductsDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

	@Override
	public List<CustomerDto> listCustomerListOnly() {
// TODO Auto-generated method stub
		List<Customer> entities = customerRepository.findAll();
		List<CustomerDto> dtos = new ArrayList<>();

		for (Customer entity : entities) {
			CustomerDto dto = entityToResponseDto.EntityToCustomerDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

	@Override
	public void createOrUpdateCustomer(CustomerRequestDto dto) {
		Customer entity = dtoToEntityConvertor.toCustomerEntity(dto);
		entity.setIsPushedInTally('0');
		customerRepository.save(entity);
	}

	@Override
	public void changeTallyPushedStatus(Long id) throws Exception {
		Optional<Customer> entity = customerRepository.findById(id);
		if (entity.isPresent()) {
			entity.get().setIsPushedInTally('1');
			customerRepository.save(entity.get());
		} else {
			throw new Exception("customer not found");
		}
	}

	@Override
	public List<CustomerDto> listNewCustomerListNotinTally() {
// TODO Auto-generated method stub
		List<Customer> entities = customerRepository.findCustomersWithTallyStatusZero();
		List<CustomerDto> dtos = new ArrayList<>();

		for (Customer entity : entities) {
			CustomerDto dto = entityToResponseDto.EntityToCustomerDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

}