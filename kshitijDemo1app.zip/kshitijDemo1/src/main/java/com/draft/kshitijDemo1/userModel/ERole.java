package com.draft.kshitijDemo1.userModel;

public enum ERole {

	ROLE_ADMIN,

	ROLE_SALES,

	ROLE_MANUFACTURER

}