package com.draft.kshitijDemo1.tallyService;

import java.io.File;

import java.io.StringWriter;

import java.text.SimpleDateFormat;

import java.util.List;

import java.util.UUID;

import java.io.ByteArrayInputStream;

import java.io.File;

import java.io.StringWriter;

import java.util.ArrayList;

import java.util.Date;

import java.util.List;

import java.util.UUID;

import org.apache.tomcat.util.http.fileupload.IOUtils;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.core.io.ByteArrayResource;

import org.springframework.core.io.Resource;

import org.springframework.http.HttpHeaders;

import org.springframework.http.HttpStatus;

import org.springframework.http.MediaType;

import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Service;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;

import jakarta.servlet.http.HttpServletResponse;

import javax.xml.bind.JAXBContext;

import javax.xml.bind.JAXBException;

import javax.xml.bind.Marshaller;

import javax.xml.parsers.DocumentBuilder;

import javax.xml.parsers.DocumentBuilderFactory;

import javax.xml.transform.OutputKeys;

import javax.xml.transform.Transformer;

import javax.xml.transform.TransformerFactory;

import javax.xml.transform.dom.DOMSource;

import javax.xml.transform.stream.StreamResult;

import javax.xml.transform.OutputKeys;

import org.w3c.dom.Document;

import org.w3c.dom.Element;

import org.w3c.dom.Node;

import org.w3c.dom.NodeList;

import com.draft.kshitijDemo1.model.Order;

import com.draft.kshitijDemo1.responseDto.OrderProductResponseDto;

import com.draft.kshitijDemo1.responseDto.OrderResponseDto;

import com.draft.kshitijDemo1.service.OrderService;

import com.draft.kshitijDemo1.service.OrderServiceImpl;

import com.draft.kshitijDemo1.tallyModel.AccountingAllocation;

import com.draft.kshitijDemo1.tallyModel.AllInventoryList;

import com.draft.kshitijDemo1.tallyModel.BatchAllocation;

import com.draft.kshitijDemo1.tallyModel.DutyHeadDetail;

import com.draft.kshitijDemo1.tallyModel.ExpenseAllocationList;

import com.draft.kshitijDemo1.tallyModel.LedgerEntryLast;

import com.draft.kshitijDemo1.tallyModel.VoucherRequest;

@Service("SingleVoucherService")

public class SingleVoucherServiceImpl {

	@Autowired

	private OrderService orderService;

	public String VoucherFill(List<VoucherRequest> voucherRequests) throws Exception {

		File inputFile = new File("src/main/resources/try.xml");

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

		Document doc = dBuilder.parse(inputFile);

		doc.getDocumentElement().normalize();

		// Get the root element of the document

		// Element rootElement = doc.getDocumentElement();

		Element rootElement = (Element) doc.getElementsByTagName("REQUESTDATA").item(0);

		int a_try = 10;

		// Loop through the voucher requests and append a new TALLYMESSAGE for each of
		// them

		for (VoucherRequest voucherRequest : voucherRequests) {

			// Create a new TALLYMESSAGE element

			a_try++;

			Element tallyMessageElement = doc.createElement("TALLYMESSAGE");

			tallyMessageElement.setAttribute("xmlns:UDF", "TallyUDF");

			// Create a new VOUCHER element and add it to the TALLYMESSAGE

			Element voucherElement = doc.createElement("VOUCHER");

			voucherElement.setAttribute("REMOTEID", "7a49bb20-cb1e-48cc-be8e-4257740eae2a-00055d" + a_try);

			voucherElement.setAttribute("VCHKEY", "7a49bb20-cb1e-48cc-be8e-4257740eae2a-0000affd:000000" + a_try);

			voucherElement.setAttribute("VCHKEY", UUID.randomUUID().toString());

			voucherElement.setAttribute("VCHTYPE", "Sales Order");

			voucherElement.setAttribute("ACTION", "Create");

			voucherElement.setAttribute("OBJVIEW", "Invoice Voucher View");

			tallyMessageElement.appendChild(voucherElement);

			// Add the addresses to the voucher

			List<String> addresses = voucherRequest.getAddress();

			Element addressListElement = doc.createElement("ADDRESS.LIST");

			addressListElement.setAttribute("TYPE", "String");

			for (String address : addresses) {

				Element addressElement = doc.createElement("ADDRESS");

				addressElement.setTextContent(address);

				addressListElement.appendChild(addressElement);

			}

			voucherElement.appendChild(addressListElement);

			// Add the basic buyer addresses to the voucher

			List<String> basicBuyerAddresses = voucherRequest.getBasicBuyerAddress();

			Element basicBuyerAddressListElement = doc.createElement("BASICBUYERADDRESS.LIST");

			basicBuyerAddressListElement.setAttribute("TYPE", "String");

			for (String basicBuyerAddress : basicBuyerAddresses) {

				Element basicBuyerAddressElement = doc.createElement("BASICBUYERADDRESS");

				basicBuyerAddressElement.setTextContent(basicBuyerAddress);

				basicBuyerAddressListElement.appendChild(basicBuyerAddressElement);

			}

			voucherElement.appendChild(basicBuyerAddressListElement);

			// oldauditentry

			List<String> oldEntry = voucherRequest.getOldAuditEntry();

			Element oldAuditEntryList = doc.createElement("OLDAUDITENTRYIDS.LIST");

			oldAuditEntryList.setAttribute("TYPE", "Number");

			for (String old : oldEntry) {

				Element oldAuditEntry = doc.createElement("OLDAUDITENTRYIDS");

				oldAuditEntry.setTextContent(old);

				oldAuditEntryList.appendChild(oldAuditEntry);

			}

			voucherElement.appendChild(oldAuditEntryList);

			// Set the date and guid of the voucher

			Element dateElement = doc.createElement("DATE");

			dateElement.setTextContent(voucherRequest.getDate());

			voucherElement.appendChild(dateElement);

			Element guidElement = doc.createElement("GUID");

			guidElement.setTextContent("7a49bb20-cb1e-48cc-be8e-4257740eae2a-00055d" + a_try);

			voucherElement.appendChild(guidElement);

			Element gst = doc.createElement("GSTREGISTRATIONTYPE");

			gst.setTextContent(voucherRequest.getGSTREGISTRATIONTYPE());

			voucherElement.appendChild(gst);

			// Create a new CSTFORMISSUETYPE element and add it to the voucher

			Element cstformissuetypeElement = doc.createElement("VATDEALERTYPE");

			cstformissuetypeElement.setTextContent(voucherRequest.getVatDealerType());

			voucherElement.appendChild(cstformissuetypeElement);

			// Create a new STATENAME element and add it to the voucher

			Element stateNameElement = doc.createElement("STATENAME");

			stateNameElement.setTextContent(voucherRequest.getStateName());

			voucherElement.appendChild(stateNameElement);

			// Create a new PRICELEVEL element and add it to the voucher

			Element priceLevelElement = doc.createElement("PRICELEVEL");

			priceLevelElement.setTextContent(voucherRequest.getPriceLevel());

			voucherElement.appendChild(priceLevelElement);

			// Create a new VOUCHERTYPENAME element and add it to the voucher

			Element voucherTypeNameElement = doc.createElement("VOUCHERTYPENAME");

			voucherTypeNameElement.setTextContent(voucherRequest.getVoucherTypeName());

			voucherElement.appendChild(voucherTypeNameElement);

			// Create a new NARRATION element and add it to the voucher

			Element narrationElement = doc.createElement("NARRATION");

			narrationElement.setTextContent(voucherRequest.getNarration());

			voucherElement.appendChild(narrationElement);

			// Create a new ENTEREDBY element and add it to the voucher

			Element enteredByElement = doc.createElement("ENTEREDBY");

			enteredByElement.setTextContent(voucherRequest.getEnteredBy());

			voucherElement.appendChild(enteredByElement);

			// Create a new OBJUPDATEACTION element and add it to the voucher

			Element objUpdateActionElement = doc.createElement("OBJECTUPDATEACTION");

			objUpdateActionElement.setTextContent(voucherRequest.getObjectUpdateAction());

			voucherElement.appendChild(objUpdateActionElement);

			// Create a new COUNTRYOFRESIDENCE element and add it to the voucher

			Element countryOfResidenceElement = doc.createElement("COUNTRYOFRESIDENCE");

			countryOfResidenceElement.setTextContent(voucherRequest.getCountryOfResidence());

			voucherElement.appendChild(countryOfResidenceElement);

			// Create a new PARTYGSTIN element and add it to the voucher

			Element partyGSTINElement = doc.createElement("PARTYGSTIN");

			partyGSTINElement.setTextContent(voucherRequest.getPartyGSTIN());

			voucherElement.appendChild(partyGSTINElement);

			// Create a new PLACEOFSUPPLY element and add it to the voucher

			Element placeOfSupplyElement = doc.createElement("PLACEOFSUPPLY");

			placeOfSupplyElement.setTextContent(voucherRequest.getPlaceOfSupply());

			voucherElement.appendChild(placeOfSupplyElement);

			// Create a new CLASSNAME element and add it to the voucher

			Element classNameElement = doc.createElement("CLASSNAME");

			classNameElement.setTextContent(voucherRequest.getClassName());

			voucherElement.appendChild(classNameElement);

			// Create a new PARTYNAME element and add it to the voucher

			Element partyNameElement = doc.createElement("PARTYNAME");

			partyNameElement.setTextContent(voucherRequest.getPartyName());

			voucherElement.appendChild(partyNameElement);

			// Create a new PARTYLEDGERNAME element and add it to the voucher

			Element partyLedgerNameElement = doc.createElement("PARTYLEDGERNAME");

			partyLedgerNameElement.setTextContent(voucherRequest.getPartyLedgerName());

			voucherElement.appendChild(partyLedgerNameElement);

			// Create a new REFERENCE element and add it to the voucher

			Element referenceElement = doc.createElement("REFERENCE");

			referenceElement.setTextContent(voucherRequest.getReference());

			voucherElement.appendChild(referenceElement);

			// Create a new PARTMAILINGNAME element and add it to the voucher

			Element partyMailingNameElement = doc.createElement("PARTYMAILINGNAME");

			partyMailingNameElement.setTextContent(voucherRequest.getPartyMailingName());

			voucherElement.appendChild(partyMailingNameElement);

			// Create elements for the remaining fields and append them to the voucher
			// element

			Element partyPincodeElement = doc.createElement("PARTYPINCODE");

			partyPincodeElement.setTextContent(voucherRequest.getPartyPincode());

			voucherElement.appendChild(partyPincodeElement);

			Element consigneeGstinElement = doc.createElement("CONSIGNEEGSTIN");

			consigneeGstinElement.setTextContent(voucherRequest.getConsigneeGstin());

			voucherElement.appendChild(consigneeGstinElement);

			Element consigneeMailingNameElement = doc.createElement("CONSIGNEEMAILINGNAME");

			consigneeMailingNameElement.setTextContent(voucherRequest.getConsigneeMailingName());

			voucherElement.appendChild(consigneeMailingNameElement);

			Element consigneePincodeElement = doc.createElement("CONSIGNEEPINCODE");

			consigneePincodeElement.setTextContent(voucherRequest.getConsigneePincode());

			voucherElement.appendChild(consigneePincodeElement);

			Element consigneeStateNameElement = doc.createElement("CONSIGNEESTATENAME");

			consigneeStateNameElement.setTextContent(voucherRequest.getConsigneeStateName());

			voucherElement.appendChild(consigneeStateNameElement);

			Element voucherNumberElement = doc.createElement("VOUCHERNUMBER");

			voucherNumberElement.setTextContent(voucherRequest.getVoucherNumber());

			voucherElement.appendChild(voucherNumberElement);

			Element basicBasePartyNameElement = doc.createElement("BASICBASEPARTYNAME");

			basicBasePartyNameElement.setTextContent(voucherRequest.getBasicBasePartyName());

			voucherElement.appendChild(basicBasePartyNameElement);

			Element cstFormIssueTypeElement = doc.createElement("CSTFORMISSUETYPE");

			cstFormIssueTypeElement.setTextContent("");

			voucherElement.appendChild(cstFormIssueTypeElement);

			Element cstFormrec = doc.createElement("CSTFORMRECVTYPE");

			cstFormrec.setTextContent("");

			voucherElement.appendChild(cstFormrec);

			// create and append element for 'persistedView'

			Element persistedViewElement = doc.createElement("PERSISTEDVIEW");

			persistedViewElement.setTextContent(voucherRequest.getPersistedView());

			voucherElement.appendChild(persistedViewElement);

			// create and append element for 'typeOfExciseVoucher'

			Element typeOfExciseVoucherElement = doc.createElement("TYPEOFEXCISEVOUCHER");

			typeOfExciseVoucherElement.setTextContent(voucherRequest.getTypeOfExciseVoucher());

			voucherElement.appendChild(typeOfExciseVoucherElement);

			// create and append element for 'basicBuyerName'

			Element basicBuyerNameElement = doc.createElement("BASICBUYERNAME");

			basicBuyerNameElement.setTextContent(voucherRequest.getBasicBuyerName());

			voucherElement.appendChild(basicBuyerNameElement);

			// create and append element for 'basicDueDateOfPymt'

			Element basicDueDateOfPymtElement = doc.createElement("BASICDUEDATEOFPYMT");

			basicDueDateOfPymtElement.setTextContent(voucherRequest.getBasicDueDateOfPymt());

			voucherElement.appendChild(basicDueDateOfPymtElement);

			// create and append element for 'consigneeCountryName'

			Element consigneeCountryNameElement = doc.createElement("CONSIGNEECOUNTRYNAME");

			consigneeCountryNameElement.setTextContent(voucherRequest.getConsigneeCountryName());

			voucherElement.appendChild(consigneeCountryNameElement);

			Element vchGstClass = doc.createElement("VCHGSTCLASS");

			voucherElement.appendChild(vchGstClass);

			Element diffActualQtyElement = doc.createElement("DIFFACTUALQTY");

			diffActualQtyElement.setTextContent(voucherRequest.getDiffActualQty());

			voucherElement.appendChild(diffActualQtyElement);

			Element isMstFromSyncElement = doc.createElement("ISMSTFROMSYNC");

			isMstFromSyncElement.setTextContent(voucherRequest.getIsMstFromSync());

			voucherElement.appendChild(isMstFromSyncElement);

			Element isDeletedElement = doc.createElement("ISDELETED");

			isDeletedElement.setTextContent(voucherRequest.getIsDeleted());

			voucherElement.appendChild(isDeletedElement);

			Element isSecurityOnWhenEnteredElement = doc.createElement("ISSECURITYONWHENENTERED");

			isSecurityOnWhenEnteredElement.setTextContent(voucherRequest.getIsSecurityOnWhenEntered());

			voucherElement.appendChild(isSecurityOnWhenEnteredElement);

			Element asOriginalElement = doc.createElement("ASORIGINAL");

			asOriginalElement.setTextContent(voucherRequest.getAsOriginal());

			voucherElement.appendChild(asOriginalElement);

			Element auditedElement = doc.createElement("AUDITED");

			auditedElement.setTextContent(voucherRequest.getAudited());

			voucherElement.appendChild(auditedElement);

			Element forJobCostingElement = doc.createElement("FORJOBCOSTING");

			forJobCostingElement.setTextContent(voucherRequest.getForJobCosting());

			voucherElement.appendChild(forJobCostingElement);

			Element isOptionalElement = doc.createElement("ISOPTIONAL");

			isOptionalElement.setTextContent(voucherRequest.getIsOptional());

			voucherElement.appendChild(isOptionalElement);

			Element effectiveDateElement = doc.createElement("EFFECTIVEDATE");

			effectiveDateElement.setTextContent(voucherRequest.getEffectiveDate());

			voucherElement.appendChild(effectiveDateElement);

			Element useForExciseElement = doc.createElement("USEFOREXCISE");

			useForExciseElement.setTextContent(voucherRequest.getUseForExcise());

			voucherElement.appendChild(useForExciseElement);

			Element isForJobWorkInElement = doc.createElement("ISFORJOBWORKIN");

			isForJobWorkInElement.setTextContent(voucherRequest.getIsForJobWorkIn());

			voucherElement.appendChild(isForJobWorkInElement);

			Element allowConsumptionElement = doc.createElement("ALLOWCONSUMPTION");

			allowConsumptionElement.setTextContent(voucherRequest.getAllowConsumption());

			voucherElement.appendChild(allowConsumptionElement);

			Element useForInterestElement = doc.createElement("USEFORINTEREST");

			useForInterestElement.setTextContent(voucherRequest.getUseForInterest());

			voucherElement.appendChild(useForInterestElement);

			Element useForGainLossElement = doc.createElement("USEFORGAINLOSS");

			useForGainLossElement.setTextContent(voucherRequest.getUseForGainLoss());

			voucherElement.appendChild(useForGainLossElement);

			Element useForGodownTransferElement = doc.createElement("USEFORGODOWNTRANSFER");

			useForGodownTransferElement.setTextContent(voucherRequest.getUseForGodownTransfer());

			voucherElement.appendChild(useForGodownTransferElement);

			Element useForCompoundElement = doc.createElement("USEFORCOMPOUND");

			useForCompoundElement.setTextContent(voucherRequest.getUseForCompound());

			voucherElement.appendChild(useForCompoundElement);

			Element useForServiceTaxElement = doc.createElement("USEFORSERVICETAX");

			useForServiceTaxElement.setTextContent(voucherRequest.getUseForServiceTax());

			voucherElement.appendChild(useForServiceTaxElement);

			Element isOnHoldElement = doc.createElement("ISONHOLD");

			isOnHoldElement.setTextContent(voucherRequest.getIsOnHold());

			voucherElement.appendChild(isOnHoldElement);

			Element isBoeNotApplicableElement = doc.createElement("ISBOENOTAPPLICABLE");

			isBoeNotApplicableElement.setTextContent(voucherRequest.getIsBoeNotApplicable());

			voucherElement.appendChild(isBoeNotApplicableElement);

			Element isGstSecSevenApplicable = doc.createElement("ISGSTSECSEVENAPPLICABLE");

			isGstSecSevenApplicable.setTextContent(voucherRequest.getIsGstSecSevenApplicable());

			voucherElement.appendChild(isGstSecSevenApplicable);

			Element isExciseVoucherElement = doc.createElement("ISEXCISEVOUCHER");

			isExciseVoucherElement.setTextContent(voucherRequest.getIsExciseVoucher());

			voucherElement.appendChild(isExciseVoucherElement);

			Element exciseTaxOverrideElement = doc.createElement("EXCISETAXOVERRIDE");

			exciseTaxOverrideElement.setTextContent(voucherRequest.getExciseTaxOverride());

			voucherElement.appendChild(exciseTaxOverrideElement);

			Element useForTaxUnitTransferElement = doc.createElement("USEFORTAXUNITTRANSFER");

			useForTaxUnitTransferElement.setTextContent(voucherRequest.getUseForTaxUnitTransfer());

			voucherElement.appendChild(useForTaxUnitTransferElement);

			Element ignorePosValidationElement = doc.createElement("IGNOREPOSVALIDATION");

			ignorePosValidationElement.setTextContent(voucherRequest.getIgnorePosValidation());

			voucherElement.appendChild(ignorePosValidationElement);

			Element exciseOpeningElement = doc.createElement("EXCISEOPENING");

			exciseOpeningElement.setTextContent(voucherRequest.getExciseOpening());

			voucherElement.appendChild(exciseOpeningElement);

			Element useForFinalProductionElement = doc.createElement("USEFORFINALPRODUCTION");

			useForFinalProductionElement.setTextContent(voucherRequest.getUseForFinalProduction());

			voucherElement.appendChild(useForFinalProductionElement);

			Element isTdsOverriddenElement = doc.createElement("ISTDSOVERRIDDEN");

			isTdsOverriddenElement.setTextContent(voucherRequest.getIsTdsOverridden());

			voucherElement.appendChild(isTdsOverriddenElement);

			Element isTcsOverriddenElement = doc.createElement("ISTCSOVERRIDDEN");

			isTcsOverriddenElement.setTextContent(voucherRequest.getIsTcsOverridden());

			voucherElement.appendChild(isTcsOverriddenElement);

			Element isTdsTcsCashVoucherElement = doc.createElement("ISTDSTCSCASHVCH");

			isTdsTcsCashVoucherElement.setTextContent(voucherRequest.getIsTdsTcsCashVoucher());

			voucherElement.appendChild(isTdsTcsCashVoucherElement);

			Element includeAdvPymtVoucherElement = doc.createElement("INCLUDEADVPYMTVCH");

			includeAdvPymtVoucherElement.setTextContent(voucherRequest.getIncludeAdvPymtVoucher());

			voucherElement.appendChild(includeAdvPymtVoucherElement);

			Element isSubWorksContractElement = doc.createElement("ISSUBWORKSCONTRACT");

			isSubWorksContractElement.setTextContent(voucherRequest.getIsSubWorksContract());

			voucherElement.appendChild(isSubWorksContractElement);

			Element isVatOverriddenElement = doc.createElement("ISVATOVERRIDDEN");

			isVatOverriddenElement.setTextContent(voucherRequest.getIsVatOverridden());

			voucherElement.appendChild(isVatOverriddenElement);

			Element ignoreOrigVoucherDateElement = doc.createElement("IGNOREORIGVCHDATE");

			ignoreOrigVoucherDateElement.setTextContent(voucherRequest.getIgnoreOrigVoucherDate());

			voucherElement.appendChild(ignoreOrigVoucherDateElement);

			Element isVatPaidAtCustomsElement = doc.createElement("ISVATPAIDATCUSTOMS");

			isVatPaidAtCustomsElement.setTextContent(voucherRequest.getIsVatPaidAtCustoms());

			voucherElement.appendChild(isVatPaidAtCustomsElement);

			Element isDeclaredToCustomsElement = doc.createElement("ISDECLAREDTOCUSTOMS");

			isDeclaredToCustomsElement.setTextContent(voucherRequest.getIsDeclaredToCustoms());

			voucherElement.appendChild(isDeclaredToCustomsElement);

			Element isServiceTaxOverridden = doc.createElement("ISSERVICETAXOVERRIDDEN");

			isServiceTaxOverridden.setTextContent(voucherRequest.getIsServiceTaxOverridden());

			voucherElement.appendChild(isServiceTaxOverridden);

			Element isIsdVoucher = doc.createElement("ISISDVOUCHER");

			isIsdVoucher.setTextContent(voucherRequest.getIsIsdVoucher());

			voucherElement.appendChild(isIsdVoucher);

			Element isExciseOverriddenElement = doc.createElement("ISEXCISEOVERRIDDEN");

			isExciseOverriddenElement.setTextContent(voucherRequest.getIsExciseOverridden());

			voucherElement.appendChild(isExciseOverriddenElement);

			Element isExciseSupplyVchElement = doc.createElement("ISEXCISESUPPLYVCH");

			isExciseSupplyVchElement.setTextContent(voucherRequest.getIsExciseSupplyVch());

			voucherElement.appendChild(isExciseSupplyVchElement);

			Element isGstOverriddenElement = doc.createElement("ISGSTOVERRIDDEN");

			isGstOverriddenElement.setTextContent(voucherRequest.getIsGstOverridden());

			voucherElement.appendChild(isGstOverriddenElement);

			Element gstNotExportedElement = doc.createElement("GSTNOTEXPORTED");

			gstNotExportedElement.setTextContent(voucherRequest.getGstNotExported());

			voucherElement.appendChild(gstNotExportedElement);

			Element ignoreGstInvalidationElement = doc.createElement("IGNOREGSTINVALIDATION");

			ignoreGstInvalidationElement.setTextContent(voucherRequest.getIgnoreGstInvalidation());

			voucherElement.appendChild(ignoreGstInvalidationElement);

			Element isGstRefundElement = doc.createElement("ISGSTREFUND");

			isGstRefundElement.setTextContent(voucherRequest.getIsGstRefund());

			voucherElement.appendChild(isGstRefundElement);

			Element ovrdNewWayBillApplicabilityElement = doc.createElement("OVRDNEWAYBILLAPPLICABILITY");

			ovrdNewWayBillApplicabilityElement.setTextContent(voucherRequest.getOvrdNewWayBillApplicability());

			voucherElement.appendChild(ovrdNewWayBillApplicabilityElement);

			Element isVatPrincipalAccountElement = doc.createElement("ISVATPRINCIPALACCOUNT");

			isVatPrincipalAccountElement.setTextContent(voucherRequest.getIsVatPrincipalAccount());

			voucherElement.appendChild(isVatPrincipalAccountElement);

			Element ignoreEinvValidationElement = doc.createElement("IGNOREEINVVALIDATION");

			ignoreEinvValidationElement.setTextContent(voucherRequest.getIgnoreEinvValidation());

			voucherElement.appendChild(ignoreEinvValidationElement);

			Element irnJsonExportedElement = doc.createElement("IRNJSONEXPORTED");

			irnJsonExportedElement.setTextContent(voucherRequest.getIrnJsonExported());

			voucherElement.appendChild(irnJsonExportedElement);

			Element irnCancelledElement = doc.createElement("IRNCANCELLED");

			irnCancelledElement.setTextContent(voucherRequest.getIrnCancelled());

			voucherElement.appendChild(irnCancelledElement);

			Element isShippingWithinStateElement = doc.createElement("ISSHIPPINGWITHINSTATE");

			isShippingWithinStateElement.setTextContent(voucherRequest.getIsShippingWithinState());

			voucherElement.appendChild(isShippingWithinStateElement);

			Element isOverseasTouristTransElement = doc.createElement("ISOVERSEASTOURISTTRANS");

			isOverseasTouristTransElement.setTextContent(voucherRequest.getIsOverseasTouristTrans());

			voucherElement.appendChild(isOverseasTouristTransElement);

			Element isDesignatedZonePartyElement = doc.createElement("ISDESIGNATEDZONEPARTY");

			isDesignatedZonePartyElement.setTextContent(voucherRequest.getIsDesignatedZoneParty());

			voucherElement.appendChild(isDesignatedZonePartyElement);

			Element isCancelledElement = doc.createElement("ISCANCELLED");

			isCancelledElement.setTextContent(voucherRequest.getIsCancelled());

			voucherElement.appendChild(isCancelledElement);

			Element hasCashFlowElement = doc.createElement("HASCASHFLOW");

			hasCashFlowElement.setTextContent(voucherRequest.getHasCashFlow());

			voucherElement.appendChild(hasCashFlowElement);

			Element isPostDatedElement = doc.createElement("ISPOSTDATED");

			isPostDatedElement.setTextContent(voucherRequest.getIsPostDated());

			voucherElement.appendChild(isPostDatedElement);

			Element useTrackingNumberElement = doc.createElement("USETRACKINGNUMBER");

			useTrackingNumberElement.setTextContent(voucherRequest.getUseTrackingNumber());

			voucherElement.appendChild(useTrackingNumberElement);

			Element isInvoiceElement = doc.createElement("ISINVOICE");

			isInvoiceElement.setTextContent(voucherRequest.getIsInvoice());

			voucherElement.appendChild(isInvoiceElement);

			Element mfgJournalElement = doc.createElement("MFGJOURNAL");

			mfgJournalElement.setTextContent(voucherRequest.getMfgJournal());

			voucherElement.appendChild(mfgJournalElement);

			Element hasDiscountsElement = doc.createElement("HASDISCOUNTS");

			hasDiscountsElement.setTextContent(voucherRequest.getHasDiscounts());

			voucherElement.appendChild(hasDiscountsElement);

			Element asPaySlipElement = doc.createElement("ASPAYSLIP");

			asPaySlipElement.setTextContent(voucherRequest.getAsPaySlip());

			voucherElement.appendChild(asPaySlipElement);

			Element isCostCentreElement = doc.createElement("ISCOSTCENTRE");

			isCostCentreElement.setTextContent(voucherRequest.getIsCostCentre());

			voucherElement.appendChild(isCostCentreElement);

			Element isStxNonRealizedVchElement = doc.createElement("ISSTXNONREALIZEDVCH");

			isStxNonRealizedVchElement.setTextContent(voucherRequest.getIsStxNonRealizedVch());

			voucherElement.appendChild(isStxNonRealizedVchElement);

			Element isExciseManufacturerOnElement = doc.createElement("ISEXCISEMANUFACTURERON");

			isExciseManufacturerOnElement.setTextContent(voucherRequest.getIsExciseManufacturerOn());

			voucherElement.appendChild(isExciseManufacturerOnElement);

			Element isBlankChequeElement = doc.createElement("ISBLANKCHEQUE");

			isBlankChequeElement.setTextContent(voucherRequest.getIsBlankCheque());

			voucherElement.appendChild(isBlankChequeElement);

			Element isVoidElement = doc.createElement("ISVOID");

			isVoidElement.setTextContent(voucherRequest.getIsVoid());

			voucherElement.appendChild(isVoidElement);

			Element orderLineStatusElement = doc.createElement("ORDERLINESTATUS");

			orderLineStatusElement.setTextContent(voucherRequest.getOrderLineStatus());

			voucherElement.appendChild(orderLineStatusElement);

			Element vatIsAgstCancSalesElement = doc.createElement("VATISAGNSTCANCSALES");

			vatIsAgstCancSalesElement.setTextContent(voucherRequest.getVatIsAgstCancSales());

			voucherElement.appendChild(vatIsAgstCancSalesElement);

			Element vatIsPurcExemptedElement = doc.createElement("VATISPURCEXEMPTED");

			vatIsPurcExemptedElement.setTextContent(voucherRequest.getVatIsPurcExempted());

			voucherElement.appendChild(vatIsPurcExemptedElement);

			Element isVatRestaxInvoiceElement = doc.createElement("ISVATRESTAXINVOICE");

			isVatRestaxInvoiceElement.setTextContent(voucherRequest.getIsVatRestaxInvoice());

			voucherElement.appendChild(isVatRestaxInvoiceElement);

			Element vatIsAssesableCalcVchElement = doc.createElement("VATISASSESABLECALCVCH");

			vatIsAssesableCalcVchElement.setTextContent(voucherRequest.getVatIsAssesableCalcVch());

			voucherElement.appendChild(vatIsAssesableCalcVchElement);

			Element isVatDutyPaidElement = doc.createElement("ISVATDUTYPAID");

			isVatDutyPaidElement.setTextContent(voucherRequest.getIsVatDutyPaid());

			voucherElement.appendChild(isVatDutyPaidElement);

			Element isDeliverySameAsConsigneeElement = doc.createElement("ISDELIVERYSAMEASCONSIGNEE");

			isDeliverySameAsConsigneeElement.setTextContent(voucherRequest.getIsDeliverySameAsConsignee());

			voucherElement.appendChild(isDeliverySameAsConsigneeElement);

			Element isDispatchSameAsConsignorElement = doc.createElement("ISDISPATCHSAMEASCONSIGNOR");

			isDispatchSameAsConsignorElement.setTextContent(voucherRequest.getIsDispatchSameAsConsignor());

			voucherElement.appendChild(isDispatchSameAsConsignorElement);

			Element isDeletedVchRetainedElement = doc.createElement("ISDELETEDVCHRETAINED");

			isDeletedVchRetainedElement.setTextContent(voucherRequest.getIsDeletedVchRetained());

			voucherElement.appendChild(isDeletedVchRetainedElement);

			Element changeVchModeElement = doc.createElement("CHANGEVCHMODE");

			changeVchModeElement.setTextContent(voucherRequest.getChangeVchMode());

			voucherElement.appendChild(changeVchModeElement);

			Element resetIrnQrCodeElement = doc.createElement("RESETIRNQRCODE");

			resetIrnQrCodeElement.setTextContent(voucherRequest.getResetIrnQrCode());

			voucherElement.appendChild(resetIrnQrCodeElement);

			Element alterIdElement = doc.createElement("ALTERID");

			alterIdElement.setTextContent(voucherRequest.getAlterId());

			voucherElement.appendChild(alterIdElement);

			Element masterIdElement = doc.createElement("MASTERID");

			masterIdElement.setTextContent(voucherRequest.getMasterId());

			voucherElement.appendChild(masterIdElement);

			Element voucherKeyElement = doc.createElement("VOUCHERKEY");

			voucherKeyElement.setTextContent(voucherRequest.getVoucherKey());

			voucherElement.appendChild(voucherKeyElement);

			Element updatedDateTimeElement = doc.createElement("UPDATEDDATETIME");

			updatedDateTimeElement.setTextContent(voucherRequest.getUpdatedDateTime());

			voucherElement.appendChild(updatedDateTimeElement);

			Element eWayBillDetailsList = doc.createElement("EWAYBILLDETAILS.LIST");

			eWayBillDetailsList.setTextContent(" ");

			voucherElement.appendChild(eWayBillDetailsList);

			Element excludedTaxationsList = doc.createElement("EXCLUDEDTAXATIONS.LIST");

			excludedTaxationsList.setTextContent(" ");

			voucherElement.appendChild(excludedTaxationsList);

			Element oldAuditEntriesList = doc.createElement("OLDAUDITENTRIES.LIST");

			oldAuditEntriesList.setTextContent(" ");

			voucherElement.appendChild(oldAuditEntriesList);

			Element accountAuditEntriesList = doc.createElement("ACCOUNTAUDITENTRIES.LIST");

			accountAuditEntriesList.setTextContent(" ");

			voucherElement.appendChild(accountAuditEntriesList);

			Element auditEntriesList = doc.createElement("AUDITENTRIES.LIST");

			auditEntriesList.setTextContent(" ");

			voucherElement.appendChild(auditEntriesList);

			Element dutyHeadDetailsList = doc.createElement("DUTYHEADDETAILS.LIST");

			dutyHeadDetailsList.setTextContent(" ");

			voucherElement.appendChild(dutyHeadDetailsList);

			// for stock items

			List<AllInventoryList> allInventoryList = voucherRequest.getAllInventoryList();

			for (int ak = 0; ak < allInventoryList.size(); ak++) {

				Element inventoryList = doc.createElement("ALLINVENTORYENTRIES.LIST");

				Element stockItemname = doc.createElement("STOCKITEMNAME");

				stockItemname.setTextContent(voucherRequest.getAllInventoryList().get(ak).getStockItemName());

				inventoryList.appendChild(stockItemname);

				Element isDeemedPositive = doc.createElement("ISDEEMEDPOSITIVE");

				isDeemedPositive.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsDeemedPositive());

				inventoryList.appendChild(isDeemedPositive);

				Element isLastDeemedPositive = doc.createElement("ISLASTDEEMEDPOSITIVE");

				isLastDeemedPositive
				.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsLastDeemedPositive());

				inventoryList.appendChild(isLastDeemedPositive);

				Element isAutoNegate = doc.createElement("ISAUTONEGATE");

				isAutoNegate.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsAutoNegate());

				inventoryList.appendChild(isAutoNegate);

				Element isCustomsClearance = doc.createElement("ISCUSTOMSCLEARANCE");

				isCustomsClearance.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsCustomsClearance());

				inventoryList.appendChild(isCustomsClearance);

				Element isTrackComponent = doc.createElement("ISTRACKCOMPONENT");

				isTrackComponent.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsTrackComponent());

				inventoryList.appendChild(isTrackComponent);

				Element isTrackProduction = doc.createElement("ISTRACKPRODUCTION");

				isTrackProduction.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsTrackProduction());

				inventoryList.appendChild(isTrackProduction);

				Element isPrimaryItem = doc.createElement("ISPRIMARYITEM");

				isPrimaryItem.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsPrimaryItem());

				inventoryList.appendChild(isPrimaryItem);

				Element isScrap = doc.createElement("ISSCRAP");

				isScrap.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsScrap());

				inventoryList.appendChild(isScrap);

				Element rate = doc.createElement("RATE");

				rate.setTextContent(voucherRequest.getAllInventoryList().get(ak).getRate());

				inventoryList.appendChild(rate);

				Element discount = doc.createElement("DISCOUNT");

				discount.setTextContent(voucherRequest.getAllInventoryList().get(ak).getDiscount());

				inventoryList.appendChild(discount);

				Element amount = doc.createElement("AMOUNT");

				amount.setTextContent(voucherRequest.getAllInventoryList().get(ak).getAmount());

				inventoryList.appendChild(amount);

				Element actualQty = doc.createElement("ACTUALQTY");

				actualQty.setTextContent(voucherRequest.getAllInventoryList().get(ak).getActualQty());

				inventoryList.appendChild(actualQty);

				Element billedQty = doc.createElement("BILLEDQTY");

				billedQty.setTextContent(voucherRequest.getAllInventoryList().get(ak).getBilledQty());

				inventoryList.appendChild(billedQty);

				// for batchAllocation

				Element batchAllocation = doc.createElement("BATCHALLOCATIONS.LIST");

				Element godownName = doc.createElement("GODOWNNAME");

				godownName.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getGodownName());

				batchAllocation.appendChild(godownName);

				Element batchName = doc.createElement("BATCHNAME");

				batchName.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getBatchName());

				batchAllocation.appendChild(batchName);

				Element destinationGodownName = doc.createElement("DESTINATIONGODOWNNAME");

				destinationGodownName.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getDestinationGodownName());

				batchAllocation.appendChild(destinationGodownName);

				Element indentNo = doc.createElement("INDENTNO");

				//                indentNo.setTextContent(voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getIndentNo());

				batchAllocation.appendChild(indentNo);

				Element orderNo = doc.createElement("ORDERNO");

				orderNo.setTextContent(voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getOrderNo());

				batchAllocation.appendChild(orderNo);

				Element trackingNumber = doc.createElement("TRACKINGNUMBER");

				trackingNumber.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getTrackingNumber());

				batchAllocation.appendChild(trackingNumber);

				Element dynamicCstIsCleared = doc.createElement("DYNAMICCSTISCLEARED");

				dynamicCstIsCleared.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getDynamicCstIsCleared());

				batchAllocation.appendChild(dynamicCstIsCleared);

				Element amount1 = doc.createElement("AMOUNT");

				amount1.setTextContent(voucherRequest.getAllInventoryList().get(ak).getAmount());

				batchAllocation.appendChild(amount1);

				Element actualQty1 = doc.createElement("ACTUALQTY");

				actualQty1.setTextContent(voucherRequest.getAllInventoryList().get(ak).getActualQty());

				batchAllocation.appendChild(actualQty1);

				Element billedQty1 = doc.createElement("BILLEDQTY");

				billedQty1.setTextContent(voucherRequest.getAllInventoryList().get(ak).getBilledQty());

				batchAllocation.appendChild(billedQty1);

				Element orderDueDate = doc.createElement("ORDERDUEDATE");

				orderDueDate.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getOrderDueDate());

				orderDueDate.setAttribute("JD", "45039");

				orderDueDate.setAttribute("P",
						voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getOrderDueDate());

				batchAllocation.appendChild(orderDueDate);

				inventoryList.appendChild(batchAllocation);

				Element additional = doc.createElement("ADDITIONALDETAILS.LIST");

				additional.setTextContent(" ");

				batchAllocation.appendChild(additional);

				Element voucherComponent = doc.createElement("VOUCHERCOMPONENTLIST.LIST");

				voucherComponent.setTextContent(" ");

				batchAllocation.appendChild(voucherComponent);

				// pushing batch allocation

				inventoryList.appendChild(batchAllocation);

				// acounting

				Element accountingAllocation = doc.createElement("ACCOUNTINGALLOCATIONS.LIST");

				Element oldAccounting = doc.createElement("OLDAUDITENTRYIDS.LIST");

				oldAccounting.setAttribute("TYPE", "Number");

				Element oldAccountingId = doc.createElement("OLDAUDITENTRYIDS");

				oldAccountingId.setTextContent("-1");

				oldAccounting.appendChild(oldAccountingId);

				accountingAllocation.appendChild(oldAccounting);

				Element ledgerName1 = doc.createElement("LEDGERNAME");

				ledgerName1.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getLedgerName());

				accountingAllocation.appendChild(ledgerName1);

				Element classRate = doc.createElement("CLASSRATE");

				classRate.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getClassRate());

				accountingAllocation.appendChild(classRate);

				Element gstClass = doc.createElement("GSTCLASS");

				gstClass.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getGstClass());

				accountingAllocation.appendChild(gstClass);

				Element isDeemedPositive1 = doc.createElement("ISDEEMEDPOSITIVE");

				isDeemedPositive1.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getIsDeemedPositive());

				accountingAllocation.appendChild(isDeemedPositive1);

				Element ledgerFromItem = doc.createElement("LEDGERFROMITEM");

				ledgerFromItem.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getLedgerFromItem());

				accountingAllocation.appendChild(ledgerFromItem);

				Element removeZeroEntries = doc.createElement("REMOVEZEROENTRIES");

				removeZeroEntries.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getRemoveZeroEntries());

				accountingAllocation.appendChild(removeZeroEntries);

				Element isPartyLedger = doc.createElement("ISPARTYLEDGER");

				isPartyLedger.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getIsPartyLedger());

				accountingAllocation.appendChild(isPartyLedger);

				Element isLastDeemedPositive1 = doc.createElement("ISLASTDEEMEDPOSITIVE");

				isLastDeemedPositive1.setTextContent(voucherRequest.getAllInventoryList().get(ak)
						.getAccountingAllocations().getIsLastDeemedPositive());

				accountingAllocation.appendChild(isLastDeemedPositive1);

				Element isCapVatTaxAltered = doc.createElement("ISCAPVATTAXALTERED");

				isCapVatTaxAltered.setTextContent(voucherRequest.getAllInventoryList().get(ak)
						.getAccountingAllocations().getIsCapVatTaxAltered());

				accountingAllocation.appendChild(isCapVatTaxAltered);

				Element isCapVatNotClaimed = doc.createElement("ISCAPVATNOTCLAIMED");

				isCapVatNotClaimed.setTextContent(voucherRequest.getAllInventoryList().get(ak)
						.getAccountingAllocations().getIsCapVatNotClaimed());

				accountingAllocation.appendChild(isCapVatNotClaimed);

				Element amount11 = doc.createElement("AMOUNT");

				amount11.setTextContent(
						voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getAmount());

				accountingAllocation.appendChild(amount11);

				Element serviceTaxDetailsList = doc.createElement("SERVICETAXDETAILS.LIST");

				serviceTaxDetailsList.setTextContent(" ");

				accountingAllocation.appendChild(serviceTaxDetailsList);

				Element bankAllocationsList = doc.createElement("BANKALLOCATIONS.LIST");

				bankAllocationsList.setTextContent(" ");

				accountingAllocation.appendChild(bankAllocationsList);

				Element billAllocationsList = doc.createElement("BILLALLOCATIONS.LIST");

				billAllocationsList.setTextContent(" ");

				accountingAllocation.appendChild(billAllocationsList);

				Element interestCollectionList = doc.createElement("INTERESTCOLLECTION.LIST");

				interestCollectionList.setTextContent(" ");

				accountingAllocation.appendChild(interestCollectionList);

				Element oldAuditEntriesList1 = doc.createElement("OLDAUDITENTRIES.LIST");

				oldAuditEntriesList1.setTextContent(" ");

				accountingAllocation.appendChild(oldAuditEntriesList1);

				Element accountAuditEntriesList1 = doc.createElement("ACCOUNTAUDITENTRIES.LIST");

				accountAuditEntriesList1.setTextContent(" ");

				accountingAllocation.appendChild(accountAuditEntriesList1);

				Element auditEntriesList1 = doc.createElement("AUDITENTRIES.LIST");

				auditEntriesList1.setTextContent(" ");

				accountingAllocation.appendChild(auditEntriesList1);

				Element inputCRAlocsList = doc.createElement("INPUTCRALLOCS.LIST");

				inputCRAlocsList.setTextContent(" ");

				accountingAllocation.appendChild(inputCRAlocsList);

				Element dutyHeadDetailsList1 = doc.createElement("DUTYHEADDETAILS.LIST");

				dutyHeadDetailsList1.setTextContent(" ");

				accountingAllocation.appendChild(dutyHeadDetailsList1);

				Element exciseDutyHeadDetailsList = doc.createElement("EXCISEDUTYHEADDETAILS.LIST");

				exciseDutyHeadDetailsList.setTextContent(" ");

				accountingAllocation.appendChild(exciseDutyHeadDetailsList);

				Element rateDetailsList = doc.createElement("RATEDETAILS.LIST");

				rateDetailsList.setTextContent(" ");

				accountingAllocation.appendChild(rateDetailsList);

				Element summaryAllocsList = doc.createElement("SUMMARYALLOCS.LIST");

				summaryAllocsList.setTextContent(" ");

				accountingAllocation.appendChild(summaryAllocsList);

				Element stPymtDetailsList = doc.createElement("STPYMTDETAILS.LIST");

				stPymtDetailsList.setTextContent(" ");

				accountingAllocation.appendChild(stPymtDetailsList);

				Element excisePaymentAllocationsList = doc.createElement("EXCISEPAYMENTALLOCATIONS.LIST");

				excisePaymentAllocationsList.setTextContent(" ");

				accountingAllocation.appendChild(excisePaymentAllocationsList);

				Element taxBillAllocationsList = doc.createElement("TAXBILLALLOCATIONS.LIST");

				taxBillAllocationsList.setTextContent(" ");

				accountingAllocation.appendChild(taxBillAllocationsList);

				Element taxObjectAllocationsList = doc.createElement("TAXOBJECTALLOCATIONS.LIST");

				taxObjectAllocationsList.setTextContent(" ");

				accountingAllocation.appendChild(taxObjectAllocationsList);

				Element tdsExpenseAllocationsList = doc.createElement("TDSEXPENSEALLOCATIONS.LIST");

				tdsExpenseAllocationsList.setTextContent(" ");

				accountingAllocation.appendChild(tdsExpenseAllocationsList);

				Element vatStatutoryDetailsList = doc.createElement("VATSTATUTORYDETAILS.LIST");

				vatStatutoryDetailsList.setTextContent(" ");

				accountingAllocation.appendChild(vatStatutoryDetailsList);

				Element costTrackAllocationsList = doc.createElement("COSTTRACKALLOCATIONS.LIST");

				costTrackAllocationsList.setTextContent(" ");

				accountingAllocation.appendChild(costTrackAllocationsList);

				Element refVoucherDetailsList = doc.createElement("REFVOUCHERDETAILS.LIST");

				refVoucherDetailsList.setTextContent(" ");

				accountingAllocation.appendChild(refVoucherDetailsList);

				Element invoiceWiseDetailsList = doc.createElement("INVOICEWISEDETAILS.LIST");

				invoiceWiseDetailsList.setTextContent(" ");

				accountingAllocation.appendChild(invoiceWiseDetailsList);

				Element vatITCDetails = doc.createElement("VATITCDETAILS.LIST");

				vatITCDetails.setTextContent(" ");

				accountingAllocation.appendChild(vatITCDetails);

				Element advanceTaxDetails = doc.createElement("ADVANCETAXDETAILS.LIST");

				advanceTaxDetails.setTextContent(" ");

				accountingAllocation.appendChild(advanceTaxDetails);

				// setting appending account allocation

				inventoryList.appendChild(accountingAllocation);

				Element dutyHeaderDetails = doc.createElement("DUTYHEADDETAILS.LIST");

				dutyHeaderDetails.setTextContent(" ");

				inventoryList.appendChild(dutyHeaderDetails);

				Element supplymentaryDutyHeaderDetails = doc.createElement("SUPPLEMENTARYDUTYHEADDETAILS.LIST");

				supplymentaryDutyHeaderDetails.setTextContent(" ");

				inventoryList.appendChild(supplymentaryDutyHeaderDetails);

				Element taxObjectAllocations = doc.createElement("TAXOBJECTALLOCATIONS.LIST");

				taxObjectAllocations.setTextContent(" ");

				inventoryList.appendChild(taxObjectAllocations);

				Element refVoucherDetails = doc.createElement("REFVOUCHERDETAILS.LIST");

				refVoucherDetails.setTextContent(" ");

				inventoryList.appendChild(refVoucherDetails);

				Element exciseAllocations = doc.createElement("EXCISEALLOCATIONS.LIST");

				exciseAllocations.setTextContent(" ");

				inventoryList.appendChild(exciseAllocations);

				List<ExpenseAllocationList> expenseAllocationList = voucherRequest.getAllInventoryList().get(ak)
						.getExpenseAllocationList();

				for (int bk = 0; bk < expenseAllocationList.size(); bk++) {

					Element expenseAllocate = doc.createElement("EXPENSEALLOCATIONS.LIST");

					Element ledgername2 = doc.createElement("LEDGERNAME");

					ledgername2.setTextContent(voucherRequest.getAllInventoryList().get(ak).getExpenseAllocationList()
							.get(bk).getLedgerName());

					expenseAllocate.appendChild(ledgername2);

					// append exepenseallocate

					inventoryList.appendChild(expenseAllocate);

				}

				voucherElement.appendChild(inventoryList);

			}

			Element supplementaryDutyHeadDetailsList = doc.createElement("SUPPLEMENTARYDUTYHEADDETAILS.LIST");

			supplementaryDutyHeadDetailsList.setTextContent(" ");

			voucherElement.appendChild(supplementaryDutyHeadDetailsList);

			// Create the elements

			Element eWayBillErrorList = doc.createElement("EWAYBILLERRORLIST.LIST");

			eWayBillErrorList.setTextContent(" ");

			Element irnErrorList = doc.createElement("IRNERRORLIST.LIST");

			irnErrorList.setTextContent(" ");

			Element invoiceDelNotesList = doc.createElement("INVOICEDELNOTES.LIST");

			invoiceDelNotesList.setTextContent(" ");

			Element invoiceOrderList = doc.createElement("INVOICEORDERLIST.LIST");

			invoiceOrderList.setTextContent(" ");

			Element invoiceIndentList = doc.createElement("INVOICEINDENTLIST.LIST");

			invoiceIndentList.setTextContent(" ");

			Element attendanceEntriesList = doc.createElement("ATTENDANCEENTRIES.LIST");

			attendanceEntriesList.setTextContent(" ");

			Element oriInvoiceDetailsList = doc.createElement("ORIGINVOICEDETAILS.LIST");

			oriInvoiceDetailsList.setTextContent(" ");

			Element invoiceExportList = doc.createElement("INVOICEEXPORTLIST.LIST");

			invoiceExportList.setTextContent(" ");

			// Append the elements to the voucher element

			voucherElement.appendChild(eWayBillErrorList);

			voucherElement.appendChild(irnErrorList);

			voucherElement.appendChild(invoiceDelNotesList);

			voucherElement.appendChild(invoiceOrderList);

			voucherElement.appendChild(invoiceIndentList);

			voucherElement.appendChild(attendanceEntriesList);

			voucherElement.appendChild(oriInvoiceDetailsList);

			voucherElement.appendChild(invoiceExportList);

			// Ledger 1 final

			Element ledgerEntry1 = doc.createElement("LEDGERENTRIES.LIST");

			// I will use 1156, 57, 58,59, 60 for ledger 2 and ledger 3

			Element oldAuditList = doc.createElement("OLDAUDITENTRYIDS.LIST");

			oldAuditList.setAttribute("TYPE", "Number");

			Element oldAuditId = doc.createElement("OLDAUDITENTRYIDS");

			oldAuditId.setTextContent("-1");

			oldAuditList.appendChild(oldAuditId);

			ledgerEntry1.appendChild(oldAuditList);

			Element ledgername1 = doc.createElement("LEDGERNAME");

			ledgername1.setTextContent(voucherRequest.getLedgerEntry1().getLedgerName());

			ledgerEntry1.appendChild(ledgername1);

			// For GSTCLASS

			Element gstclass1 = doc.createElement("GSTCLASS");

			ledgerEntry1.appendChild(gstclass1);

			// For ISDEEMEDPOSITIVE

			Element isdeemedpositive1 = doc.createElement("ISDEEMEDPOSITIVE");

			isdeemedpositive1.setTextContent(voucherRequest.getLedgerEntry1().getIsDeemedPositive());

			ledgerEntry1.appendChild(isdeemedpositive1);

			// For LEDGERFROMITEM

			Element ledgerfromitem1 = doc.createElement("LEDGERFROMITEM");

			ledgerfromitem1.setTextContent(voucherRequest.getLedgerEntry1().getLedgerFromItem());

			ledgerEntry1.appendChild(ledgerfromitem1);

			// For REMOVEZEROENTRIES

			Element removezeroentries1 = doc.createElement("REMOVEZEROENTRIES");

			removezeroentries1.setTextContent(voucherRequest.getLedgerEntry1().getRemoveZeroEntries());

			ledgerEntry1.appendChild(removezeroentries1);

			// For ISPARTYLEDGER

			Element ispartyledger1 = doc.createElement("ISPARTYLEDGER");

			ispartyledger1.setTextContent(voucherRequest.getLedgerEntry1().getIsPartyLedger());

			ledgerEntry1.appendChild(ispartyledger1);

			// For ISLASTDEEMEDPOSITIVE

			Element islastdeemedpositive1 = doc.createElement("ISLASTDEEMEDPOSITIVE");

			islastdeemedpositive1.setTextContent(voucherRequest.getLedgerEntry1().getIsLastDeemedPositive());

			ledgerEntry1.appendChild(islastdeemedpositive1);

			// For ISCAPVATTAXALTERED

			Element iscapvattaxaltered1 = doc.createElement("ISCAPVATTAXALTERED");

			iscapvattaxaltered1.setTextContent(voucherRequest.getLedgerEntry1().getIsCapVatTaxAltered());

			ledgerEntry1.appendChild(iscapvattaxaltered1);

			// For ISCAPVATNOTCLAIMED

			Element iscapvatnotclaimed1 = doc.createElement("ISCAPVATNOTCLAIMED");

			iscapvatnotclaimed1.setTextContent(voucherRequest.getLedgerEntry1().getIsCapVatNotClaimed());

			ledgerEntry1.appendChild(iscapvatnotclaimed1);

			// For AMOUNT

			Element amount1 = doc.createElement("AMOUNT");

			amount1.setTextContent(String.valueOf(voucherRequest.getLedgerEntry1().getAmount()));

			ledgerEntry1.appendChild(amount1);

			Element serviceTaxDetailsList = doc.createElement("SERVICETAXDETAILS.LIST");

			serviceTaxDetailsList.setTextContent(" ");

			ledgerEntry1.appendChild(serviceTaxDetailsList);

			Element bankAllocationsList = doc.createElement("BANKALLOCATIONS.LIST");

			bankAllocationsList.setTextContent(" ");

			ledgerEntry1.appendChild(bankAllocationsList);

			Element billAllocationsList = doc.createElement("BILLALLOCATIONS.LIST");

			billAllocationsList.setTextContent(" ");

			ledgerEntry1.appendChild(billAllocationsList);

			Element interestCollectionList = doc.createElement("INTERESTCOLLECTION.LIST");

			interestCollectionList.setTextContent(" ");

			ledgerEntry1.appendChild(interestCollectionList);

			Element oldAuditEntriesList1 = doc.createElement("OLDAUDITENTRIES.LIST");

			oldAuditEntriesList1.setTextContent(" ");

			ledgerEntry1.appendChild(oldAuditEntriesList1);

			Element accountAuditEntriesList1 = doc.createElement("ACCOUNTAUDITENTRIES.LIST");

			accountAuditEntriesList1.setTextContent(" ");

			ledgerEntry1.appendChild(accountAuditEntriesList1);

			Element auditEntriesList1 = doc.createElement("AUDITENTRIES.LIST");

			auditEntriesList1.setTextContent(" ");

			ledgerEntry1.appendChild(auditEntriesList1);

			Element inputCRAAllocsList = doc.createElement("INPUTCRALLOCS.LIST");

			inputCRAAllocsList.setTextContent(" ");

			ledgerEntry1.appendChild(inputCRAAllocsList);

			Element dutyHeadDetailsList1 = doc.createElement("DUTYHEADDETAILS.LIST");

			dutyHeadDetailsList1.setTextContent(" ");

			ledgerEntry1.appendChild(dutyHeadDetailsList1);

			Element exciseDutyHeadDetailsList = doc.createElement("EXCISEDUTYHEADDETAILS.LIST");

			exciseDutyHeadDetailsList.setTextContent(" ");

			ledgerEntry1.appendChild(exciseDutyHeadDetailsList);

			Element rateDetailsList = doc.createElement("RATEDETAILS.LIST");

			rateDetailsList.setTextContent(" ");

			ledgerEntry1.appendChild(rateDetailsList);

			Element summaryAllocsList = doc.createElement("SUMMARYALLOCS.LIST");

			summaryAllocsList.setTextContent(" ");

			ledgerEntry1.appendChild(summaryAllocsList);

			Element stPymtDetailsList = doc.createElement("STPYMTDETAILS.LIST");

			stPymtDetailsList.setTextContent(" ");

			ledgerEntry1.appendChild(stPymtDetailsList);

			Element excisePymtAllocsList = doc.createElement("EXCISEPAYMENTALLOCATIONS.LIST");

			excisePymtAllocsList.setTextContent(" ");

			ledgerEntry1.appendChild(excisePymtAllocsList);

			Element taxBillAllocsList = doc.createElement("TAXBILLALLOCATIONS.LIST");

			taxBillAllocsList.setTextContent(" ");

			ledgerEntry1.appendChild(taxBillAllocsList);

			Element taxObjectAllocsList = doc.createElement("TAXOBJECTALLOCATIONS.LIST");

			taxObjectAllocsList.setTextContent(" ");

			ledgerEntry1.appendChild(taxObjectAllocsList);

			Element tdsExpenseAllocsList = doc.createElement("TDSEXPENSEALLOCATIONS.LIST");

			tdsExpenseAllocsList.setTextContent(" ");

			ledgerEntry1.appendChild(tdsExpenseAllocsList);

			Element vatStatutoryDetailsList = doc.createElement("VATSTATUTORYDETAILS.LIST");

			vatStatutoryDetailsList.setTextContent(" ");

			ledgerEntry1.appendChild(vatStatutoryDetailsList);

			Element costTrackAllocsList = doc.createElement("COSTTRACKALLOCATIONS.LIST");

			costTrackAllocsList.setTextContent(" ");

			ledgerEntry1.appendChild(costTrackAllocsList);

			Element refVoucherDetailsList = doc.createElement("REFVOUCHERDETAILS.LIST");

			refVoucherDetailsList.setTextContent(" ");

			ledgerEntry1.appendChild(refVoucherDetailsList);

			Element invoiceWiseDetailsList = doc.createElement("INVOICEWISEDETAILS.LIST");

			invoiceWiseDetailsList.setTextContent(" ");

			ledgerEntry1.appendChild(invoiceWiseDetailsList);

			Element vatItcDetailsList = doc.createElement("VATITCDETAILS.LIST");

			vatItcDetailsList.setTextContent(" ");

			ledgerEntry1.appendChild(vatItcDetailsList);

			Element advanceTaxDetailsList = doc.createElement("ADVANCETAXDETAILS.LIST");

			advanceTaxDetailsList.setTextContent(" ");

			ledgerEntry1.appendChild(advanceTaxDetailsList);

			voucherElement.appendChild(ledgerEntry1);

			// ledger entry 2 final

			Element ledgerEntry2 = doc.createElement("LEDGERENTRIES.LIST");

			Element oldAuditList2 = doc.createElement("OLDAUDITENTRYIDS.LIST");

			oldAuditList2.setAttribute("TYPE", "Number");

			Element oldAuditId2 = doc.createElement("OLDAUDITENTRYIDS");

			oldAuditId2.setTextContent("-1");

			oldAuditList2.appendChild(oldAuditId2);

			ledgerEntry2.appendChild(oldAuditList2);

			Element roundType2 = doc.createElement("ROUNDTYPE");

			roundType2.setTextContent(voucherRequest.getLedgerEntry2().getRoundType());

			ledgerEntry2.appendChild(roundType2);

			Element ledgername2 = doc.createElement("LEDGERNAME");

			ledgername2.setTextContent(voucherRequest.getLedgerEntry2().getLedgerName());

			ledgerEntry2.appendChild(ledgername2);

			Element methodName2 = doc.createElement("METHODTYPE");

			methodName2.setTextContent(voucherRequest.getLedgerEntry2().getMethodType());

			ledgerEntry2.appendChild(methodName2);

			// For GSTCLASS

			Element gstclass2 = doc.createElement("GSTCLASS");

			ledgerEntry2.appendChild(gstclass2);

			// For ISDEEMEDPOSITIVE

			Element isdeemedpositive2 = doc.createElement("ISDEEMEDPOSITIVE");

			isdeemedpositive2.setTextContent(voucherRequest.getLedgerEntry2().getIsDeemedPositive());

			ledgerEntry2.appendChild(isdeemedpositive2);

			// For LEDGERFROMITEM

			Element ledgerfromitem2 = doc.createElement("LEDGERFROMITEM");

			ledgerfromitem2.setTextContent(voucherRequest.getLedgerEntry2().getLedgerFromItem());

			ledgerEntry2.appendChild(ledgerfromitem2);

			// For REMOVEZEROENTRIES

			Element removezeroentries2 = doc.createElement("REMOVEZEROENTRIES");

			removezeroentries2.setTextContent(voucherRequest.getLedgerEntry2().getRemoveZeroEntries());

			ledgerEntry2.appendChild(removezeroentries2);

			// For ISPARTYLEDGER

			Element ispartyledger2 = doc.createElement("ISPARTYLEDGER");

			ispartyledger2.setTextContent(voucherRequest.getLedgerEntry2().getIsPartyLedger());

			ledgerEntry2.appendChild(ispartyledger2);

			// For ISLASTDEEMEDPOSITIVE

			Element islastdeemedpositive2 = doc.createElement("ISLASTDEEMEDPOSITIVE");

			islastdeemedpositive2.setTextContent(voucherRequest.getLedgerEntry2().getIsLastDeemedPositive());

			ledgerEntry2.appendChild(islastdeemedpositive2);

			// For ISCAPVATTAXALTERED

			Element iscapvattaxaltered2 = doc.createElement("ISCAPVATTAXALTERED");

			iscapvattaxaltered2.setTextContent(voucherRequest.getLedgerEntry2().getIsCapVatTaxAltered());

			ledgerEntry2.appendChild(iscapvattaxaltered2);

			// For ISCAPVATNOTCLAIMED

			Element iscapvatnotclaimed2 = doc.createElement("ISCAPVATNOTCLAIMED");

			iscapvatnotclaimed2.setTextContent(voucherRequest.getLedgerEntry2().getIsCapVatNotClaimed());

			ledgerEntry2.appendChild(iscapvatnotclaimed2);

			// For AMOUNT

			Element amount2 = doc.createElement("AMOUNT");

			amount2.setTextContent(String.valueOf(voucherRequest.getLedgerEntry2().getAmount()));

			ledgerEntry2.appendChild(amount2);

			// vatex

			Element vatexp2 = doc.createElement("VATEXPAMOUNT");

			vatexp2.setTextContent(String.valueOf(voucherRequest.getLedgerEntry2().getVatExpAmount()));

			ledgerEntry2.appendChild(vatexp2);

			Element serviceTaxDetailsList2 = doc.createElement("SERVICETAXDETAILS.LIST");

			serviceTaxDetailsList2.setTextContent(" ");

			ledgerEntry2.appendChild(serviceTaxDetailsList2);

			Element bankAllocationsList2 = doc.createElement("BANKALLOCATIONS.LIST");

			bankAllocationsList2.setTextContent(" ");

			ledgerEntry2.appendChild(bankAllocationsList2);

			Element billAllocationsList2 = doc.createElement("BILLALLOCATIONS.LIST");

			billAllocationsList2.setTextContent(" ");

			ledgerEntry2.appendChild(billAllocationsList2);

			Element interestCollectionList2 = doc.createElement("INTERESTCOLLECTION.LIST");

			interestCollectionList2.setTextContent(" ");

			ledgerEntry2.appendChild(interestCollectionList2);

			Element oldAuditEntriesList2 = doc.createElement("OLDAUDITENTRIES.LIST");

			oldAuditEntriesList2.setTextContent(" ");

			ledgerEntry2.appendChild(oldAuditEntriesList2);

			Element accountAuditEntriesList2 = doc.createElement("ACCOUNTAUDITENTRIES.LIST");

			accountAuditEntriesList2.setTextContent(" ");

			ledgerEntry2.appendChild(accountAuditEntriesList2);

			Element auditEntriesList2 = doc.createElement("AUDITENTRIES.LIST");

			auditEntriesList2.setTextContent(" ");

			ledgerEntry2.appendChild(auditEntriesList2);

			Element inputCRAAllocsList2 = doc.createElement("INPUTCRALLOCS.LIST");

			inputCRAAllocsList2.setTextContent(" ");

			ledgerEntry2.appendChild(inputCRAAllocsList2);

			Element dutyHeadDetailsList2 = doc.createElement("DUTYHEADDETAILS.LIST");

			dutyHeadDetailsList2.setTextContent(" ");

			ledgerEntry2.appendChild(dutyHeadDetailsList2);

			Element exciseDutyHeadDetailsList2 = doc.createElement("EXCISEDUTYHEADDETAILS.LIST");

			exciseDutyHeadDetailsList2.setTextContent(" ");

			ledgerEntry2.appendChild(exciseDutyHeadDetailsList2);

			Element rateDetailsList2 = doc.createElement("RATEDETAILS.LIST");

			rateDetailsList2.setTextContent(" ");

			ledgerEntry2.appendChild(rateDetailsList2);

			Element summaryAllocsList2 = doc.createElement("SUMMARYALLOCS.LIST");

			summaryAllocsList2.setTextContent(" ");

			ledgerEntry2.appendChild(summaryAllocsList2);

			Element stPymtDetailsList2 = doc.createElement("STPYMTDETAILS.LIST");

			stPymtDetailsList2.setTextContent(" ");

			ledgerEntry2.appendChild(stPymtDetailsList2);

			Element excisePymtAllocsList2 = doc.createElement("EXCISEPAYMENTALLOCATIONS.LIST");

			excisePymtAllocsList2.setTextContent(" ");

			ledgerEntry2.appendChild(excisePymtAllocsList2);

			Element taxBillAllocsList2 = doc.createElement("TAXBILLALLOCATIONS.LIST");

			taxBillAllocsList2.setTextContent(" ");

			ledgerEntry2.appendChild(taxBillAllocsList2);

			Element taxObjectAllocsList2 = doc.createElement("TAXOBJECTALLOCATIONS.LIST");

			taxObjectAllocsList2.setTextContent(" ");

			ledgerEntry2.appendChild(taxObjectAllocsList2);

			Element tdsExpenseAllocsList2 = doc.createElement("TDSEXPENSEALLOCATIONS.LIST");

			tdsExpenseAllocsList2.setTextContent(" ");

			ledgerEntry2.appendChild(tdsExpenseAllocsList2);

			Element vatStatutoryDetailsList2 = doc.createElement("VATSTATUTORYDETAILS.LIST");

			vatStatutoryDetailsList2.setTextContent(" ");

			ledgerEntry2.appendChild(vatStatutoryDetailsList2);

			Element costTrackAllocsList2 = doc.createElement("COSTTRACKALLOCATIONS.LIST");

			costTrackAllocsList2.setTextContent(" ");

			ledgerEntry2.appendChild(costTrackAllocsList2);

			Element refVoucherDetailsList2 = doc.createElement("REFVOUCHERDETAILS.LIST");

			refVoucherDetailsList2.setTextContent(" ");

			ledgerEntry2.appendChild(refVoucherDetailsList2);

			Element invoiceWiseDetailsList2 = doc.createElement("INVOICEWISEDETAILS.LIST");

			invoiceWiseDetailsList2.setTextContent(" ");

			ledgerEntry2.appendChild(invoiceWiseDetailsList2);

			Element vatItcDetailsList2 = doc.createElement("VATITCDETAILS.LIST");

			vatItcDetailsList2.setTextContent(" ");

			ledgerEntry2.appendChild(vatItcDetailsList2);

			Element advanceTaxDetailsList2 = doc.createElement("ADVANCETAXDETAILS.LIST");

			advanceTaxDetailsList2.setTextContent(" ");

			ledgerEntry2.appendChild(advanceTaxDetailsList2);

			voucherElement.appendChild(ledgerEntry2);

			// for 3rd ledgerEntry

			Element ledgerEntry3 = doc.createElement("LEDGERENTRIES.LIST");

			Element oldAuditList3 = doc.createElement("OLDAUDITENTRYIDS.LIST");

			oldAuditList3.setAttribute("TYPE", "Number");

			Element oldAuditId3 = doc.createElement("OLDAUDITENTRYIDS");

			oldAuditId3.setTextContent("-1");

			oldAuditList3.appendChild(oldAuditId3);

			ledgerEntry3.appendChild(oldAuditList3);

			Element roundType3 = doc.createElement("ROUNDTYPE");

			roundType3.setTextContent(voucherRequest.getLedgerEntry3().getRoundType());

			ledgerEntry3.appendChild(roundType3);

			Element ledgername3 = doc.createElement("LEDGERNAME");

			ledgername3.setTextContent(voucherRequest.getLedgerEntry3().getLedgerName());

			ledgerEntry3.appendChild(ledgername3);

			Element methodName3 = doc.createElement("METHODTYPE");

			methodName3.setTextContent(voucherRequest.getLedgerEntry3().getMethodType());

			ledgerEntry3.appendChild(methodName3);

			// For GSTCLASS

			Element gstclass3 = doc.createElement("GSTCLASS");

			ledgerEntry3.appendChild(gstclass3);

			// For ISDEEMEDPOSITIVE

			Element isdeemedpositive3 = doc.createElement("ISDEEMEDPOSITIVE");

			isdeemedpositive3.setTextContent(voucherRequest.getLedgerEntry3().getIsDeemedPositive());

			ledgerEntry3.appendChild(isdeemedpositive3);

			// For LEDGERFROMITEM

			Element ledgerfromitem3 = doc.createElement("LEDGERFROMITEM");

			ledgerfromitem3.setTextContent(voucherRequest.getLedgerEntry3().getLedgerFromItem());

			ledgerEntry3.appendChild(ledgerfromitem3);

			// For REMOVEZEROENTRIES

			Element removezeroentries3 = doc.createElement("REMOVEZEROENTRIES");

			removezeroentries3.setTextContent(voucherRequest.getLedgerEntry3().getRemoveZeroEntries());

			ledgerEntry3.appendChild(removezeroentries3);

			// For ISPARTYLEDGER

			Element ispartyledger3 = doc.createElement("ISPARTYLEDGER");

			ispartyledger3.setTextContent(voucherRequest.getLedgerEntry3().getIsPartyLedger());

			ledgerEntry3.appendChild(ispartyledger3);

			// For ISLASTDEEMEDPOSITIVE

			Element islastdeemedpositive3 = doc.createElement("ISLASTDEEMEDPOSITIVE");

			islastdeemedpositive3.setTextContent(voucherRequest.getLedgerEntry3().getIsLastDeemedPositive());

			ledgerEntry3.appendChild(islastdeemedpositive3);

			// For ISCAPVATTAXALTERED

			Element iscapvattaxaltered3 = doc.createElement("ISCAPVATTAXALTERED");

			iscapvattaxaltered3.setTextContent(voucherRequest.getLedgerEntry3().getIsCapVatTaxAltered());

			ledgerEntry3.appendChild(iscapvattaxaltered3);

			// For ISCAPVATNOTCLAIMED

			Element iscapvatnotclaimed3 = doc.createElement("ISCAPVATNOTCLAIMED");

			iscapvatnotclaimed3.setTextContent(voucherRequest.getLedgerEntry3().getIsCapVatNotClaimed());

			ledgerEntry3.appendChild(iscapvatnotclaimed3);

			// roundlimit

			Element roundLimit3 = doc.createElement("ROUNDLIMIT");

			roundLimit3.setTextContent(voucherRequest.getLedgerEntry3().getRoundLimit());

			ledgerEntry3.appendChild(roundLimit3);

			// For AMOUNT

			Element amount3 = doc.createElement("AMOUNT");

			amount3.setTextContent(String.valueOf(voucherRequest.getLedgerEntry3().getAmount()));

			ledgerEntry3.appendChild(amount3);

			// vatex

			Element vatexp3 = doc.createElement("VATEXPAMOUNT");

			vatexp3.setTextContent(String.valueOf(voucherRequest.getLedgerEntry3().getVatExpAmount()));

			ledgerEntry3.appendChild(vatexp3);

			Element serviceTaxDetailsList3 = doc.createElement("SERVICETAXDETAILS.LIST");

			serviceTaxDetailsList3.setTextContent(" ");

			ledgerEntry3.appendChild(serviceTaxDetailsList3);

			Element bankAllocationsList3 = doc.createElement("BANKALLOCATIONS.LIST");

			bankAllocationsList3.setTextContent(" ");

			ledgerEntry3.appendChild(bankAllocationsList3);

			Element billAllocationsList3 = doc.createElement("BILLALLOCATIONS.LIST");

			billAllocationsList3.setTextContent(" ");

			ledgerEntry3.appendChild(billAllocationsList3);

			Element interestCollectionList3 = doc.createElement("INTERESTCOLLECTION.LIST");

			interestCollectionList3.setTextContent(" ");

			ledgerEntry3.appendChild(interestCollectionList3);

			Element oldAuditEntriesList3 = doc.createElement("OLDAUDITENTRIES.LIST");

			oldAuditEntriesList3.setTextContent(" ");

			ledgerEntry3.appendChild(oldAuditEntriesList3);

			Element accountAuditEntriesList3 = doc.createElement("ACCOUNTAUDITENTRIES.LIST");

			accountAuditEntriesList3.setTextContent(" ");

			ledgerEntry3.appendChild(accountAuditEntriesList3);

			Element auditEntriesList3 = doc.createElement("AUDITENTRIES.LIST");

			auditEntriesList3.setTextContent(" ");

			ledgerEntry3.appendChild(auditEntriesList3);

			Element inputCRAAllocsList3 = doc.createElement("INPUTCRALLOCS.LIST");

			inputCRAAllocsList3.setTextContent(" ");

			ledgerEntry3.appendChild(inputCRAAllocsList3);

			Element dutyHeadDetailsList3 = doc.createElement("DUTYHEADDETAILS.LIST");

			dutyHeadDetailsList3.setTextContent(" ");

			ledgerEntry3.appendChild(dutyHeadDetailsList3);

			Element exciseDutyHeadDetailsList3 = doc.createElement("EXCISEDUTYHEADDETAILS.LIST");

			exciseDutyHeadDetailsList3.setTextContent(" ");

			ledgerEntry3.appendChild(exciseDutyHeadDetailsList3);

			Element rateDetailsList3 = doc.createElement("RATEDETAILS.LIST");

			rateDetailsList3.setTextContent(" ");

			ledgerEntry3.appendChild(rateDetailsList3);

			Element summaryAllocsList3 = doc.createElement("SUMMARYALLOCS.LIST");

			summaryAllocsList3.setTextContent(" ");

			ledgerEntry3.appendChild(summaryAllocsList3);

			Element stPymtDetailsList3 = doc.createElement("STPYMTDETAILS.LIST");

			stPymtDetailsList3.setTextContent(" ");

			ledgerEntry3.appendChild(stPymtDetailsList3);

			Element excisePymtAllocsList3 = doc.createElement("EXCISEPAYMENTALLOCATIONS.LIST");

			excisePymtAllocsList3.setTextContent(" ");

			ledgerEntry3.appendChild(excisePymtAllocsList3);

			Element taxBillAllocsList3 = doc.createElement("TAXBILLALLOCATIONS.LIST");

			taxBillAllocsList3.setTextContent(" ");

			ledgerEntry3.appendChild(taxBillAllocsList3);

			Element taxObjectAllocsList3 = doc.createElement("TAXOBJECTALLOCATIONS.LIST");

			taxObjectAllocsList3.setTextContent(" ");

			ledgerEntry3.appendChild(taxObjectAllocsList3);

			Element tdsExpenseAllocsList3 = doc.createElement("TDSEXPENSEALLOCATIONS.LIST");

			tdsExpenseAllocsList3.setTextContent(" ");

			ledgerEntry3.appendChild(tdsExpenseAllocsList3);

			Element vatStatutoryDetailsList3 = doc.createElement("VATSTATUTORYDETAILS.LIST");

			vatStatutoryDetailsList3.setTextContent(" ");

			ledgerEntry3.appendChild(vatStatutoryDetailsList3);

			Element costTrackAllocsList3 = doc.createElement("COSTTRACKALLOCATIONS.LIST");

			costTrackAllocsList3.setTextContent(" ");

			ledgerEntry3.appendChild(costTrackAllocsList3);

			Element refVoucherDetailsList3 = doc.createElement("REFVOUCHERDETAILS.LIST");

			refVoucherDetailsList3.setTextContent(" ");

			ledgerEntry3.appendChild(refVoucherDetailsList3);

			Element invoiceWiseDetailsList3 = doc.createElement("INVOICEWISEDETAILS.LIST");

			invoiceWiseDetailsList3.setTextContent(" ");

			ledgerEntry3.appendChild(invoiceWiseDetailsList3);

			Element vatItcDetailsList3 = doc.createElement("VATITCDETAILS.LIST");

			vatItcDetailsList3.setTextContent(" ");

			ledgerEntry3.appendChild(vatItcDetailsList3);

			Element advanceTaxDetailsList3 = doc.createElement("ADVANCETAXDETAILS.LIST");

			advanceTaxDetailsList3.setTextContent(" ");

			ledgerEntry3.appendChild(advanceTaxDetailsList3);

			voucherElement.appendChild(ledgerEntry3);

			Element payrollModeOfPayment = doc.createElement("PAYROLLMODEOFPAYMENT.LIST");

			payrollModeOfPayment.setTextContent(" ");

			voucherElement.appendChild(payrollModeOfPayment);

			Element attdRecords = doc.createElement("ATTDRECORDS.LIST");

			attdRecords.setTextContent(" ");

			voucherElement.appendChild(attdRecords);

			Element gstWayConsignorAddress = doc.createElement("GSTEWAYCONSIGNORADDRESS.LIST");

			gstWayConsignorAddress.setTextContent(" ");

			voucherElement.appendChild(gstWayConsignorAddress);

			Element gstWayConsigneeAddress = doc.createElement("GSTEWAYCONSIGNEEADDRESS.LIST");

			gstWayConsigneeAddress.setTextContent(" ");

			voucherElement.appendChild(gstWayConsigneeAddress);

			Element tempGstRatedDetails = doc.createElement("TEMPGSTRATEDETAILS.LIST");

			tempGstRatedDetails.setTextContent(" ");

			voucherElement.appendChild(tempGstRatedDetails);

			Element udfList = doc.createElement("UDF:VCHCREATEONCC.LIST");

			udfList.setAttribute("DESC", "`VchCreateOnCC`");

			udfList.setAttribute("ISLIST", "YES`");

			udfList.setAttribute("TYPE", "Date");

			udfList.setAttribute("INDEX", "6007`");

			Element udf = doc.createElement("UDF:VCHCREATEONCC");

			udf.setAttribute("DESC", "`VchCreateOnCC`");

			udf.setTextContent("20230424");

			udfList.appendChild(udf);

			voucherElement.appendChild(udfList);

			Node refNode = doc.getElementsByTagName("TALLYMESSAGE").item(0);

			rootElement.insertBefore(tallyMessageElement, refNode);

			// Add the new TALLYMESSAGE to the root element of the document

			// rootElement.appendChild(tallyMessageElement);

		}

		// Return the modified XML as a string

		TransformerFactory transformerFactory = TransformerFactory.newInstance();

		Transformer transformer = transformerFactory.newTransformer();

		transformer.setOutputProperty(OutputKeys.INDENT, "yes");

		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-16LE");

		StringWriter writer = new StringWriter();

		transformer.transform(new DOMSource(doc), new StreamResult(writer));

		String xmlString = writer.getBuffer().toString();

		return xmlString;

	}

	public String SINGLEVoucherFill(VoucherRequest voucherRequest) throws Exception {

		File inputFile = new File("src/main/resources/try.xml");

		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

		Document doc = dBuilder.parse(inputFile);

		doc.getDocumentElement().normalize();

		// Get the root element of the document

		// Element rootElement = doc.getDocumentElement();

		Element rootElement = (Element) doc.getElementsByTagName("REQUESTDATA").item(0);

		// Loop through the voucher requests and append a new TALLYMESSAGE for each of
		// them

		// Create a new TALLYMESSAGE element

		Element tallyMessageElement = doc.createElement("TALLYMESSAGE");

		tallyMessageElement.setAttribute("xmlns:UDF", "TallyUDF");

		// Create a new VOUCHER element and add it to the TALLYMESSAGE

		Element voucherElement = doc.createElement("VOUCHER");

		voucherElement.setAttribute("REMOTEID", "7a49bb20-cb1e-48cc-be8e-4257740eae2a-00035deb");

		voucherElement.setAttribute("VCHKEY", UUID.randomUUID().toString());

		voucherElement.setAttribute("VCHTYPE", "Sales Order");

		voucherElement.setAttribute("ACTION", "Create");

		voucherElement.setAttribute("OBJVIEW", "Invoice Voucher View");

		tallyMessageElement.appendChild(voucherElement);

		// Add the addresses to the voucher

		List<String> addresses = voucherRequest.getAddress();

		Element addressListElement = doc.createElement("ADDRESS.LIST");

		addressListElement.setAttribute("TYPE", "String");

		for (String address : addresses) {

			Element addressElement = doc.createElement("ADDRESS");

			addressElement.setTextContent(address);

			addressListElement.appendChild(addressElement);

		}

		voucherElement.appendChild(addressListElement);

		// Add the basic buyer addresses to the voucher

		List<String> basicBuyerAddresses = voucherRequest.getBasicBuyerAddress();

		Element basicBuyerAddressListElement = doc.createElement("BASICBUYERADDRESS.LIST");

		basicBuyerAddressListElement.setAttribute("TYPE", "String");

		for (String basicBuyerAddress : basicBuyerAddresses) {

			Element basicBuyerAddressElement = doc.createElement("BASICBUYERADDRESS");

			basicBuyerAddressElement.setTextContent(basicBuyerAddress);

			basicBuyerAddressListElement.appendChild(basicBuyerAddressElement);

		}

		voucherElement.appendChild(basicBuyerAddressListElement);

		// oldauditentry

		List<String> oldEntry = voucherRequest.getOldAuditEntry();

		Element oldAuditEntryList = doc.createElement("OLDAUDITENTRYIDS.LIST");

		oldAuditEntryList.setAttribute("TYPE", "Number");

		for (String old : oldEntry) {

			Element oldAuditEntry = doc.createElement("OLDAUDITENTRYIDS");

			oldAuditEntry.setTextContent(old);

			oldAuditEntryList.appendChild(oldAuditEntry);

		}

		voucherElement.appendChild(oldAuditEntryList);

		// Set the date and guid of the voucher

		Element dateElement = doc.createElement("DATE");

		dateElement.setTextContent(voucherRequest.getDate());

		voucherElement.appendChild(dateElement);

		Element guidElement = doc.createElement("GUID");

		guidElement.setTextContent(voucherRequest.getGuid());

		voucherElement.appendChild(guidElement);

		Element gst = doc.createElement("GSTREGISTRATIONTYPE");

		gst.setTextContent(voucherRequest.getGSTREGISTRATIONTYPE());

		voucherElement.appendChild(gst);

		// Create a new CSTFORMISSUETYPE element and add it to the voucher

		Element cstformissuetypeElement = doc.createElement("VATDEALERTYPE");

		cstformissuetypeElement.setTextContent(voucherRequest.getVatDealerType());

		voucherElement.appendChild(cstformissuetypeElement);

		// Create a new STATENAME element and add it to the voucher

		Element stateNameElement = doc.createElement("STATENAME");

		stateNameElement.setTextContent(voucherRequest.getStateName());

		voucherElement.appendChild(stateNameElement);

		// Create a new PRICELEVEL element and add it to the voucher

		Element priceLevelElement = doc.createElement("PRICELEVEL");

		priceLevelElement.setTextContent(voucherRequest.getPriceLevel());

		voucherElement.appendChild(priceLevelElement);

		// Create a new VOUCHERTYPENAME element and add it to the voucher

		Element voucherTypeNameElement = doc.createElement("VOUCHERTYPENAME");

		voucherTypeNameElement.setTextContent(voucherRequest.getVoucherTypeName());

		voucherElement.appendChild(voucherTypeNameElement);

		// Create a new NARRATION element and add it to the voucher

		Element narrationElement = doc.createElement("NARRATION");

		narrationElement.setTextContent(voucherRequest.getNarration());

		voucherElement.appendChild(narrationElement);

		// Create a new ENTEREDBY element and add it to the voucher

		Element enteredByElement = doc.createElement("ENTEREDBY");

		enteredByElement.setTextContent(voucherRequest.getEnteredBy());

		voucherElement.appendChild(enteredByElement);

		// Create a new OBJUPDATEACTION element and add it to the voucher

		Element objUpdateActionElement = doc.createElement("OBJECTUPDATEACTION");

		objUpdateActionElement.setTextContent(voucherRequest.getObjectUpdateAction());

		voucherElement.appendChild(objUpdateActionElement);

		// Create a new COUNTRYOFRESIDENCE element and add it to the voucher

		Element countryOfResidenceElement = doc.createElement("COUNTRYOFRESIDENCE");

		countryOfResidenceElement.setTextContent(voucherRequest.getCountryOfResidence());

		voucherElement.appendChild(countryOfResidenceElement);

		// Create a new PARTYGSTIN element and add it to the voucher

		Element partyGSTINElement = doc.createElement("PARTYGSTIN");

		partyGSTINElement.setTextContent(voucherRequest.getPartyGSTIN());

		voucherElement.appendChild(partyGSTINElement);

		// Create a new PLACEOFSUPPLY element and add it to the voucher

		Element placeOfSupplyElement = doc.createElement("PLACEOFSUPPLY");

		placeOfSupplyElement.setTextContent(voucherRequest.getPlaceOfSupply());

		voucherElement.appendChild(placeOfSupplyElement);

		// Create a new CLASSNAME element and add it to the voucher

		Element classNameElement = doc.createElement("CLASSNAME");

		classNameElement.setTextContent(voucherRequest.getClassName());

		voucherElement.appendChild(classNameElement);

		// Create a new PARTYNAME element and add it to the voucher

		Element partyNameElement = doc.createElement("PARTYNAME");

		partyNameElement.setTextContent(voucherRequest.getPartyName());

		voucherElement.appendChild(partyNameElement);

		// Create a new PARTYLEDGERNAME element and add it to the voucher

		Element partyLedgerNameElement = doc.createElement("PARTYLEDGERNAME");

		partyLedgerNameElement.setTextContent(voucherRequest.getPartyLedgerName());

		voucherElement.appendChild(partyLedgerNameElement);

		// Create a new REFERENCE element and add it to the voucher

		Element referenceElement = doc.createElement("REFERENCE");

		referenceElement.setTextContent(voucherRequest.getReference());

		voucherElement.appendChild(referenceElement);

		// Create a new PARTMAILINGNAME element and add it to the voucher

		Element partyMailingNameElement = doc.createElement("PARTYMAILINGNAME");

		partyMailingNameElement.setTextContent(voucherRequest.getPartyMailingName());

		voucherElement.appendChild(partyMailingNameElement);

		// Create elements for the remaining fields and append them to the voucher
		// element

		Element partyPincodeElement = doc.createElement("PARTYPINCODE");

		partyPincodeElement.setTextContent(voucherRequest.getPartyPincode());

		voucherElement.appendChild(partyPincodeElement);

		Element consigneeGstinElement = doc.createElement("CONSIGNEEGSTIN");

		consigneeGstinElement.setTextContent(voucherRequest.getConsigneeGstin());

		voucherElement.appendChild(consigneeGstinElement);

		Element consigneeMailingNameElement = doc.createElement("CONSIGNEEMAILINGNAME");

		consigneeMailingNameElement.setTextContent(voucherRequest.getConsigneeMailingName());

		voucherElement.appendChild(consigneeMailingNameElement);

		Element consigneePincodeElement = doc.createElement("CONSIGNEEPINCODE");

		consigneePincodeElement.setTextContent(voucherRequest.getConsigneePincode());

		voucherElement.appendChild(consigneePincodeElement);

		Element consigneeStateNameElement = doc.createElement("CONSIGNEESTATENAME");

		consigneeStateNameElement.setTextContent(voucherRequest.getConsigneeStateName());

		voucherElement.appendChild(consigneeStateNameElement);

		Element voucherNumberElement = doc.createElement("VOUCHERNUMBER");

		voucherNumberElement.setTextContent(voucherRequest.getVoucherNumber());

		voucherElement.appendChild(voucherNumberElement);

		Element basicBasePartyNameElement = doc.createElement("BASICBASEPARTYNAME");

		basicBasePartyNameElement.setTextContent(voucherRequest.getBasicBasePartyName());

		voucherElement.appendChild(basicBasePartyNameElement);

		Element cstFormIssueTypeElement = doc.createElement("CSTFORMISSUETYPE");

		cstFormIssueTypeElement.setTextContent("");

		voucherElement.appendChild(cstFormIssueTypeElement);

		Element cstFormrec = doc.createElement("CSTFORMRECVTYPE");

		cstFormrec.setTextContent("");

		voucherElement.appendChild(cstFormrec);

		// create and append element for 'persistedView'

		Element persistedViewElement = doc.createElement("PERSISTEDVIEW");

		persistedViewElement.setTextContent(voucherRequest.getPersistedView());

		voucherElement.appendChild(persistedViewElement);

		// create and append element for 'typeOfExciseVoucher'

		Element typeOfExciseVoucherElement = doc.createElement("TYPEOFEXCISEVOUCHER");

		typeOfExciseVoucherElement.setTextContent(voucherRequest.getTypeOfExciseVoucher());

		voucherElement.appendChild(typeOfExciseVoucherElement);

		// create and append element for 'basicBuyerName'

		Element basicBuyerNameElement = doc.createElement("BASICBUYERNAME");

		basicBuyerNameElement.setTextContent(voucherRequest.getBasicBuyerName());

		voucherElement.appendChild(basicBuyerNameElement);

		// create and append element for 'basicDueDateOfPymt'

		Element basicDueDateOfPymtElement = doc.createElement("BASICDUEDATEOFPYMT");

		basicDueDateOfPymtElement.setTextContent(voucherRequest.getBasicDueDateOfPymt());

		voucherElement.appendChild(basicDueDateOfPymtElement);

		// create and append element for 'consigneeCountryName'

		Element consigneeCountryNameElement = doc.createElement("CONSIGNEECOUNTRYNAME");

		consigneeCountryNameElement.setTextContent(voucherRequest.getConsigneeCountryName());

		voucherElement.appendChild(consigneeCountryNameElement);

		Element vchGstClass = doc.createElement("VCHGSTCLASS");

		voucherElement.appendChild(vchGstClass);

		Element diffActualQtyElement = doc.createElement("DIFFACTUALQTY");

		diffActualQtyElement.setTextContent(voucherRequest.getDiffActualQty());

		voucherElement.appendChild(diffActualQtyElement);

		Element isMstFromSyncElement = doc.createElement("ISMSTFROMSYNC");

		isMstFromSyncElement.setTextContent(voucherRequest.getIsMstFromSync());

		voucherElement.appendChild(isMstFromSyncElement);

		Element isDeletedElement = doc.createElement("ISDELETED");

		isDeletedElement.setTextContent(voucherRequest.getIsDeleted());

		voucherElement.appendChild(isDeletedElement);

		Element isSecurityOnWhenEnteredElement = doc.createElement("ISSECURITYONWHENENTERED");

		isSecurityOnWhenEnteredElement.setTextContent(voucherRequest.getIsSecurityOnWhenEntered());

		voucherElement.appendChild(isSecurityOnWhenEnteredElement);

		Element asOriginalElement = doc.createElement("ASORIGINAL");

		asOriginalElement.setTextContent(voucherRequest.getAsOriginal());

		voucherElement.appendChild(asOriginalElement);

		Element auditedElement = doc.createElement("AUDITED");

		auditedElement.setTextContent(voucherRequest.getAudited());

		voucherElement.appendChild(auditedElement);

		Element forJobCostingElement = doc.createElement("FORJOBCOSTING");

		forJobCostingElement.setTextContent(voucherRequest.getForJobCosting());

		voucherElement.appendChild(forJobCostingElement);

		Element isOptionalElement = doc.createElement("ISOPTIONAL");

		isOptionalElement.setTextContent(voucherRequest.getIsOptional());

		voucherElement.appendChild(isOptionalElement);

		Element effectiveDateElement = doc.createElement("EFFECTIVEDATE");

		effectiveDateElement.setTextContent(voucherRequest.getEffectiveDate());

		voucherElement.appendChild(effectiveDateElement);

		Element useForExciseElement = doc.createElement("USEFOREXCISE");

		useForExciseElement.setTextContent(voucherRequest.getUseForExcise());

		voucherElement.appendChild(useForExciseElement);

		Element isForJobWorkInElement = doc.createElement("ISFORJOBWORKIN");

		isForJobWorkInElement.setTextContent(voucherRequest.getIsForJobWorkIn());

		voucherElement.appendChild(isForJobWorkInElement);

		Element allowConsumptionElement = doc.createElement("ALLOWCONSUMPTION");

		allowConsumptionElement.setTextContent(voucherRequest.getAllowConsumption());

		voucherElement.appendChild(allowConsumptionElement);

		Element useForInterestElement = doc.createElement("USEFORINTEREST");

		useForInterestElement.setTextContent(voucherRequest.getUseForInterest());

		voucherElement.appendChild(useForInterestElement);

		Element useForGainLossElement = doc.createElement("USEFORGAINLOSS");

		useForGainLossElement.setTextContent(voucherRequest.getUseForGainLoss());

		voucherElement.appendChild(useForGainLossElement);

		Element useForGodownTransferElement = doc.createElement("USEFORGODOWNTRANSFER");

		useForGodownTransferElement.setTextContent(voucherRequest.getUseForGodownTransfer());

		voucherElement.appendChild(useForGodownTransferElement);

		Element useForCompoundElement = doc.createElement("USEFORCOMPOUND");

		useForCompoundElement.setTextContent(voucherRequest.getUseForCompound());

		voucherElement.appendChild(useForCompoundElement);

		Element useForServiceTaxElement = doc.createElement("USEFORSERVICETAX");

		useForServiceTaxElement.setTextContent(voucherRequest.getUseForServiceTax());

		voucherElement.appendChild(useForServiceTaxElement);

		Element isOnHoldElement = doc.createElement("ISONHOLD");

		isOnHoldElement.setTextContent(voucherRequest.getIsOnHold());

		voucherElement.appendChild(isOnHoldElement);

		Element isBoeNotApplicableElement = doc.createElement("ISBOENOTAPPLICABLE");

		isBoeNotApplicableElement.setTextContent(voucherRequest.getIsBoeNotApplicable());

		voucherElement.appendChild(isBoeNotApplicableElement);

		Element isGstSecSevenApplicable = doc.createElement("ISGSTSECSEVENAPPLICABLE");

		isGstSecSevenApplicable.setTextContent(voucherRequest.getIsGstSecSevenApplicable());

		voucherElement.appendChild(isGstSecSevenApplicable);

		Element isExciseVoucherElement = doc.createElement("ISEXCISEVOUCHER");

		isExciseVoucherElement.setTextContent(voucherRequest.getIsExciseVoucher());

		voucherElement.appendChild(isExciseVoucherElement);

		Element exciseTaxOverrideElement = doc.createElement("EXCISETAXOVERRIDE");

		exciseTaxOverrideElement.setTextContent(voucherRequest.getExciseTaxOverride());

		voucherElement.appendChild(exciseTaxOverrideElement);

		Element useForTaxUnitTransferElement = doc.createElement("USEFORTAXUNITTRANSFER");

		useForTaxUnitTransferElement.setTextContent(voucherRequest.getUseForTaxUnitTransfer());

		voucherElement.appendChild(useForTaxUnitTransferElement);

		Element ignorePosValidationElement = doc.createElement("IGNOREPOSVALIDATION");

		ignorePosValidationElement.setTextContent(voucherRequest.getIgnorePosValidation());

		voucherElement.appendChild(ignorePosValidationElement);

		Element exciseOpeningElement = doc.createElement("EXCISEOPENING");

		exciseOpeningElement.setTextContent(voucherRequest.getExciseOpening());

		voucherElement.appendChild(exciseOpeningElement);

		Element useForFinalProductionElement = doc.createElement("USEFORFINALPRODUCTION");

		useForFinalProductionElement.setTextContent(voucherRequest.getUseForFinalProduction());

		voucherElement.appendChild(useForFinalProductionElement);

		Element isTdsOverriddenElement = doc.createElement("ISTDSOVERRIDDEN");

		isTdsOverriddenElement.setTextContent(voucherRequest.getIsTdsOverridden());

		voucherElement.appendChild(isTdsOverriddenElement);

		Element isTcsOverriddenElement = doc.createElement("ISTCSOVERRIDDEN");

		isTcsOverriddenElement.setTextContent(voucherRequest.getIsTcsOverridden());

		voucherElement.appendChild(isTcsOverriddenElement);

		Element isTdsTcsCashVoucherElement = doc.createElement("ISTDSTCSCASHVCH");

		isTdsTcsCashVoucherElement.setTextContent(voucherRequest.getIsTdsTcsCashVoucher());

		voucherElement.appendChild(isTdsTcsCashVoucherElement);

		Element includeAdvPymtVoucherElement = doc.createElement("INCLUDEADVPYMTVCH");

		includeAdvPymtVoucherElement.setTextContent(voucherRequest.getIncludeAdvPymtVoucher());

		voucherElement.appendChild(includeAdvPymtVoucherElement);

		Element isSubWorksContractElement = doc.createElement("ISSUBWORKSCONTRACT");

		isSubWorksContractElement.setTextContent(voucherRequest.getIsSubWorksContract());

		voucherElement.appendChild(isSubWorksContractElement);

		Element isVatOverriddenElement = doc.createElement("ISVATOVERRIDDEN");

		isVatOverriddenElement.setTextContent(voucherRequest.getIsVatOverridden());

		voucherElement.appendChild(isVatOverriddenElement);

		Element ignoreOrigVoucherDateElement = doc.createElement("IGNOREORIGVCHDATE");

		ignoreOrigVoucherDateElement.setTextContent(voucherRequest.getIgnoreOrigVoucherDate());

		voucherElement.appendChild(ignoreOrigVoucherDateElement);

		Element isVatPaidAtCustomsElement = doc.createElement("ISVATPAIDATCUSTOMS");

		isVatPaidAtCustomsElement.setTextContent(voucherRequest.getIsVatPaidAtCustoms());

		voucherElement.appendChild(isVatPaidAtCustomsElement);

		Element isDeclaredToCustomsElement = doc.createElement("ISDECLAREDTOCUSTOMS");

		isDeclaredToCustomsElement.setTextContent(voucherRequest.getIsDeclaredToCustoms());

		voucherElement.appendChild(isDeclaredToCustomsElement);

		Element isServiceTaxOverridden = doc.createElement("ISSERVICETAXOVERRIDDEN");

		isServiceTaxOverridden.setTextContent(voucherRequest.getIsServiceTaxOverridden());

		voucherElement.appendChild(isServiceTaxOverridden);

		Element isIsdVoucher = doc.createElement("ISISDVOUCHER");

		isIsdVoucher.setTextContent(voucherRequest.getIsIsdVoucher());

		voucherElement.appendChild(isIsdVoucher);

		Element isExciseOverriddenElement = doc.createElement("ISEXCISEOVERRIDDEN");

		isExciseOverriddenElement.setTextContent(voucherRequest.getIsExciseOverridden());

		voucherElement.appendChild(isExciseOverriddenElement);

		Element isExciseSupplyVchElement = doc.createElement("ISEXCISESUPPLYVCH");

		isExciseSupplyVchElement.setTextContent(voucherRequest.getIsExciseSupplyVch());

		voucherElement.appendChild(isExciseSupplyVchElement);

		Element isGstOverriddenElement = doc.createElement("ISGSTOVERRIDDEN");

		isGstOverriddenElement.setTextContent(voucherRequest.getIsGstOverridden());

		voucherElement.appendChild(isGstOverriddenElement);

		Element gstNotExportedElement = doc.createElement("GSTNOTEXPORTED");

		gstNotExportedElement.setTextContent(voucherRequest.getGstNotExported());

		voucherElement.appendChild(gstNotExportedElement);

		Element ignoreGstInvalidationElement = doc.createElement("IGNOREGSTINVALIDATION");

		ignoreGstInvalidationElement.setTextContent(voucherRequest.getIgnoreGstInvalidation());

		voucherElement.appendChild(ignoreGstInvalidationElement);

		Element isGstRefundElement = doc.createElement("ISGSTREFUND");

		isGstRefundElement.setTextContent(voucherRequest.getIsGstRefund());

		voucherElement.appendChild(isGstRefundElement);

		Element ovrdNewWayBillApplicabilityElement = doc.createElement("OVRDNEWAYBILLAPPLICABILITY");

		ovrdNewWayBillApplicabilityElement.setTextContent(voucherRequest.getOvrdNewWayBillApplicability());

		voucherElement.appendChild(ovrdNewWayBillApplicabilityElement);

		Element isVatPrincipalAccountElement = doc.createElement("ISVATPRINCIPALACCOUNT");

		isVatPrincipalAccountElement.setTextContent(voucherRequest.getIsVatPrincipalAccount());

		voucherElement.appendChild(isVatPrincipalAccountElement);

		Element ignoreEinvValidationElement = doc.createElement("IGNOREEINVVALIDATION");

		ignoreEinvValidationElement.setTextContent(voucherRequest.getIgnoreEinvValidation());

		voucherElement.appendChild(ignoreEinvValidationElement);

		Element irnJsonExportedElement = doc.createElement("IRNJSONEXPORTED");

		irnJsonExportedElement.setTextContent(voucherRequest.getIrnJsonExported());

		voucherElement.appendChild(irnJsonExportedElement);

		Element irnCancelledElement = doc.createElement("IRNCANCELLED");

		irnCancelledElement.setTextContent(voucherRequest.getIrnCancelled());

		voucherElement.appendChild(irnCancelledElement);

		Element isShippingWithinStateElement = doc.createElement("ISSHIPPINGWITHINSTATE");

		isShippingWithinStateElement.setTextContent(voucherRequest.getIsShippingWithinState());

		voucherElement.appendChild(isShippingWithinStateElement);

		Element isOverseasTouristTransElement = doc.createElement("ISOVERSEASTOURISTTRANS");

		isOverseasTouristTransElement.setTextContent(voucherRequest.getIsOverseasTouristTrans());

		voucherElement.appendChild(isOverseasTouristTransElement);

		Element isDesignatedZonePartyElement = doc.createElement("ISDESIGNATEDZONEPARTY");

		isDesignatedZonePartyElement.setTextContent(voucherRequest.getIsDesignatedZoneParty());

		voucherElement.appendChild(isDesignatedZonePartyElement);

		Element isCancelledElement = doc.createElement("ISCANCELLED");

		isCancelledElement.setTextContent(voucherRequest.getIsCancelled());

		voucherElement.appendChild(isCancelledElement);

		Element hasCashFlowElement = doc.createElement("HASCASHFLOW");

		hasCashFlowElement.setTextContent(voucherRequest.getHasCashFlow());

		voucherElement.appendChild(hasCashFlowElement);

		Element isPostDatedElement = doc.createElement("ISPOSTDATED");

		isPostDatedElement.setTextContent(voucherRequest.getIsPostDated());

		voucherElement.appendChild(isPostDatedElement);

		Element useTrackingNumberElement = doc.createElement("USETRACKINGNUMBER");

		useTrackingNumberElement.setTextContent(voucherRequest.getUseTrackingNumber());

		voucherElement.appendChild(useTrackingNumberElement);

		Element isInvoiceElement = doc.createElement("ISINVOICE");

		isInvoiceElement.setTextContent(voucherRequest.getIsInvoice());

		voucherElement.appendChild(isInvoiceElement);

		Element mfgJournalElement = doc.createElement("MFGJOURNAL");

		mfgJournalElement.setTextContent(voucherRequest.getMfgJournal());

		voucherElement.appendChild(mfgJournalElement);

		Element hasDiscountsElement = doc.createElement("HASDISCOUNTS");

		hasDiscountsElement.setTextContent(voucherRequest.getHasDiscounts());

		voucherElement.appendChild(hasDiscountsElement);

		Element asPaySlipElement = doc.createElement("ASPAYSLIP");

		asPaySlipElement.setTextContent(voucherRequest.getAsPaySlip());

		voucherElement.appendChild(asPaySlipElement);

		Element isCostCentreElement = doc.createElement("ISCOSTCENTRE");

		isCostCentreElement.setTextContent(voucherRequest.getIsCostCentre());

		voucherElement.appendChild(isCostCentreElement);

		Element isStxNonRealizedVchElement = doc.createElement("ISSTXNONREALIZEDVCH");

		isStxNonRealizedVchElement.setTextContent(voucherRequest.getIsStxNonRealizedVch());

		voucherElement.appendChild(isStxNonRealizedVchElement);

		Element isExciseManufacturerOnElement = doc.createElement("ISEXCISEMANUFACTURERON");

		isExciseManufacturerOnElement.setTextContent(voucherRequest.getIsExciseManufacturerOn());

		voucherElement.appendChild(isExciseManufacturerOnElement);

		Element isBlankChequeElement = doc.createElement("ISBLANKCHEQUE");

		isBlankChequeElement.setTextContent(voucherRequest.getIsBlankCheque());

		voucherElement.appendChild(isBlankChequeElement);

		Element isVoidElement = doc.createElement("ISVOID");

		isVoidElement.setTextContent(voucherRequest.getIsVoid());

		voucherElement.appendChild(isVoidElement);

		Element orderLineStatusElement = doc.createElement("ORDERLINESTATUS");

		orderLineStatusElement.setTextContent(voucherRequest.getOrderLineStatus());

		voucherElement.appendChild(orderLineStatusElement);

		Element vatIsAgstCancSalesElement = doc.createElement("VATISAGNSTCANCSALES");

		vatIsAgstCancSalesElement.setTextContent(voucherRequest.getVatIsAgstCancSales());

		voucherElement.appendChild(vatIsAgstCancSalesElement);

		Element vatIsPurcExemptedElement = doc.createElement("VATISPURCEXEMPTED");

		vatIsPurcExemptedElement.setTextContent(voucherRequest.getVatIsPurcExempted());

		voucherElement.appendChild(vatIsPurcExemptedElement);

		Element isVatRestaxInvoiceElement = doc.createElement("ISVATRESTAXINVOICE");

		isVatRestaxInvoiceElement.setTextContent(voucherRequest.getIsVatRestaxInvoice());

		voucherElement.appendChild(isVatRestaxInvoiceElement);

		Element vatIsAssesableCalcVchElement = doc.createElement("VATISASSESABLECALCVCH");

		vatIsAssesableCalcVchElement.setTextContent(voucherRequest.getVatIsAssesableCalcVch());

		voucherElement.appendChild(vatIsAssesableCalcVchElement);

		Element isVatDutyPaidElement = doc.createElement("ISVATDUTYPAID");

		isVatDutyPaidElement.setTextContent(voucherRequest.getIsVatDutyPaid());

		voucherElement.appendChild(isVatDutyPaidElement);

		Element isDeliverySameAsConsigneeElement = doc.createElement("ISDELIVERYSAMEASCONSIGNEE");

		isDeliverySameAsConsigneeElement.setTextContent(voucherRequest.getIsDeliverySameAsConsignee());

		voucherElement.appendChild(isDeliverySameAsConsigneeElement);

		Element isDispatchSameAsConsignorElement = doc.createElement("ISDISPATCHSAMEASCONSIGNOR");

		isDispatchSameAsConsignorElement.setTextContent(voucherRequest.getIsDispatchSameAsConsignor());

		voucherElement.appendChild(isDispatchSameAsConsignorElement);

		Element isDeletedVchRetainedElement = doc.createElement("ISDELETEDVCHRETAINED");

		isDeletedVchRetainedElement.setTextContent(voucherRequest.getIsDeletedVchRetained());

		voucherElement.appendChild(isDeletedVchRetainedElement);

		Element changeVchModeElement = doc.createElement("CHANGEVCHMODE");

		changeVchModeElement.setTextContent(voucherRequest.getChangeVchMode());

		voucherElement.appendChild(changeVchModeElement);

		Element resetIrnQrCodeElement = doc.createElement("RESETIRNQRCODE");

		resetIrnQrCodeElement.setTextContent(voucherRequest.getResetIrnQrCode());

		voucherElement.appendChild(resetIrnQrCodeElement);

		Element alterIdElement = doc.createElement("ALTERID");

		alterIdElement.setTextContent(voucherRequest.getAlterId());

		voucherElement.appendChild(alterIdElement);

		Element masterIdElement = doc.createElement("MASTERID");

		masterIdElement.setTextContent(voucherRequest.getMasterId());

		voucherElement.appendChild(masterIdElement);

		Element voucherKeyElement = doc.createElement("VOUCHERKEY");

		voucherKeyElement.setTextContent(voucherRequest.getVoucherKey());

		voucherElement.appendChild(voucherKeyElement);

		Element updatedDateTimeElement = doc.createElement("UPDATEDDATETIME");

		updatedDateTimeElement.setTextContent(voucherRequest.getUpdatedDateTime());

		voucherElement.appendChild(updatedDateTimeElement);

		Element eWayBillDetailsList = doc.createElement("EWAYBILLDETAILS.LIST");

		eWayBillDetailsList.setTextContent(" ");

		voucherElement.appendChild(eWayBillDetailsList);

		Element excludedTaxationsList = doc.createElement("EXCLUDEDTAXATIONS.LIST");

		excludedTaxationsList.setTextContent(" ");

		voucherElement.appendChild(excludedTaxationsList);

		Element oldAuditEntriesList = doc.createElement("OLDAUDITENTRIES.LIST");

		oldAuditEntriesList.setTextContent(" ");

		voucherElement.appendChild(oldAuditEntriesList);

		Element accountAuditEntriesList = doc.createElement("ACCOUNTAUDITENTRIES.LIST");

		accountAuditEntriesList.setTextContent(" ");

		voucherElement.appendChild(accountAuditEntriesList);

		Element auditEntriesList = doc.createElement("AUDITENTRIES.LIST");

		auditEntriesList.setTextContent(" ");

		voucherElement.appendChild(auditEntriesList);

		Element dutyHeadDetailsList = doc.createElement("DUTYHEADDETAILS.LIST");

		dutyHeadDetailsList.setTextContent(" ");

		voucherElement.appendChild(dutyHeadDetailsList);

		// for stock items

		List<AllInventoryList> allInventoryList = voucherRequest.getAllInventoryList();

		for (int ak = 0; ak < allInventoryList.size(); ak++) {

			Element inventoryList = doc.createElement("ALLINVENTORYENTRIES.LIST");

			Element stockItemname = doc.createElement("STOCKITEMNAME");

			stockItemname.setTextContent(voucherRequest.getAllInventoryList().get(ak).getStockItemName());

			inventoryList.appendChild(stockItemname);

			Element isDeemedPositive = doc.createElement("ISDEEMEDPOSITIVE");

			isDeemedPositive.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsDeemedPositive());

			inventoryList.appendChild(isDeemedPositive);

			Element isLastDeemedPositive = doc.createElement("ISLASTDEEMEDPOSITIVE");

			isLastDeemedPositive.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsLastDeemedPositive());

			inventoryList.appendChild(isLastDeemedPositive);

			Element isAutoNegate = doc.createElement("ISAUTONEGATE");

			isAutoNegate.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsAutoNegate());

			inventoryList.appendChild(isAutoNegate);

			Element isCustomsClearance = doc.createElement("ISCUSTOMSCLEARANCE");

			isCustomsClearance.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsCustomsClearance());

			inventoryList.appendChild(isCustomsClearance);

			Element isTrackComponent = doc.createElement("ISTRACKCOMPONENT");

			isTrackComponent.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsTrackComponent());

			inventoryList.appendChild(isTrackComponent);

			Element isTrackProduction = doc.createElement("ISTRACKPRODUCTION");

			isTrackProduction.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsTrackProduction());

			inventoryList.appendChild(isTrackProduction);

			Element isPrimaryItem = doc.createElement("ISPRIMARYITEM");

			isPrimaryItem.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsPrimaryItem());

			inventoryList.appendChild(isPrimaryItem);

			Element isScrap = doc.createElement("ISSCRAP");

			isScrap.setTextContent(voucherRequest.getAllInventoryList().get(ak).getIsScrap());

			inventoryList.appendChild(isScrap);

			Element rate = doc.createElement("RATE");

			rate.setTextContent(voucherRequest.getAllInventoryList().get(ak).getRate());

			inventoryList.appendChild(rate);

			Element discount = doc.createElement("DISCOUNT");

			discount.setTextContent(voucherRequest.getAllInventoryList().get(ak).getDiscount());

			inventoryList.appendChild(discount);

			Element amount = doc.createElement("AMOUNT");

			amount.setTextContent(voucherRequest.getAllInventoryList().get(ak).getAmount());

			inventoryList.appendChild(amount);

			Element actualQty = doc.createElement("ACTUALQTY");

			actualQty.setTextContent(voucherRequest.getAllInventoryList().get(ak).getActualQty());

			inventoryList.appendChild(actualQty);

			Element billedQty = doc.createElement("BILLEDQTY");

			billedQty.setTextContent(voucherRequest.getAllInventoryList().get(ak).getBilledQty());

			inventoryList.appendChild(billedQty);

			// for batchAllocation

			Element batchAllocation = doc.createElement("BATCHALLOCATIONS.LIST");

			Element godownName = doc.createElement("GODOWNNAME");

			godownName
			.setTextContent(voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getGodownName());

			batchAllocation.appendChild(godownName);

			Element batchName = doc.createElement("BATCHNAME");

			batchName.setTextContent(voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getBatchName());

			batchAllocation.appendChild(batchName);

			Element destinationGodownName = doc.createElement("DESTINATIONGODOWNNAME");

			destinationGodownName.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getDestinationGodownName());

			batchAllocation.appendChild(destinationGodownName);

			Element indentNo = doc.createElement("INDENTNO");

			//                indentNo.setTextContent(voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getIndentNo());

			batchAllocation.appendChild(indentNo);

			Element orderNo = doc.createElement("ORDERNO");

			orderNo.setTextContent(voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getOrderNo());

			batchAllocation.appendChild(orderNo);

			Element trackingNumber = doc.createElement("TRACKINGNUMBER");

			trackingNumber.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getTrackingNumber());

			batchAllocation.appendChild(trackingNumber);

			Element dynamicCstIsCleared = doc.createElement("DYNAMICCSTISCLEARED");

			dynamicCstIsCleared.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getDynamicCstIsCleared());

			batchAllocation.appendChild(dynamicCstIsCleared);

			Element amount1 = doc.createElement("AMOUNT");

			amount1.setTextContent(voucherRequest.getAllInventoryList().get(ak).getAmount());

			batchAllocation.appendChild(amount1);

			Element actualQty1 = doc.createElement("ACTUALQTY");

			actualQty1.setTextContent(voucherRequest.getAllInventoryList().get(ak).getActualQty());

			batchAllocation.appendChild(actualQty1);

			Element billedQty1 = doc.createElement("BILLEDQTY");

			billedQty1.setTextContent(voucherRequest.getAllInventoryList().get(ak).getBilledQty());

			batchAllocation.appendChild(billedQty1);

			Element orderDueDate = doc.createElement("ORDERDUEDATE");

			orderDueDate.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getOrderDueDate());

			orderDueDate.setAttribute("JD", "45039");

			orderDueDate.setAttribute("P",
					voucherRequest.getAllInventoryList().get(ak).getBatchAllocations().getOrderDueDate());

			batchAllocation.appendChild(orderDueDate);

			inventoryList.appendChild(batchAllocation);

			Element additional = doc.createElement("ADDITIONALDETAILS.LIST");

			additional.setTextContent(" ");

			batchAllocation.appendChild(additional);

			Element voucherComponent = doc.createElement("VOUCHERCOMPONENTLIST.LIST");

			voucherComponent.setTextContent(" ");

			batchAllocation.appendChild(voucherComponent);

			// pushing batch allocation

			inventoryList.appendChild(batchAllocation);

			// acounting

			Element accountingAllocation = doc.createElement("ACCOUNTINGALLOCATIONS.LIST");

			Element oldAccounting = doc.createElement("OLDAUDITENTRYIDS.LIST");

			oldAccounting.setAttribute("TYPE", "Number");

			Element oldAccountingId = doc.createElement("OLDAUDITENTRYIDS");

			oldAccountingId.setTextContent("-1");

			oldAccounting.appendChild(oldAccountingId);

			accountingAllocation.appendChild(oldAccounting);

			Element ledgerName1 = doc.createElement("LEDGERNAME");

			ledgerName1.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getLedgerName());

			accountingAllocation.appendChild(ledgerName1);

			Element classRate = doc.createElement("CLASSRATE");

			classRate.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getClassRate());

			accountingAllocation.appendChild(classRate);

			Element gstClass = doc.createElement("GSTCLASS");

			gstClass.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getGstClass());

			accountingAllocation.appendChild(gstClass);

			Element isDeemedPositive1 = doc.createElement("ISDEEMEDPOSITIVE");

			isDeemedPositive1.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getIsDeemedPositive());

			accountingAllocation.appendChild(isDeemedPositive1);

			Element ledgerFromItem = doc.createElement("LEDGERFROMITEM");

			ledgerFromItem.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getLedgerFromItem());

			accountingAllocation.appendChild(ledgerFromItem);

			Element removeZeroEntries = doc.createElement("REMOVEZEROENTRIES");

			removeZeroEntries.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getRemoveZeroEntries());

			accountingAllocation.appendChild(removeZeroEntries);

			Element isPartyLedger = doc.createElement("ISPARTYLEDGER");

			isPartyLedger.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getIsPartyLedger());

			accountingAllocation.appendChild(isPartyLedger);

			Element isLastDeemedPositive1 = doc.createElement("ISLASTDEEMEDPOSITIVE");

			isLastDeemedPositive1.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getIsLastDeemedPositive());

			accountingAllocation.appendChild(isLastDeemedPositive1);

			Element isCapVatTaxAltered = doc.createElement("ISCAPVATTAXALTERED");

			isCapVatTaxAltered.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getIsCapVatTaxAltered());

			accountingAllocation.appendChild(isCapVatTaxAltered);

			Element isCapVatNotClaimed = doc.createElement("ISCAPVATNOTCLAIMED");

			isCapVatNotClaimed.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getIsCapVatNotClaimed());

			accountingAllocation.appendChild(isCapVatNotClaimed);

			Element amount11 = doc.createElement("AMOUNT");

			amount11.setTextContent(
					voucherRequest.getAllInventoryList().get(ak).getAccountingAllocations().getAmount());

			accountingAllocation.appendChild(amount11);

			Element serviceTaxDetailsList = doc.createElement("SERVICETAXDETAILS.LIST");

			serviceTaxDetailsList.setTextContent(" ");

			accountingAllocation.appendChild(serviceTaxDetailsList);

			Element bankAllocationsList = doc.createElement("BANKALLOCATIONS.LIST");

			bankAllocationsList.setTextContent(" ");

			accountingAllocation.appendChild(bankAllocationsList);

			Element billAllocationsList = doc.createElement("BILLALLOCATIONS.LIST");

			billAllocationsList.setTextContent(" ");

			accountingAllocation.appendChild(billAllocationsList);

			Element interestCollectionList = doc.createElement("INTERESTCOLLECTION.LIST");

			interestCollectionList.setTextContent(" ");

			accountingAllocation.appendChild(interestCollectionList);

			Element oldAuditEntriesList1 = doc.createElement("OLDAUDITENTRIES.LIST");

			oldAuditEntriesList1.setTextContent(" ");

			accountingAllocation.appendChild(oldAuditEntriesList1);

			Element accountAuditEntriesList1 = doc.createElement("ACCOUNTAUDITENTRIES.LIST");

			accountAuditEntriesList1.setTextContent(" ");

			accountingAllocation.appendChild(accountAuditEntriesList1);

			Element auditEntriesList1 = doc.createElement("AUDITENTRIES.LIST");

			auditEntriesList1.setTextContent(" ");

			accountingAllocation.appendChild(auditEntriesList1);

			Element inputCRAlocsList = doc.createElement("INPUTCRALLOCS.LIST");

			inputCRAlocsList.setTextContent(" ");

			accountingAllocation.appendChild(inputCRAlocsList);

			Element dutyHeadDetailsList1 = doc.createElement("DUTYHEADDETAILS.LIST");

			dutyHeadDetailsList1.setTextContent(" ");

			accountingAllocation.appendChild(dutyHeadDetailsList1);

			Element exciseDutyHeadDetailsList = doc.createElement("EXCISEDUTYHEADDETAILS.LIST");

			exciseDutyHeadDetailsList.setTextContent(" ");

			accountingAllocation.appendChild(exciseDutyHeadDetailsList);

			Element rateDetailsList = doc.createElement("RATEDETAILS.LIST");

			rateDetailsList.setTextContent(" ");

			accountingAllocation.appendChild(rateDetailsList);

			Element summaryAllocsList = doc.createElement("SUMMARYALLOCS.LIST");

			summaryAllocsList.setTextContent(" ");

			accountingAllocation.appendChild(summaryAllocsList);

			Element stPymtDetailsList = doc.createElement("STPYMTDETAILS.LIST");

			stPymtDetailsList.setTextContent(" ");

			accountingAllocation.appendChild(stPymtDetailsList);

			Element excisePaymentAllocationsList = doc.createElement("EXCISEPAYMENTALLOCATIONS.LIST");

			excisePaymentAllocationsList.setTextContent(" ");

			accountingAllocation.appendChild(excisePaymentAllocationsList);

			Element taxBillAllocationsList = doc.createElement("TAXBILLALLOCATIONS.LIST");

			taxBillAllocationsList.setTextContent(" ");

			accountingAllocation.appendChild(taxBillAllocationsList);

			Element taxObjectAllocationsList = doc.createElement("TAXOBJECTALLOCATIONS.LIST");

			taxObjectAllocationsList.setTextContent(" ");

			accountingAllocation.appendChild(taxObjectAllocationsList);

			Element tdsExpenseAllocationsList = doc.createElement("TDSEXPENSEALLOCATIONS.LIST");

			tdsExpenseAllocationsList.setTextContent(" ");

			accountingAllocation.appendChild(tdsExpenseAllocationsList);

			Element vatStatutoryDetailsList = doc.createElement("VATSTATUTORYDETAILS.LIST");

			vatStatutoryDetailsList.setTextContent(" ");

			accountingAllocation.appendChild(vatStatutoryDetailsList);

			Element costTrackAllocationsList = doc.createElement("COSTTRACKALLOCATIONS.LIST");

			costTrackAllocationsList.setTextContent(" ");

			accountingAllocation.appendChild(costTrackAllocationsList);

			Element refVoucherDetailsList = doc.createElement("REFVOUCHERDETAILS.LIST");

			refVoucherDetailsList.setTextContent(" ");

			accountingAllocation.appendChild(refVoucherDetailsList);

			Element invoiceWiseDetailsList = doc.createElement("INVOICEWISEDETAILS.LIST");

			invoiceWiseDetailsList.setTextContent(" ");

			accountingAllocation.appendChild(invoiceWiseDetailsList);

			Element vatITCDetails = doc.createElement("VATITCDETAILS.LIST");

			vatITCDetails.setTextContent(" ");

			accountingAllocation.appendChild(vatITCDetails);

			Element advanceTaxDetails = doc.createElement("ADVANCETAXDETAILS.LIST");

			advanceTaxDetails.setTextContent(" ");

			accountingAllocation.appendChild(advanceTaxDetails);

			// setting appending account allocation

			inventoryList.appendChild(accountingAllocation);

			Element dutyHeaderDetails = doc.createElement("DUTYHEADDETAILS.LIST");

			dutyHeaderDetails.setTextContent(" ");

			inventoryList.appendChild(dutyHeaderDetails);

			Element supplymentaryDutyHeaderDetails = doc.createElement("SUPPLEMENTARYDUTYHEADDETAILS.LIST");

			supplymentaryDutyHeaderDetails.setTextContent(" ");

			inventoryList.appendChild(supplymentaryDutyHeaderDetails);

			Element taxObjectAllocations = doc.createElement("TAXOBJECTALLOCATIONS.LIST");

			taxObjectAllocations.setTextContent(" ");

			inventoryList.appendChild(taxObjectAllocations);

			Element refVoucherDetails = doc.createElement("REFVOUCHERDETAILS.LIST");

			refVoucherDetails.setTextContent(" ");

			inventoryList.appendChild(refVoucherDetails);

			Element exciseAllocations = doc.createElement("EXCISEALLOCATIONS.LIST");

			exciseAllocations.setTextContent(" ");

			inventoryList.appendChild(exciseAllocations);

			List<ExpenseAllocationList> expenseAllocationList = voucherRequest.getAllInventoryList().get(ak)
					.getExpenseAllocationList();

			for (int bk = 0; bk < expenseAllocationList.size(); bk++) {

				Element expenseAllocate = doc.createElement("EXPENSEALLOCATIONS.LIST");

				Element ledgername2 = doc.createElement("LEDGERNAME");

				ledgername2.setTextContent(voucherRequest.getAllInventoryList().get(ak).getExpenseAllocationList()
						.get(bk).getLedgerName());

				expenseAllocate.appendChild(ledgername2);

				// append exepenseallocate

				inventoryList.appendChild(expenseAllocate);

			}

			voucherElement.appendChild(inventoryList);

		}

		Element supplementaryDutyHeadDetailsList = doc.createElement("SUPPLEMENTARYDUTYHEADDETAILS.LIST");

		supplementaryDutyHeadDetailsList.setTextContent(" ");

		voucherElement.appendChild(supplementaryDutyHeadDetailsList);

		// Create the elements

		Element eWayBillErrorList = doc.createElement("EWAYBILLERRORLIST.LIST");

		eWayBillErrorList.setTextContent(" ");

		Element irnErrorList = doc.createElement("IRNERRORLIST.LIST");

		irnErrorList.setTextContent(" ");

		Element invoiceDelNotesList = doc.createElement("INVOICEDELNOTES.LIST");

		invoiceDelNotesList.setTextContent(" ");

		Element invoiceOrderList = doc.createElement("INVOICEORDERLIST.LIST");

		invoiceOrderList.setTextContent(" ");

		Element invoiceIndentList = doc.createElement("INVOICEINDENTLIST.LIST");

		invoiceIndentList.setTextContent(" ");

		Element attendanceEntriesList = doc.createElement("ATTENDANCEENTRIES.LIST");

		attendanceEntriesList.setTextContent(" ");

		Element oriInvoiceDetailsList = doc.createElement("ORIGINVOICEDETAILS.LIST");

		oriInvoiceDetailsList.setTextContent(" ");

		Element invoiceExportList = doc.createElement("INVOICEEXPORTLIST.LIST");

		invoiceExportList.setTextContent(" ");

		// Append the elements to the voucher element

		voucherElement.appendChild(eWayBillErrorList);

		voucherElement.appendChild(irnErrorList);

		voucherElement.appendChild(invoiceDelNotesList);

		voucherElement.appendChild(invoiceOrderList);

		voucherElement.appendChild(invoiceIndentList);

		voucherElement.appendChild(attendanceEntriesList);

		voucherElement.appendChild(oriInvoiceDetailsList);

		voucherElement.appendChild(invoiceExportList);

		// Ledger 1 final

		Element ledgerEntry1 = doc.createElement("LEDGERENTRIES.LIST");

		// I will use 1156, 57, 58,59, 60 for ledger 2 and ledger 3

		Element oldAuditList = doc.createElement("OLDAUDITENTRYIDS.LIST");

		oldAuditList.setAttribute("TYPE", "Number");

		Element oldAuditId = doc.createElement("OLDAUDITENTRYIDS");

		oldAuditId.setTextContent("-1");

		oldAuditList.appendChild(oldAuditId);

		ledgerEntry1.appendChild(oldAuditList);

		Element ledgername1 = doc.createElement("LEDGERNAME");

		ledgername1.setTextContent(voucherRequest.getLedgerEntry1().getLedgerName());

		ledgerEntry1.appendChild(ledgername1);

		// For GSTCLASS

		Element gstclass1 = doc.createElement("GSTCLASS");

		ledgerEntry1.appendChild(gstclass1);

		// For ISDEEMEDPOSITIVE

		Element isdeemedpositive1 = doc.createElement("ISDEEMEDPOSITIVE");

		isdeemedpositive1.setTextContent(voucherRequest.getLedgerEntry1().getIsDeemedPositive());

		ledgerEntry1.appendChild(isdeemedpositive1);

		// For LEDGERFROMITEM

		Element ledgerfromitem1 = doc.createElement("LEDGERFROMITEM");

		ledgerfromitem1.setTextContent(voucherRequest.getLedgerEntry1().getLedgerFromItem());

		ledgerEntry1.appendChild(ledgerfromitem1);

		// For REMOVEZEROENTRIES

		Element removezeroentries1 = doc.createElement("REMOVEZEROENTRIES");

		removezeroentries1.setTextContent(voucherRequest.getLedgerEntry1().getRemoveZeroEntries());

		ledgerEntry1.appendChild(removezeroentries1);

		// For ISPARTYLEDGER

		Element ispartyledger1 = doc.createElement("ISPARTYLEDGER");

		ispartyledger1.setTextContent(voucherRequest.getLedgerEntry1().getIsPartyLedger());

		ledgerEntry1.appendChild(ispartyledger1);

		// For ISLASTDEEMEDPOSITIVE

		Element islastdeemedpositive1 = doc.createElement("ISLASTDEEMEDPOSITIVE");

		islastdeemedpositive1.setTextContent(voucherRequest.getLedgerEntry1().getIsLastDeemedPositive());

		ledgerEntry1.appendChild(islastdeemedpositive1);

		// For ISCAPVATTAXALTERED

		Element iscapvattaxaltered1 = doc.createElement("ISCAPVATTAXALTERED");

		iscapvattaxaltered1.setTextContent(voucherRequest.getLedgerEntry1().getIsCapVatTaxAltered());

		ledgerEntry1.appendChild(iscapvattaxaltered1);

		// For ISCAPVATNOTCLAIMED

		Element iscapvatnotclaimed1 = doc.createElement("ISCAPVATNOTCLAIMED");

		iscapvatnotclaimed1.setTextContent(voucherRequest.getLedgerEntry1().getIsCapVatNotClaimed());

		ledgerEntry1.appendChild(iscapvatnotclaimed1);

		// For AMOUNT

		Element amount1 = doc.createElement("AMOUNT");

		amount1.setTextContent(String.valueOf(voucherRequest.getLedgerEntry1().getAmount()));

		ledgerEntry1.appendChild(amount1);

		Element serviceTaxDetailsList = doc.createElement("SERVICETAXDETAILS.LIST");

		serviceTaxDetailsList.setTextContent(" ");

		ledgerEntry1.appendChild(serviceTaxDetailsList);

		Element bankAllocationsList = doc.createElement("BANKALLOCATIONS.LIST");

		bankAllocationsList.setTextContent(" ");

		ledgerEntry1.appendChild(bankAllocationsList);

		Element billAllocationsList = doc.createElement("BILLALLOCATIONS.LIST");

		billAllocationsList.setTextContent(" ");

		ledgerEntry1.appendChild(billAllocationsList);

		Element interestCollectionList = doc.createElement("INTERESTCOLLECTION.LIST");

		interestCollectionList.setTextContent(" ");

		ledgerEntry1.appendChild(interestCollectionList);

		Element oldAuditEntriesList1 = doc.createElement("OLDAUDITENTRIES.LIST");

		oldAuditEntriesList1.setTextContent(" ");

		ledgerEntry1.appendChild(oldAuditEntriesList1);

		Element accountAuditEntriesList1 = doc.createElement("ACCOUNTAUDITENTRIES.LIST");

		accountAuditEntriesList1.setTextContent(" ");

		ledgerEntry1.appendChild(accountAuditEntriesList1);

		Element auditEntriesList1 = doc.createElement("AUDITENTRIES.LIST");

		auditEntriesList1.setTextContent(" ");

		ledgerEntry1.appendChild(auditEntriesList1);

		Element inputCRAAllocsList = doc.createElement("INPUTCRALLOCS.LIST");

		inputCRAAllocsList.setTextContent(" ");

		ledgerEntry1.appendChild(inputCRAAllocsList);

		Element dutyHeadDetailsList1 = doc.createElement("DUTYHEADDETAILS.LIST");

		dutyHeadDetailsList1.setTextContent(" ");

		ledgerEntry1.appendChild(dutyHeadDetailsList1);

		Element exciseDutyHeadDetailsList = doc.createElement("EXCISEDUTYHEADDETAILS.LIST");

		exciseDutyHeadDetailsList.setTextContent(" ");

		ledgerEntry1.appendChild(exciseDutyHeadDetailsList);

		Element rateDetailsList = doc.createElement("RATEDETAILS.LIST");

		rateDetailsList.setTextContent(" ");

		ledgerEntry1.appendChild(rateDetailsList);

		Element summaryAllocsList = doc.createElement("SUMMARYALLOCS.LIST");

		summaryAllocsList.setTextContent(" ");

		ledgerEntry1.appendChild(summaryAllocsList);

		Element stPymtDetailsList = doc.createElement("STPYMTDETAILS.LIST");

		stPymtDetailsList.setTextContent(" ");

		ledgerEntry1.appendChild(stPymtDetailsList);

		Element excisePymtAllocsList = doc.createElement("EXCISEPAYMENTALLOCATIONS.LIST");

		excisePymtAllocsList.setTextContent(" ");

		ledgerEntry1.appendChild(excisePymtAllocsList);

		Element taxBillAllocsList = doc.createElement("TAXBILLALLOCATIONS.LIST");

		taxBillAllocsList.setTextContent(" ");

		ledgerEntry1.appendChild(taxBillAllocsList);

		Element taxObjectAllocsList = doc.createElement("TAXOBJECTALLOCATIONS.LIST");

		taxObjectAllocsList.setTextContent(" ");

		ledgerEntry1.appendChild(taxObjectAllocsList);

		Element tdsExpenseAllocsList = doc.createElement("TDSEXPENSEALLOCATIONS.LIST");

		tdsExpenseAllocsList.setTextContent(" ");

		ledgerEntry1.appendChild(tdsExpenseAllocsList);

		Element vatStatutoryDetailsList = doc.createElement("VATSTATUTORYDETAILS.LIST");

		vatStatutoryDetailsList.setTextContent(" ");

		ledgerEntry1.appendChild(vatStatutoryDetailsList);

		Element costTrackAllocsList = doc.createElement("COSTTRACKALLOCATIONS.LIST");

		costTrackAllocsList.setTextContent(" ");

		ledgerEntry1.appendChild(costTrackAllocsList);

		Element refVoucherDetailsList = doc.createElement("REFVOUCHERDETAILS.LIST");

		refVoucherDetailsList.setTextContent(" ");

		ledgerEntry1.appendChild(refVoucherDetailsList);

		Element invoiceWiseDetailsList = doc.createElement("INVOICEWISEDETAILS.LIST");

		invoiceWiseDetailsList.setTextContent(" ");

		ledgerEntry1.appendChild(invoiceWiseDetailsList);

		Element vatItcDetailsList = doc.createElement("VATITCDETAILS.LIST");

		vatItcDetailsList.setTextContent(" ");

		ledgerEntry1.appendChild(vatItcDetailsList);

		Element advanceTaxDetailsList = doc.createElement("ADVANCETAXDETAILS.LIST");

		advanceTaxDetailsList.setTextContent(" ");

		ledgerEntry1.appendChild(advanceTaxDetailsList);

		voucherElement.appendChild(ledgerEntry1);

		// ledger entry 2 final

		Element ledgerEntry2 = doc.createElement("LEDGERENTRIES.LIST");

		Element oldAuditList2 = doc.createElement("OLDAUDITENTRYIDS.LIST");

		oldAuditList2.setAttribute("TYPE", "Number");

		Element oldAuditId2 = doc.createElement("OLDAUDITENTRYIDS");

		oldAuditId2.setTextContent("-1");

		oldAuditList2.appendChild(oldAuditId2);

		ledgerEntry2.appendChild(oldAuditList2);

		Element roundType2 = doc.createElement("ROUNDTYPE");

		roundType2.setTextContent(voucherRequest.getLedgerEntry2().getRoundType());

		ledgerEntry2.appendChild(roundType2);

		Element ledgername2 = doc.createElement("LEDGERNAME");

		ledgername2.setTextContent(voucherRequest.getLedgerEntry2().getLedgerName());

		ledgerEntry2.appendChild(ledgername2);

		Element methodName2 = doc.createElement("METHODTYPE");

		methodName2.setTextContent(voucherRequest.getLedgerEntry2().getMethodType());

		ledgerEntry2.appendChild(methodName2);

		// For GSTCLASS

		Element gstclass2 = doc.createElement("GSTCLASS");

		ledgerEntry2.appendChild(gstclass2);

		// For ISDEEMEDPOSITIVE

		Element isdeemedpositive2 = doc.createElement("ISDEEMEDPOSITIVE");

		isdeemedpositive2.setTextContent(voucherRequest.getLedgerEntry2().getIsDeemedPositive());

		ledgerEntry2.appendChild(isdeemedpositive2);

		// For LEDGERFROMITEM

		Element ledgerfromitem2 = doc.createElement("LEDGERFROMITEM");

		ledgerfromitem2.setTextContent(voucherRequest.getLedgerEntry2().getLedgerFromItem());

		ledgerEntry2.appendChild(ledgerfromitem2);

		// For REMOVEZEROENTRIES

		Element removezeroentries2 = doc.createElement("REMOVEZEROENTRIES");

		removezeroentries2.setTextContent(voucherRequest.getLedgerEntry2().getRemoveZeroEntries());

		ledgerEntry2.appendChild(removezeroentries2);

		// For ISPARTYLEDGER

		Element ispartyledger2 = doc.createElement("ISPARTYLEDGER");

		ispartyledger2.setTextContent(voucherRequest.getLedgerEntry2().getIsPartyLedger());

		ledgerEntry2.appendChild(ispartyledger2);

		// For ISLASTDEEMEDPOSITIVE

		Element islastdeemedpositive2 = doc.createElement("ISLASTDEEMEDPOSITIVE");

		islastdeemedpositive2.setTextContent(voucherRequest.getLedgerEntry2().getIsLastDeemedPositive());

		ledgerEntry2.appendChild(islastdeemedpositive2);

		// For ISCAPVATTAXALTERED

		Element iscapvattaxaltered2 = doc.createElement("ISCAPVATTAXALTERED");

		iscapvattaxaltered2.setTextContent(voucherRequest.getLedgerEntry2().getIsCapVatTaxAltered());

		ledgerEntry2.appendChild(iscapvattaxaltered2);

		// For ISCAPVATNOTCLAIMED

		Element iscapvatnotclaimed2 = doc.createElement("ISCAPVATNOTCLAIMED");

		iscapvatnotclaimed2.setTextContent(voucherRequest.getLedgerEntry2().getIsCapVatNotClaimed());

		ledgerEntry2.appendChild(iscapvatnotclaimed2);

		// For AMOUNT

		Element amount2 = doc.createElement("AMOUNT");

		amount2.setTextContent(String.valueOf(voucherRequest.getLedgerEntry2().getAmount()));

		ledgerEntry2.appendChild(amount2);

		// vatex

		Element vatexp2 = doc.createElement("VATEXPAMOUNT");

		vatexp2.setTextContent(String.valueOf(voucherRequest.getLedgerEntry2().getVatExpAmount()));

		ledgerEntry2.appendChild(vatexp2);

		Element serviceTaxDetailsList2 = doc.createElement("SERVICETAXDETAILS.LIST");

		serviceTaxDetailsList2.setTextContent(" ");

		ledgerEntry2.appendChild(serviceTaxDetailsList2);

		Element bankAllocationsList2 = doc.createElement("BANKALLOCATIONS.LIST");

		bankAllocationsList2.setTextContent(" ");

		ledgerEntry2.appendChild(bankAllocationsList2);

		Element billAllocationsList2 = doc.createElement("BILLALLOCATIONS.LIST");

		billAllocationsList2.setTextContent(" ");

		ledgerEntry2.appendChild(billAllocationsList2);

		Element interestCollectionList2 = doc.createElement("INTERESTCOLLECTION.LIST");

		interestCollectionList2.setTextContent(" ");

		ledgerEntry2.appendChild(interestCollectionList2);

		Element oldAuditEntriesList2 = doc.createElement("OLDAUDITENTRIES.LIST");

		oldAuditEntriesList2.setTextContent(" ");

		ledgerEntry2.appendChild(oldAuditEntriesList2);

		Element accountAuditEntriesList2 = doc.createElement("ACCOUNTAUDITENTRIES.LIST");

		accountAuditEntriesList2.setTextContent(" ");

		ledgerEntry2.appendChild(accountAuditEntriesList2);

		Element auditEntriesList2 = doc.createElement("AUDITENTRIES.LIST");

		auditEntriesList2.setTextContent(" ");

		ledgerEntry2.appendChild(auditEntriesList2);

		Element inputCRAAllocsList2 = doc.createElement("INPUTCRALLOCS.LIST");

		inputCRAAllocsList2.setTextContent(" ");

		ledgerEntry2.appendChild(inputCRAAllocsList2);

		Element dutyHeadDetailsList2 = doc.createElement("DUTYHEADDETAILS.LIST");

		dutyHeadDetailsList2.setTextContent(" ");

		ledgerEntry2.appendChild(dutyHeadDetailsList2);

		Element exciseDutyHeadDetailsList2 = doc.createElement("EXCISEDUTYHEADDETAILS.LIST");

		exciseDutyHeadDetailsList2.setTextContent(" ");

		ledgerEntry2.appendChild(exciseDutyHeadDetailsList2);

		Element rateDetailsList2 = doc.createElement("RATEDETAILS.LIST");

		rateDetailsList2.setTextContent(" ");

		ledgerEntry2.appendChild(rateDetailsList2);

		Element summaryAllocsList2 = doc.createElement("SUMMARYALLOCS.LIST");

		summaryAllocsList2.setTextContent(" ");

		ledgerEntry2.appendChild(summaryAllocsList2);

		Element stPymtDetailsList2 = doc.createElement("STPYMTDETAILS.LIST");

		stPymtDetailsList2.setTextContent(" ");

		ledgerEntry2.appendChild(stPymtDetailsList2);

		Element excisePymtAllocsList2 = doc.createElement("EXCISEPAYMENTALLOCATIONS.LIST");

		excisePymtAllocsList2.setTextContent(" ");

		ledgerEntry2.appendChild(excisePymtAllocsList2);

		Element taxBillAllocsList2 = doc.createElement("TAXBILLALLOCATIONS.LIST");

		taxBillAllocsList2.setTextContent(" ");

		ledgerEntry2.appendChild(taxBillAllocsList2);

		Element taxObjectAllocsList2 = doc.createElement("TAXOBJECTALLOCATIONS.LIST");

		taxObjectAllocsList2.setTextContent(" ");

		ledgerEntry2.appendChild(taxObjectAllocsList2);

		Element tdsExpenseAllocsList2 = doc.createElement("TDSEXPENSEALLOCATIONS.LIST");

		tdsExpenseAllocsList2.setTextContent(" ");

		ledgerEntry2.appendChild(tdsExpenseAllocsList2);

		Element vatStatutoryDetailsList2 = doc.createElement("VATSTATUTORYDETAILS.LIST");

		vatStatutoryDetailsList2.setTextContent(" ");

		ledgerEntry2.appendChild(vatStatutoryDetailsList2);

		Element costTrackAllocsList2 = doc.createElement("COSTTRACKALLOCATIONS.LIST");

		costTrackAllocsList2.setTextContent(" ");

		ledgerEntry2.appendChild(costTrackAllocsList2);

		Element refVoucherDetailsList2 = doc.createElement("REFVOUCHERDETAILS.LIST");

		refVoucherDetailsList2.setTextContent(" ");

		ledgerEntry2.appendChild(refVoucherDetailsList2);

		Element invoiceWiseDetailsList2 = doc.createElement("INVOICEWISEDETAILS.LIST");

		invoiceWiseDetailsList2.setTextContent(" ");

		ledgerEntry2.appendChild(invoiceWiseDetailsList2);

		Element vatItcDetailsList2 = doc.createElement("VATITCDETAILS.LIST");

		vatItcDetailsList2.setTextContent(" ");

		ledgerEntry2.appendChild(vatItcDetailsList2);

		Element advanceTaxDetailsList2 = doc.createElement("ADVANCETAXDETAILS.LIST");

		advanceTaxDetailsList2.setTextContent(" ");

		ledgerEntry2.appendChild(advanceTaxDetailsList2);

		voucherElement.appendChild(ledgerEntry2);

		// for 3rd ledgerEntry

		Element ledgerEntry3 = doc.createElement("LEDGERENTRIES.LIST");

		Element oldAuditList3 = doc.createElement("OLDAUDITENTRYIDS.LIST");

		oldAuditList3.setAttribute("TYPE", "Number");

		Element oldAuditId3 = doc.createElement("OLDAUDITENTRYIDS");

		oldAuditId3.setTextContent("-1");

		oldAuditList3.appendChild(oldAuditId3);

		ledgerEntry3.appendChild(oldAuditList3);

		Element roundType3 = doc.createElement("ROUNDTYPE");

		roundType3.setTextContent(voucherRequest.getLedgerEntry3().getRoundType());

		ledgerEntry3.appendChild(roundType3);

		Element ledgername3 = doc.createElement("LEDGERNAME");

		ledgername3.setTextContent(voucherRequest.getLedgerEntry3().getLedgerName());

		ledgerEntry3.appendChild(ledgername3);

		Element methodName3 = doc.createElement("METHODTYPE");

		methodName3.setTextContent(voucherRequest.getLedgerEntry3().getMethodType());

		ledgerEntry3.appendChild(methodName3);

		// For GSTCLASS

		Element gstclass3 = doc.createElement("GSTCLASS");

		ledgerEntry3.appendChild(gstclass3);

		// For ISDEEMEDPOSITIVE

		Element isdeemedpositive3 = doc.createElement("ISDEEMEDPOSITIVE");

		isdeemedpositive3.setTextContent(voucherRequest.getLedgerEntry3().getIsDeemedPositive());

		ledgerEntry3.appendChild(isdeemedpositive3);

		// For LEDGERFROMITEM

		Element ledgerfromitem3 = doc.createElement("LEDGERFROMITEM");

		ledgerfromitem3.setTextContent(voucherRequest.getLedgerEntry3().getLedgerFromItem());

		ledgerEntry3.appendChild(ledgerfromitem3);

		// For REMOVEZEROENTRIES

		Element removezeroentries3 = doc.createElement("REMOVEZEROENTRIES");

		removezeroentries3.setTextContent(voucherRequest.getLedgerEntry3().getRemoveZeroEntries());

		ledgerEntry3.appendChild(removezeroentries3);

		// For ISPARTYLEDGER

		Element ispartyledger3 = doc.createElement("ISPARTYLEDGER");

		ispartyledger3.setTextContent(voucherRequest.getLedgerEntry3().getIsPartyLedger());

		ledgerEntry3.appendChild(ispartyledger3);

		// For ISLASTDEEMEDPOSITIVE

		Element islastdeemedpositive3 = doc.createElement("ISLASTDEEMEDPOSITIVE");

		islastdeemedpositive3.setTextContent(voucherRequest.getLedgerEntry3().getIsLastDeemedPositive());

		ledgerEntry3.appendChild(islastdeemedpositive3);

		// For ISCAPVATTAXALTERED

		Element iscapvattaxaltered3 = doc.createElement("ISCAPVATTAXALTERED");

		iscapvattaxaltered3.setTextContent(voucherRequest.getLedgerEntry3().getIsCapVatTaxAltered());

		ledgerEntry3.appendChild(iscapvattaxaltered3);

		// For ISCAPVATNOTCLAIMED

		Element iscapvatnotclaimed3 = doc.createElement("ISCAPVATNOTCLAIMED");

		iscapvatnotclaimed3.setTextContent(voucherRequest.getLedgerEntry3().getIsCapVatNotClaimed());

		ledgerEntry3.appendChild(iscapvatnotclaimed3);

		// roundlimit

		Element roundLimit3 = doc.createElement("ROUNDLIMIT");

		roundLimit3.setTextContent(voucherRequest.getLedgerEntry3().getRoundLimit());

		ledgerEntry3.appendChild(roundLimit3);

		// For AMOUNT

		Element amount3 = doc.createElement("AMOUNT");

		amount3.setTextContent(String.valueOf(voucherRequest.getLedgerEntry3().getAmount()));

		ledgerEntry3.appendChild(amount3);

		// vatex

		Element vatexp3 = doc.createElement("VATEXPAMOUNT");

		vatexp3.setTextContent(String.valueOf(voucherRequest.getLedgerEntry3().getVatExpAmount()));

		ledgerEntry3.appendChild(vatexp3);

		Element serviceTaxDetailsList3 = doc.createElement("SERVICETAXDETAILS.LIST");

		serviceTaxDetailsList3.setTextContent(" ");

		ledgerEntry3.appendChild(serviceTaxDetailsList3);

		Element bankAllocationsList3 = doc.createElement("BANKALLOCATIONS.LIST");

		bankAllocationsList3.setTextContent(" ");

		ledgerEntry3.appendChild(bankAllocationsList3);

		Element billAllocationsList3 = doc.createElement("BILLALLOCATIONS.LIST");

		billAllocationsList3.setTextContent(" ");

		ledgerEntry3.appendChild(billAllocationsList3);

		Element interestCollectionList3 = doc.createElement("INTERESTCOLLECTION.LIST");

		interestCollectionList3.setTextContent(" ");

		ledgerEntry3.appendChild(interestCollectionList3);

		Element oldAuditEntriesList3 = doc.createElement("OLDAUDITENTRIES.LIST");

		oldAuditEntriesList3.setTextContent(" ");

		ledgerEntry3.appendChild(oldAuditEntriesList3);

		Element accountAuditEntriesList3 = doc.createElement("ACCOUNTAUDITENTRIES.LIST");

		accountAuditEntriesList3.setTextContent(" ");

		ledgerEntry3.appendChild(accountAuditEntriesList3);

		Element auditEntriesList3 = doc.createElement("AUDITENTRIES.LIST");

		auditEntriesList3.setTextContent(" ");

		ledgerEntry3.appendChild(auditEntriesList3);

		Element inputCRAAllocsList3 = doc.createElement("INPUTCRALLOCS.LIST");

		inputCRAAllocsList3.setTextContent(" ");

		ledgerEntry3.appendChild(inputCRAAllocsList3);

		Element dutyHeadDetailsList3 = doc.createElement("DUTYHEADDETAILS.LIST");

		dutyHeadDetailsList3.setTextContent(" ");

		ledgerEntry3.appendChild(dutyHeadDetailsList3);

		Element exciseDutyHeadDetailsList3 = doc.createElement("EXCISEDUTYHEADDETAILS.LIST");

		exciseDutyHeadDetailsList3.setTextContent(" ");

		ledgerEntry3.appendChild(exciseDutyHeadDetailsList3);

		Element rateDetailsList3 = doc.createElement("RATEDETAILS.LIST");

		rateDetailsList3.setTextContent(" ");

		ledgerEntry3.appendChild(rateDetailsList3);

		Element summaryAllocsList3 = doc.createElement("SUMMARYALLOCS.LIST");

		summaryAllocsList3.setTextContent(" ");

		ledgerEntry3.appendChild(summaryAllocsList3);

		Element stPymtDetailsList3 = doc.createElement("STPYMTDETAILS.LIST");

		stPymtDetailsList3.setTextContent(" ");

		ledgerEntry3.appendChild(stPymtDetailsList3);

		Element excisePymtAllocsList3 = doc.createElement("EXCISEPAYMENTALLOCATIONS.LIST");

		excisePymtAllocsList3.setTextContent(" ");

		ledgerEntry3.appendChild(excisePymtAllocsList3);

		Element taxBillAllocsList3 = doc.createElement("TAXBILLALLOCATIONS.LIST");

		taxBillAllocsList3.setTextContent(" ");

		ledgerEntry3.appendChild(taxBillAllocsList3);

		Element taxObjectAllocsList3 = doc.createElement("TAXOBJECTALLOCATIONS.LIST");

		taxObjectAllocsList3.setTextContent(" ");

		ledgerEntry3.appendChild(taxObjectAllocsList3);

		Element tdsExpenseAllocsList3 = doc.createElement("TDSEXPENSEALLOCATIONS.LIST");

		tdsExpenseAllocsList3.setTextContent(" ");

		ledgerEntry3.appendChild(tdsExpenseAllocsList3);

		Element vatStatutoryDetailsList3 = doc.createElement("VATSTATUTORYDETAILS.LIST");

		vatStatutoryDetailsList3.setTextContent(" ");

		ledgerEntry3.appendChild(vatStatutoryDetailsList3);

		Element costTrackAllocsList3 = doc.createElement("COSTTRACKALLOCATIONS.LIST");

		costTrackAllocsList3.setTextContent(" ");

		ledgerEntry3.appendChild(costTrackAllocsList3);

		Element refVoucherDetailsList3 = doc.createElement("REFVOUCHERDETAILS.LIST");

		refVoucherDetailsList3.setTextContent(" ");

		ledgerEntry3.appendChild(refVoucherDetailsList3);

		Element invoiceWiseDetailsList3 = doc.createElement("INVOICEWISEDETAILS.LIST");

		invoiceWiseDetailsList3.setTextContent(" ");

		ledgerEntry3.appendChild(invoiceWiseDetailsList3);

		Element vatItcDetailsList3 = doc.createElement("VATITCDETAILS.LIST");

		vatItcDetailsList3.setTextContent(" ");

		ledgerEntry3.appendChild(vatItcDetailsList3);

		Element advanceTaxDetailsList3 = doc.createElement("ADVANCETAXDETAILS.LIST");

		advanceTaxDetailsList3.setTextContent(" ");

		ledgerEntry3.appendChild(advanceTaxDetailsList3);

		voucherElement.appendChild(ledgerEntry3);

		Element payrollModeOfPayment = doc.createElement("PAYROLLMODEOFPAYMENT.LIST");

		payrollModeOfPayment.setTextContent(" ");

		voucherElement.appendChild(payrollModeOfPayment);

		Element attdRecords = doc.createElement("ATTDRECORDS.LIST");

		attdRecords.setTextContent(" ");

		voucherElement.appendChild(attdRecords);

		Element gstWayConsignorAddress = doc.createElement("GSTEWAYCONSIGNORADDRESS.LIST");

		gstWayConsignorAddress.setTextContent(" ");

		voucherElement.appendChild(gstWayConsignorAddress);

		Element gstWayConsigneeAddress = doc.createElement("GSTEWAYCONSIGNEEADDRESS.LIST");

		gstWayConsigneeAddress.setTextContent(" ");

		voucherElement.appendChild(gstWayConsigneeAddress);

		Element tempGstRatedDetails = doc.createElement("TEMPGSTRATEDETAILS.LIST");

		tempGstRatedDetails.setTextContent(" ");

		voucherElement.appendChild(tempGstRatedDetails);

		Element udfList = doc.createElement("UDF:VCHCREATEONCC.LIST");

		udfList.setAttribute("DESC", "`VchCreateOnCC`");

		udfList.setAttribute("ISLIST", "YES`");

		udfList.setAttribute("TYPE", "Date");

		udfList.setAttribute("INDEX", "6007`");

		Element udf = doc.createElement("UDF:VCHCREATEONCC");

		udf.setAttribute("DESC", "`VchCreateOnCC`");

		udf.setTextContent(voucherRequest.getDate());

		udfList.appendChild(udf);

		voucherElement.appendChild(udfList);

		Node refNode = doc.getElementsByTagName("TALLYMESSAGE").item(0);

		rootElement.insertBefore(tallyMessageElement, refNode);

		// Add the new TALLYMESSAGE to the root element of the document

		// rootElement.appendChild(tallyMessageElement);

		// Return the modified XML as a string

		TransformerFactory transformerFactory = TransformerFactory.newInstance();

		Transformer transformer = transformerFactory.newTransformer();

		transformer.setOutputProperty(OutputKeys.INDENT, "yes");

		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-16LE");

		StringWriter writer = new StringWriter();

		transformer.transform(new DOMSource(doc), new StreamResult(writer));

		String xmlString = writer.getBuffer().toString();

		return xmlString;

	}

	public List<VoucherRequest> generatePayloadForMultipleVoucher() {

		List<VoucherRequest> voucherRequestList = new ArrayList<VoucherRequest>();

		List<OrderResponseDto> orderResponseDtoList = orderService.listNewOrdersListNotinTally();

		Double finalAmountWithGst;

		float ledger3amount = -0.40f;

		Date dateToFill = new Date();

		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

		SimpleDateFormat formatter2 = new SimpleDateFormat("yyyyMMdd");

		SimpleDateFormat formatter3 = new SimpleDateFormat("yyyyMMddHHmmss000");

		SimpleDateFormat formatter4 = new SimpleDateFormat("dd-MMM-yy");

		String convertedDate;

		for (OrderResponseDto orderResponseDto : orderResponseDtoList) {

			VoucherRequest voucherRequest = new VoucherRequest();

			dateToFill = orderResponseDto.getOrderDate();

			System.out.println(dateToFill);

			convertedDate = formatter4.format(dateToFill);

			System.out.println(convertedDate);

			finalAmountWithGst = orderResponseDto.getFinalAmount().doubleValue()
					+ (orderResponseDto.getFinalAmount().doubleValue() * 18) / 100;

			List<String> addresses = new ArrayList<String>();

			// addresses.add(orderResponseDto.getCustomer().getAddressLine1());

			// addresses.add(orderResponseDto.getCustomer().getAddressLine2());

			// addresses.add(orderResponseDto.getCustomer().getAddressLine3());

			// addresses.add(orderResponseDto.getCustomer().getAddressLine4());

			addresses.add(orderResponseDto.getD_AddressLine1());

			addresses.add(orderResponseDto.getD_AddressLine2());

			addresses.add(orderResponseDto.getD_AddressLine3());

			addresses.add(orderResponseDto.getD_AddressLine4());

			voucherRequest.setAddress(addresses);

			List<String> basicBuyerAddresses = new ArrayList<String>();

			basicBuyerAddresses.add(orderResponseDto.getD_AddressLine1());

			basicBuyerAddresses.add(orderResponseDto.getD_AddressLine2());

			basicBuyerAddresses.add(orderResponseDto.getD_AddressLine3());

			basicBuyerAddresses.add(orderResponseDto.getD_AddressLine4());

			voucherRequest.setBasicBuyerAddress(basicBuyerAddresses);

			voucherRequest.setPartyGSTIN(orderResponseDto.getGst());

			voucherRequest.setConsigneeGstin(orderResponseDto.getGst());

			//date

			voucherRequest.setDate(formatter2.format(dateToFill));

			voucherRequest.setEffectiveDate(formatter2.format(dateToFill));

			voucherRequest.setUpdatedDateTime(formatter3.format(dateToFill));

			//voucherRequest.setUpdatedDateTime(orderResponseDto.getOrderDate().toString());

			voucherRequest.setStateName(orderResponseDto.getD_State());

			voucherRequest.setConsigneeStateName(orderResponseDto.getD_State());

			voucherRequest.setPlaceOfSupply(orderResponseDto.getD_State());

			voucherRequest.setConsigneeCountryName(orderResponseDto.getD_Country());

			voucherRequest.setCountryOfResidence(orderResponseDto.getD_Country());

			voucherRequest.setConsigneePincode(orderResponseDto.getD_Pincode().toString());

			voucherRequest.setPartyPincode(orderResponseDto.getD_Pincode().toString());

			voucherRequest.setPartyLedgerName(orderResponseDto.getCustomer().getName());

			voucherRequest.setPartyMailingName(orderResponseDto.getCustomer().getName());

			voucherRequest.setPartyName(orderResponseDto.getCustomer().getName());

			voucherRequest.setBasicBasePartyName(orderResponseDto.getCustomer().getName());

			voucherRequest.setBasicBuyerName(orderResponseDto.getCustomer().getName());

			voucherRequest.setConsigneeMailingName(orderResponseDto.getCustomer().getName());

			voucherRequest.setReference(orderResponseDto.getOrderNumber());

			voucherRequest.setVoucherNumber(orderResponseDto.getOrderNumber());

			voucherRequest.setNarration(orderResponseDto.getNarration());

			LedgerEntryLast ledgerEntryLast1 = new LedgerEntryLast();

			ledgerEntryLast1.setLedgerName(orderResponseDto.getCustomer().getName());

			ledgerEntryLast1.setAmount((Math.round(-finalAmountWithGst) * 100 / 100));

			ledgerEntryLast1.setIsDeemedPositive("Yes");

			ledgerEntryLast1.setLedgerFromItem("No");

			ledgerEntryLast1.setRemoveZeroEntries("No");

			ledgerEntryLast1.setIsPartyLedger("Yes");

			ledgerEntryLast1.setIsLastDeemedPositive("Yes");

			voucherRequest.setLedgerEntry1(ledgerEntryLast1);

			LedgerEntryLast ledgerEntryLast2 = new LedgerEntryLast();

			ledgerEntryLast2.setLedgerName("IGST @ 18%");

			ledgerEntryLast2.setRoundType("Normal Rounding");

			ledgerEntryLast2.setIsDeemedPositive("No");

			ledgerEntryLast2.setLedgerFromItem("No");

			ledgerEntryLast2.setRemoveZeroEntries("Yes");

			ledgerEntryLast2.setIsPartyLedger("No");

			ledgerEntryLast2.setMethodType("GST");

			ledgerEntryLast1.setIsLastDeemedPositive("No");

			ledgerEntryLast2
			.setAmount(Math.round((orderResponseDto.getFinalAmount().doubleValue() * 18) / 100) * 100 / 100);

			ledgerEntryLast2.setVatExpAmount(
					Math.round((orderResponseDto.getFinalAmount().doubleValue() * 18) / 100) * 100 / 100);

			voucherRequest.setLedgerEntry2(ledgerEntryLast2);

			LedgerEntryLast ledgerEntryLast3 = new LedgerEntryLast();

			ledgerEntryLast3.setLedgerName("Round Off(S)");

			ledgerEntryLast3.setRoundType("Normal Rounding");

			ledgerEntryLast3.setIsDeemedPositive("No");

			ledgerEntryLast3.setLedgerFromItem("No");

			ledgerEntryLast3.setRemoveZeroEntries("Yes");

			ledgerEntryLast3.setIsPartyLedger("No");

			ledgerEntryLast3.setMethodType("GST");

			ledgerEntryLast3.setIsLastDeemedPositive("No");

			ledgerEntryLast3.setRoundLimit("1");

			ledgerEntryLast3.setAmount(Math.round(ledger3amount) * 100 / 100);

			ledgerEntryLast3.setVatExpAmount(Math.round(ledger3amount) * 100 / 100);

			voucherRequest.setLedgerEntry3(ledgerEntryLast3);

			List<AllInventoryList> inventoryList = new ArrayList<AllInventoryList>();

			for (OrderProductResponseDto orderProductResponseDto : orderResponseDto.getOrderProducts()) {

				AllInventoryList inventory = new AllInventoryList();

				inventory.setStockItemName(orderProductResponseDto.getProductName());

				inventory.setActualQty(
						orderProductResponseDto.getQuantity() + ".000 " + orderProductResponseDto.getUnit());

				inventory.setBilledQty(
						orderProductResponseDto.getQuantity() + ".000 " + orderProductResponseDto.getUnit());

				inventory.setDiscount(String.valueOf(orderProductResponseDto.getDiscount()));

				inventory.setRate(
						String.valueOf(orderProductResponseDto.getRate()) + "/" + orderProductResponseDto.getUnit());

				inventory.setDiscount(String.valueOf(orderProductResponseDto.getDiscount()));

				inventory.setAmount(String.valueOf(orderProductResponseDto.getAmount()));

				BatchAllocation batchAllocations = new BatchAllocation();

				batchAllocations.setOrderNo(orderResponseDto.getOrderNumber());

				batchAllocations.setActualQty(
						orderProductResponseDto.getQuantity() + ".000 " + orderProductResponseDto.getUnit());

				batchAllocations.setBilledQty(
						orderProductResponseDto.getQuantity() + ".000 " + orderProductResponseDto.getUnit());

				batchAllocations.setAmount(String.valueOf(orderProductResponseDto.getAmount()));

				batchAllocations.setOrderDueDate(formatter4.format(dateToFill));

				inventory.setBatchAllocations(batchAllocations);

				AccountingAllocation accountingAllocations = new AccountingAllocation();

				accountingAllocations.setAmount(String.valueOf(orderProductResponseDto.getAmount()));

				inventory.setAccountingAllocations(accountingAllocations);

				DutyHeadDetail dutyHeadDetails = new DutyHeadDetail();

				inventory.setDutyHeadDetails(dutyHeadDetails);

				List<ExpenseAllocationList> expenseList = new ArrayList<ExpenseAllocationList>();

				ExpenseAllocationList expense1 = new ExpenseAllocationList();

				expense1.setLedgerName("Courier Charges(G)");

				expenseList.add(expense1);

				ExpenseAllocationList expense2 = new ExpenseAllocationList();

				expense2.setLedgerName("Transport Charges (G)");

				expenseList.add(expense2);

				inventory.setExpenseAllocationList(expenseList);

				inventoryList.add(inventory);

			}

			voucherRequest.setAllInventoryList(inventoryList);

			voucherRequestList.add(voucherRequest);

		}

		return voucherRequestList;

	}

	public List<VoucherRequest> generatePayloadForSingleVoucher(Long Id) {

		List<VoucherRequest> voucherRequestList = new ArrayList<VoucherRequest>();

		OrderResponseDto orderResponseDtofromId = orderService.getOrderResponseById(Id).get();

		List<OrderResponseDto> orderResponseDtoList = new ArrayList<OrderResponseDto>();

		orderResponseDtoList.add(orderResponseDtofromId);

		//List<OrderResponseDto> orderResponseDtoList = orderService.listNewOrdersListNotinTally();

		Double finalAmountWithGst;

		float ledger3amount = 0.40f;

		for (OrderResponseDto orderResponseDto : orderResponseDtoList) {

			VoucherRequest voucherRequest = new VoucherRequest();

			finalAmountWithGst = orderResponseDto.getFinalAmount().doubleValue()
					+ (orderResponseDto.getFinalAmount().doubleValue() * 18) / 100;

			List<String> addresses = new ArrayList<String>();

			addresses.add(orderResponseDto.getCustomer().getAddressLine1());

			addresses.add(orderResponseDto.getCustomer().getAddressLine2());

			addresses.add(orderResponseDto.getCustomer().getAddressLine3());

			addresses.add(orderResponseDto.getCustomer().getAddressLine4());

			voucherRequest.setAddress(addresses);

			List<String> basicBuyerAddresses = new ArrayList<String>();

			basicBuyerAddresses.add(orderResponseDto.getD_AddressLine1());

			basicBuyerAddresses.add(orderResponseDto.getD_AddressLine2());

			basicBuyerAddresses.add(orderResponseDto.getD_AddressLine3());

			basicBuyerAddresses.add(orderResponseDto.getD_AddressLine4());

			voucherRequest.setBasicBuyerAddress(basicBuyerAddresses);

			voucherRequest.setPartyGSTIN(orderResponseDto.getCustomer().getGstin());

			voucherRequest.setConsigneeGstin(orderResponseDto.getCustomer().getGstin());

			//date

			voucherRequest.setDate(orderResponseDto.getOrderDate().toString());

			voucherRequest.setEffectiveDate(orderResponseDto.getOrderDate().toString());

			//voucherRequest.setUpdatedDateTime(orderResponseDto.getOrderDate().toString());

			voucherRequest.setStateName(orderResponseDto.getD_State());

			voucherRequest.setConsigneeStateName(orderResponseDto.getD_State());

			voucherRequest.setPlaceOfSupply(orderResponseDto.getD_State());

			voucherRequest.setConsigneeCountryName(orderResponseDto.getD_Country());

			voucherRequest.setCountryOfResidence(orderResponseDto.getD_Country());

			voucherRequest.setConsigneePincode(orderResponseDto.getD_Pincode().toString());

			voucherRequest.setPartyPincode(orderResponseDto.getD_Pincode().toString());

			voucherRequest.setPartyLedgerName(orderResponseDto.getCustomer().getName());

			voucherRequest.setPartyMailingName(orderResponseDto.getCustomer().getName());

			voucherRequest.setPartyName(orderResponseDto.getCustomer().getName());

			voucherRequest.setBasicBasePartyName(orderResponseDto.getCustomer().getName());

			voucherRequest.setBasicBuyerName(orderResponseDto.getCustomer().getName());

			voucherRequest.setConsigneeMailingName(orderResponseDto.getCustomer().getName());

			voucherRequest.setReference(orderResponseDto.getOrderNumber());

			voucherRequest.setVoucherNumber(orderResponseDto.getOrderNumber());

			voucherRequest.setNarration(orderResponseDto.getNarration());

			LedgerEntryLast ledgerEntryLast1 = new LedgerEntryLast();

			ledgerEntryLast1.setLedgerName(orderResponseDto.getCustomer().getName());

			ledgerEntryLast1.setAmount((Math.round(-finalAmountWithGst) * 100 / 100));

			ledgerEntryLast1.setIsDeemedPositive("Yes");

			ledgerEntryLast1.setLedgerFromItem("No");

			ledgerEntryLast1.setRemoveZeroEntries("No");

			ledgerEntryLast1.setIsPartyLedger("Yes");

			ledgerEntryLast1.setIsLastDeemedPositive("Yes");

			voucherRequest.setLedgerEntry1(ledgerEntryLast1);

			LedgerEntryLast ledgerEntryLast2 = new LedgerEntryLast();

			ledgerEntryLast2.setLedgerName("IGST @ 18%");

			ledgerEntryLast2.setRoundType("Normal Rounding");

			ledgerEntryLast2.setIsDeemedPositive("No");

			ledgerEntryLast2.setLedgerFromItem("No");

			ledgerEntryLast2.setRemoveZeroEntries("Yes");

			ledgerEntryLast2.setIsPartyLedger("No");

			ledgerEntryLast2.setMethodType("GST");

			ledgerEntryLast2.setIsLastDeemedPositive("No");

			ledgerEntryLast2
			.setAmount(Math.round((orderResponseDto.getFinalAmount().doubleValue() * 18) / 100) * 100 / 100);

			ledgerEntryLast2.setVatExpAmount(
					Math.round((orderResponseDto.getFinalAmount().doubleValue() * 18) / 100) * 100 / 100);

			voucherRequest.setLedgerEntry2(ledgerEntryLast2);

			LedgerEntryLast ledgerEntryLast3 = new LedgerEntryLast();

			ledgerEntryLast3.setLedgerName("Round Off(S)");

			ledgerEntryLast3.setRoundType("Normal Rounding");

			ledgerEntryLast3.setIsDeemedPositive("No");

			ledgerEntryLast3.setLedgerFromItem("No");

			ledgerEntryLast3.setRemoveZeroEntries("Yes");

			ledgerEntryLast3.setIsPartyLedger("No");

			ledgerEntryLast3.setMethodType("GST");

			ledgerEntryLast3.setIsLastDeemedPositive("No");

			ledgerEntryLast3.setRoundLimit("1");

			ledgerEntryLast3.setAmount(Math.round(ledger3amount) * 100 / 100);

			ledgerEntryLast3.setVatExpAmount(Math.round(ledger3amount) * 100 / 100);

			voucherRequest.setLedgerEntry3(ledgerEntryLast3);

			List<AllInventoryList> inventoryList = new ArrayList<AllInventoryList>();

			for (OrderProductResponseDto orderProductResponseDto : orderResponseDto.getOrderProducts()) {

				AllInventoryList inventory = new AllInventoryList();

				inventory.setStockItemName(orderProductResponseDto.getProductName());

				inventory.setActualQty(
						orderProductResponseDto.getQuantity() + ".000 " + orderProductResponseDto.getUnit());

				inventory.setBilledQty(
						orderProductResponseDto.getQuantity() + ".000 " + orderProductResponseDto.getUnit());

				inventory.setDiscount(String.valueOf(orderProductResponseDto.getDiscount()));

				inventory.setRate(
						String.valueOf(orderProductResponseDto.getRate()) + "/" + orderProductResponseDto.getUnit());

				inventory.setDiscount(String.valueOf(orderProductResponseDto.getDiscount()));

				inventory.setAmount(String.valueOf(orderProductResponseDto.getAmount()));

				BatchAllocation batchAllocations = new BatchAllocation();

				batchAllocations.setOrderNo(orderResponseDto.getOrderNumber());

				batchAllocations.setActualQty(
						orderProductResponseDto.getQuantity() + ".000 " + orderProductResponseDto.getUnit());

				batchAllocations.setBilledQty(
						orderProductResponseDto.getQuantity() + ".000 " + orderProductResponseDto.getUnit());

				batchAllocations.setAmount(String.valueOf(orderProductResponseDto.getAmount()));

				batchAllocations.setOrderDueDate(orderResponseDto.getOrderDate().toString());

				inventory.setBatchAllocations(batchAllocations);

				AccountingAllocation accountingAllocations = new AccountingAllocation();

				accountingAllocations.setAmount(String.valueOf(orderProductResponseDto.getAmount()));

				inventory.setAccountingAllocations(accountingAllocations);

				DutyHeadDetail dutyHeadDetails = new DutyHeadDetail();

				inventory.setDutyHeadDetails(dutyHeadDetails);

				List<ExpenseAllocationList> expenseList = new ArrayList<ExpenseAllocationList>();

				ExpenseAllocationList expense1 = new ExpenseAllocationList();

				expense1.setLedgerName("Courier Charges(G)");

				expenseList.add(expense1);

				ExpenseAllocationList expense2 = new ExpenseAllocationList();

				expense2.setLedgerName("Transport Charges (G)");

				expenseList.add(expense2);

				inventory.setExpenseAllocationList(expenseList);

				inventoryList.add(inventory);

			}

			voucherRequest.setAllInventoryList(inventoryList);

			voucherRequestList.add(voucherRequest);

		}

		return voucherRequestList;

	}

}
