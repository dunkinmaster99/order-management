package com.draft.kshitijDemo1.model;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="STATUS")
public class Status {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name = "STATUS_ID", updatable = false)
private Long statusId;
@Column(name="STATUS_NAME")
private String value;

}
