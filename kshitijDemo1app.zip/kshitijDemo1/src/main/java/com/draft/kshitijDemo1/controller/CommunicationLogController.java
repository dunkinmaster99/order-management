package com.draft.kshitijDemo1.controller;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.draft.kshitijDemo1.model.Order;
import com.draft.kshitijDemo1.requestDto.CommunicationLogRequestDto;
import com.draft.kshitijDemo1.service.CommunicationLogService;
import com.draft.kshitijDemo1.service.CustomException;
import com.draft.kshitijDemo1.util.ApiResponse;
import com.draft.kshitijDemo1.util.ErrorResponse;
import com.draft.kshitijDemo1.util.MsgConstant;
import com.draft.kshitijDemo1.util.ResponseBodyUtil;

import lombok.extern.slf4j.Slf4j;

@RequestMapping("communicationLog")
@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:4200/")
public class CommunicationLogController {

	@Autowired
	private CommunicationLogService communicationLogService;

	@PostMapping("/createDto")
	public ResponseEntity<String> createCoomunicationLogByDto(@RequestBody CommunicationLogRequestDto dto)
			throws CustomException {

		try {
			communicationLogService.createCommunicationLogByDto(dto);

			return ResponseEntity.ok().body(ResponseBodyUtil.createResponseBody(HttpStatus.CREATED.value(),
					MsgConstant.RECORDS_CREATED_SUCCESS));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@PostMapping("/createDtoWithParent")

	public ResponseEntity<String> createComunicationLogByDto(@RequestBody CommunicationLogRequestDto dto,
			@RequestBody Order parent) throws CustomException {

		try {

			communicationLogService.createCommunicationLog(dto, parent);

			return ResponseEntity.ok().body(ResponseBodyUtil.createResponseBody(HttpStatus.CREATED.value(),
					MsgConstant.RECORDS_CREATED_SUCCESS));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/getAllLogs")

	public ResponseEntity<ApiResponse> listAllLogHistory() throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					communicationLogService.listAllLogHistory()));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/getAllLogByOrderId")

	public ResponseEntity<ApiResponse> listAllLogByOrderId(@RequestParam Long orderId) throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					communicationLogService.listAllLogByOrderId(orderId)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/getAllLogBetweenDateRange")

	public ResponseEntity<ApiResponse> listAllLogByOrderIdbetween(@RequestParam Date startDate, Date endDate)
			throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					communicationLogService.listAllLogBetweenDateRange(startDate, endDate)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/getAllLogOnDate")

	public ResponseEntity<ApiResponse> listAllLogsOnDate(@RequestParam Date date) throws CustomException {

		try {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);

			// Set the time component to the beginning of the day
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			Date startDate = calendar.getTime();

			// Set the time component to the end of the day
			calendar.set(Calendar.HOUR_OF_DAY, 23);
			calendar.set(Calendar.MINUTE, 59);
			calendar.set(Calendar.SECOND, 59);
			calendar.set(Calendar.MILLISECOND, 999);
			Date endDate = calendar.getTime();

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					communicationLogService.listAllLogBetweenDateRange(startDate, endDate)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

}