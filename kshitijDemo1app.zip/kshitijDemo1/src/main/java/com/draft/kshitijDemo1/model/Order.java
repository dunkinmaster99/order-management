package com.draft.kshitijDemo1.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "ORDER_TABLE")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Order extends BaseEntity implements Serializable {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ORDER_ID", updatable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "M_ORDER_ID")
	private String orderId;

	@Column(name = "ORDER_NO")
	private String orderNumber;

	@Column(name = "NARRATION")
	private String narration;

	@Column(name = "PRIORITY")
	private String priority;

	@Column(name = "DISCOUNT")
	private BigDecimal discount;

	@Column(name = "AMOUNT")
	private BigDecimal finalAmount;

	@Column(name = "ORDER_DATE")
	private Date orderDate;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "STATUS_ID")
	private Status status;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CUSTOMER_ID")
	private Customer customer;

	@Column(name = "TALLY_STATUS")
	private char isPushedInTally;

	@OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<CommunicationLog> communicationLogs = new ArrayList<>();

	@OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<OrderProduct> orderProductsList = new ArrayList<>();

	@Column(name = "IS_DELIVERY_ADDRESS_SAME")
	private char isDeliveryAddressSame;

	@Column(name = "D_LINE1")
	private String d_AddressLine1;

	@Column(name = "D_LINE2")
	private String d_AddressLine2;

	@Column(name = "D_LINE3")
	private String d_AddressLine3;

	@Column(name = "D_LIN4")
	private String d_AddressLine4;

	@Column(name = "D_STATE")
	private String d_State;

	@Column(name = "D_COUNTRY")
	private String d_Country;

	@Column(name = "D_PINCODE")
	private Integer d_Pincode;

	@Column(name = "GST")
	private String gst;

	@PrePersist
	public void prePersist() {
		if (orderId == null) {
			LocalDateTime dateTime = LocalDateTime.now();
			String date = String.valueOf(dateTime.getDayOfMonth()).length() == 1 ? "0" + dateTime.getDayOfMonth()
					: String.valueOf(dateTime.getDayOfMonth());
			String month = String.valueOf(dateTime.getMonthValue()).length() == 1 ? "0" + dateTime.getMonthValue()
					: String.valueOf(dateTime.getMonthValue());
			String year = String.valueOf(dateTime.getYear()).substring(2, 4);
			String hour = String.valueOf(dateTime.getHour()).length() == 1 ? "0" + dateTime.getHour()
					: String.valueOf(dateTime.getHour());
			String minute = String.valueOf(dateTime.getMinute()).length() == 1 ? "0" + dateTime.getMinute()
					: String.valueOf(dateTime.getMinute());
			String second = String.valueOf(dateTime.getSecond()).length() == 1 ? "0" + dateTime.getSecond()
					: String.valueOf(dateTime.getSecond());
			orderId = "KPL" + date + month + year + hour + minute + second;
		}
	}

}