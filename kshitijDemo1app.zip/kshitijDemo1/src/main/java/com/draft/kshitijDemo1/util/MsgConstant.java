package com.draft.kshitijDemo1.util;

public class MsgConstant {

	public static final String RECORDS_CREATED_SUCCESS = "Records created successfully";

	public static final String RECORDS_NOT_CREATED_SUCCESS = "Records not created successfully";

	public static final String RECORDS_UPDATED_SUCCESS = "Records updated successfully";

	public static final String RECORDS_NOT_UPDATED_SUCCESS = "Records not updated successfully";

	public static final String RECORDS_FETCH_SUCCESS = "Records fetched successfully";

	public static final String GROUP_NOT_FOUND = "Group not found";

	public static final String RECORDS_DELETED_SUCCESS = "Records deleted successfully";

	public static final String RECORDS_NOT_FOUND = "Records not found";

	public static final String PASSWORD_EMPTY = "Password or Confirm Password cannot be empty";

	public static final String PASSWORD_NOT_MATCH = "Password and Confirm Password does not match";

	public static final String STATUS_CHANGE = "Status changed to Inactive";

}