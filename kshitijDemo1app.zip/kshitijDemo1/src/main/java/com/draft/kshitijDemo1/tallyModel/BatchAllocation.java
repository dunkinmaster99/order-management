package com.draft.kshitijDemo1.tallyModel;

import lombok.Data;

@Data

public class BatchAllocation {

	private String godownName;

	private String batchName;

	private String destinationGodownName;

	private String indentNo;

	private String orderNo;

	private String trackingNumber;

	private String dynamicCstIsCleared;

	private String amount;

	private String actualQty;

	private String billedQty;

	private String orderDueDate;

//    private List<AdditionalDetail> additionalDetails;

//    private List<VoucherComponent> voucherComponents;

//

	public BatchAllocation() {

		this.godownName = "KPL";

		this.batchName = "Primary Batch";

		this.destinationGodownName = "KPL";

		this.dynamicCstIsCleared = "No";

	}

}