package com.draft.kshitijDemo1.tallyModel;

import java.util.ArrayList;

import java.util.List;

import lombok.Data;

import lombok.NoArgsConstructor;

@Data

public class VoucherRequest {

	private String date;

	private String guid;

	private List<String> address;

	private List<String> basicBuyerAddress;

	private List<String> oldAuditEntry = new ArrayList<String>();

	private String GSTREGISTRATIONTYPE;

	private String vatDealerType;

	private String stateName;

	private String priceLevel;

	private String VoucherTypeName;

	private String narration;

	private String enteredBy;

	private String objectUpdateAction;

	private String countryOfResidence;

	private String partyGSTIN;

	private String placeOfSupply;

	private String className;

	private String partyName;

	private String partyLedgerName;

	private String reference;

	private String partyMailingName;

	private String partyPincode;

	private String consigneeGstin;

	private String consigneeMailingName;

	private String consigneePincode;

	private String consigneeStateName;

	private String voucherNumber;

	private String basicBasePartyName;

	private String persistedView;

	private String typeOfExciseVoucher;

	private String basicBuyerName;

	private String basicDueDateOfPymt;

	private String consigneeCountryName;

	private String diffActualQty;

	private String isMstFromSync;

	private String isDeleted;

	private String isSecurityOnWhenEntered;

	private String asOriginal;

	private String audited;

	private String forJobCosting;

	private String isOptional;

	private String effectiveDate;

	private String useForExcise;

	private String isForJobWorkIn;

	private String allowConsumption;

	private String useForInterest;

	private String useForGainLoss;

	private String useForGodownTransfer;

	private String useForCompound;

	private String useForServiceTax;

	private String isOnHold;

	private String isBoeNotApplicable;

	private String isGstSecSevenApplicable;

	private String isExciseVoucher;

	private String exciseTaxOverride;

	private String useForTaxUnitTransfer;

	private String ignorePosValidation;

	private String exciseOpening;

	private String useForFinalProduction;

	private String isTdsOverridden;

	private String isTcsOverridden;

	private String isTdsTcsCashVoucher;

	private String includeAdvPymtVoucher;

	private String isSubWorksContract;

	private String isVatOverridden;

	private String ignoreOrigVoucherDate;

	private String isVatPaidAtCustoms;

	private String isDeclaredToCustoms;

	private String isServiceTaxOverridden;

	private String isIsdVoucher;

	private String isExciseOverridden;

	private String isExciseSupplyVch;

	private String isGstOverridden;

	private String gstNotExported;

	private String ignoreGstInvalidation;

	private String isGstRefund;

	private String ovrdNewWayBillApplicability;

	private String isVatPrincipalAccount;

	private String ignoreEinvValidation;

	private String irnJsonExported;

	private String irnCancelled;

	private String isShippingWithinState;

	private String isOverseasTouristTrans;

	private String isDesignatedZoneParty;

	private String isCancelled;

	private String hasCashFlow;

	private String isPostDated;

	private String useTrackingNumber;

	private String isInvoice;

	private String mfgJournal;

	private String hasDiscounts;

	private String asPaySlip;

	private String isCostCentre;

	private String isStxNonRealizedVch;

	private String isExciseManufacturerOn;

	private String isBlankCheque;

	private String isVoid;

	private String orderLineStatus;

	private String vatIsAgstCancSales;

	private String vatIsPurcExempted;

	private String isVatRestaxInvoice;

	private String vatIsAssesableCalcVch;

	private String isVatDutyPaid;

	private String isDeliverySameAsConsignee;

	private String isDispatchSameAsConsignor;

	private String isDeletedVchRetained;

	private String changeVchMode;

	private String resetIrnQrCode;

	private String alterId;

	private String masterId;

	private String voucherKey;

	private String updatedDateTime;

	private List<AllInventoryList> allInventoryList;

	private LedgerEntryLast ledgerEntry1;

	private LedgerEntryLast ledgerEntry2;

	private LedgerEntryLast ledgerEntry3;

	public VoucherRequest() {

		this.oldAuditEntry.add("-1");

		this.GSTREGISTRATIONTYPE = "Regular";

		this.vatDealerType = "Regular";

		this.priceLevel = "-   Vb /Distributor";

		this.VoucherTypeName = "Sales Order";

		this.objectUpdateAction = "Create";

		this.className = "Sales Gst";

		this.persistedView = "Invoice Voucher View";

		this.persistedView = "Invoice Voucher View";

		this.typeOfExciseVoucher = "Non-Excise";

		// maybe in frontend

		this.basicDueDateOfPymt = "1 Days";

		this.diffActualQty = "No";

		this.isMstFromSync = "No";

		this.isDeleted = "No";

		this.isSecurityOnWhenEntered = "Yes";

		this.asOriginal = "No";

		this.audited = "No";

		this.forJobCosting = "No";

		this.isOptional = "No";

		this.useForExcise = "No";

		this.isForJobWorkIn = "No";

		this.allowConsumption = "No";

		this.useForInterest = "No";

		this.useForGainLoss = "No";

		this.useForGodownTransfer = "No";

		this.useForCompound = "No";

		this.useForServiceTax = "No";

		this.isOnHold = "No";

		this.isBoeNotApplicable = "No";

		this.isGstSecSevenApplicable = "No";

		this.isExciseVoucher = "No";

		this.exciseTaxOverride = "No";

		this.useForTaxUnitTransfer = "No";

		this.ignorePosValidation = "No";

		this.exciseOpening = "No";

		this.useForFinalProduction = "No";

		this.isTdsOverridden = "No";

		this.isTcsOverridden = "No";

		this.isTdsTcsCashVoucher = "No";

		this.includeAdvPymtVoucher = "No";

		this.isSubWorksContract = "No";

		this.isVatOverridden = "No";

		this.ignoreOrigVoucherDate = "No";

		this.isVatPaidAtCustoms = "No";

		this.isDeclaredToCustoms = "No";

		this.isServiceTaxOverridden = "No";

		this.isIsdVoucher = "No";

		this.isExciseOverridden = "No";

		this.isExciseSupplyVch = "No";

		this.isGstOverridden = "No";

		this.gstNotExported = "No";

		this.ignoreGstInvalidation = "No";

		this.isGstRefund = "No";

		this.ovrdNewWayBillApplicability = "No";

		this.isVatPrincipalAccount = "No";

		this.ignoreEinvValidation = "No";

		this.irnJsonExported = "No";

		this.irnCancelled = "No";

		this.isShippingWithinState = "No";

		this.isOverseasTouristTrans = "No";

		this.isDesignatedZoneParty = "No";

		this.isCancelled = "No";

		this.hasCashFlow = "No";

		this.isPostDated = "No";

		this.useTrackingNumber = "No";

		this.isInvoice = "No";

		this.mfgJournal = "No";

		this.hasDiscounts = "No";

		this.asPaySlip = "No";

		this.isCostCentre = "No";

		this.isStxNonRealizedVch = "No";

		this.isExciseManufacturerOn = "No";

		this.isBlankCheque = "No";

		this.isVoid = "No";

		this.orderLineStatus = "No";

		this.vatIsAgstCancSales = "No";

		this.vatIsPurcExempted = "No";

		this.isVatRestaxInvoice = "No";

		this.vatIsAssesableCalcVch = "No";

		this.isVatDutyPaid = "No";

		this.isDeliverySameAsConsignee = "No";

		this.isDispatchSameAsConsignor = "No";

		this.isDeletedVchRetained = "No";

		this.changeVchMode = "No";

		this.resetIrnQrCode = "No";

		this.alterId = " 557288";

		this.masterId = " 220651";

		// doubt it should beauto generated

		this.voucherKey = "193441032044584";

	}

}