package com.draft.kshitijDemo1.responseDto;

import lombok.Data;

@Data

public class OrderProductResponseDto {

	private Long id;

	// private OrderResponseDto order;

	private Long orderId;

	private String productName;

	private String category;

	private Integer quantity;

	private String properties;

	private float discount;

	private float amount;

	private String unit;

	private float rate;

	private String status;

	// Constructors, getters, and setters

}