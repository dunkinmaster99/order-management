package com.draft.kshitijDemo1.service;

import java.util.Optional;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

public class CustomAuditorAware implements AuditorAware<String> {

// @Override
// public Optional<Integer> getCurrentAuditor() {
// // TODO Auto-generated method stub
// return Optional.of(2);
// }
	@Override
	public Optional<String> getCurrentAuditor() {
		// Retrieve the currently logged-in user's ID or username
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

		if (authentication == null || !authentication.isAuthenticated()) {
			// Return an empty Optional if no user is authenticated
			return Optional.empty();
		}

		// Return the ID or username of the authenticated user
		return Optional.of(authentication.getName());
	}

}