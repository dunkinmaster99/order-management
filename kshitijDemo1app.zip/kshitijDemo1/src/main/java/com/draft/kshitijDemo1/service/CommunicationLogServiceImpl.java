package com.draft.kshitijDemo1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.draft.kshitijDemo1.convvertor.DtoToEntityConvertor;
import com.draft.kshitijDemo1.convvertor.EntityToResponseDto;
import com.draft.kshitijDemo1.model.CommunicationLog;
import com.draft.kshitijDemo1.model.Order;
import com.draft.kshitijDemo1.repository.CommunicationLogRepository;
import com.draft.kshitijDemo1.requestDto.CommunicationLogRequestDto;
import com.draft.kshitijDemo1.responseDto.CommunicationLogDto;

@Service("CommunicationLogService")
public class CommunicationLogServiceImpl implements CommunicationLogService {
	@Autowired
	private CommunicationLogRepository logRepository;
	@Autowired
	private EntityToResponseDto entityToDtoConvertor;
	@Autowired
	private DtoToEntityConvertor dtoToEntityConvertor;

	@Override
	public List<CommunicationLogDto> listAllLogHistory() {
		List<CommunicationLog> entities = logRepository.findAll();
		List<CommunicationLogDto> dtos = new ArrayList<>();

		for (CommunicationLog entity : entities) {
			CommunicationLogDto dto = entityToDtoConvertor.EntityToLogDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

	@Override
	public List<CommunicationLogDto> listAllLogByOrderId(Long orderId) {
		List<CommunicationLog> entities = logRepository.findCommunicationLogsByOrderId(orderId);
		List<CommunicationLogDto> dtos = new ArrayList<>();

		for (CommunicationLog entity : entities) {
			CommunicationLogDto dto = entityToDtoConvertor.EntityToLogDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

	@Override
	public List<CommunicationLogDto> listAllLogBetweenDateRange(Date startDate, Date endDate) {
		List<CommunicationLog> entities = logRepository.findByCreatedDateBetween(startDate, endDate);
		List<CommunicationLogDto> dtos = new ArrayList<>();

		for (CommunicationLog entity : entities) {
			CommunicationLogDto dto = entityToDtoConvertor.EntityToLogDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

	@Override
	public List<CommunicationLogDto> listAllLogsOnDate(Date date) {
		List<CommunicationLog> entities = logRepository.findByCreatedDate(date);
		List<CommunicationLogDto> dtos = new ArrayList<>();

		for (CommunicationLog entity : entities) {
			CommunicationLogDto dto = entityToDtoConvertor.EntityToLogDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

	@Override
	public void createCommunicationLogByDto(CommunicationLogRequestDto dto) {
		CommunicationLog entity = dtoToEntityConvertor.toLogEntityByDtoOnly(dto);
		logRepository.save(entity);
	}

	@Override
	public CommunicationLog createCommunicationLog(CommunicationLogRequestDto dto, Order parent) {
		CommunicationLog entity = dtoToEntityConvertor.toLogEntity(dto, parent);
		CommunicationLog savedEntity = logRepository.save(entity);
		return savedEntity;
	}

}