package com.draft.kshitijDemo1.responseDto;

import lombok.Data;

@Data

public class CustomerDto {

	private Long id;

	private String name;

	private String panNo;

	private String cstNo;

	private String voucherNo;

	private String Gstin;

	private String addressLine1;

	private String addressLine2;

	private String addressLine3;

	private String addressLine4;

	private String state;

	private String country;

	private Integer pincode;

	private char isPushedInTally;

}