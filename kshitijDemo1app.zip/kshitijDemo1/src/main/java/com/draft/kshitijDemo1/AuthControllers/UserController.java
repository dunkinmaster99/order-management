package com.draft.kshitijDemo1.AuthControllers;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.draft.kshitijDemo1.AuthService.UserService;
import com.draft.kshitijDemo1.service.CustomException;
import com.draft.kshitijDemo1.userModel.User;
import com.draft.kshitijDemo1.util.ApiResponse;
import com.draft.kshitijDemo1.util.ErrorResponse;
import com.draft.kshitijDemo1.util.MsgConstant;

import lombok.extern.slf4j.Slf4j;



@RestController
@Slf4j
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {

    @Autowired
    private UserService userService;

    @jakarta.annotation.PostConstruct
    public void initRoleAndUser() {
        userService.initRoleAndUser();
    }

    @PostMapping({"/registerNewUser"})
    public User registerNewUser(@RequestBody User user) {
        return userService.registerNewUser(user);
    }

    @GetMapping({"/forAdmin"})
    @PreAuthorize("hasRole('Admin')")
    public String forAdmin(){
        return "This URL is only accessible to the admin";
    }

    @GetMapping({"/forUser"})
    @PreAuthorize("hasRole('User')")
    public String forUser(){
        return "This URL is only accessible to the user";
    }
    
    @GetMapping("/helloWorld")
    public String helloWorld() {
    return "Hi, I am inside";
    }
    
    @GetMapping("/getAllUsers")
    public ResponseEntity<ApiResponse> getUsers() throws CustomException{
    try {
    return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(),MsgConstant.RECORDS_FETCH_SUCCESS,userService.getAllUsers()));
    }
    catch(Exception e) {
    log.error("Error occured in class :"+this.getClass().getSimpleName()+"and Method:"+new Object() {
    }.getClass().getEnclosingMethod().getName(),e);
    throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
    }
    }
    
    @GetMapping("/getAllUserCategory")
    public ResponseEntity<ApiResponse> getUserCategories() throws CustomException{
    try {
    return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(),MsgConstant.RECORDS_FETCH_SUCCESS,userService.getAllUserCategories()));
    }
    catch(Exception e) {
    log.error("Error occured in class :"+this.getClass().getSimpleName()+"and Method:"+new Object() {
    }.getClass().getEnclosingMethod().getName(),e);
    throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
    }
    }
    
    
    
    @GetMapping("/getUserById")
    public ResponseEntity<ApiResponse> getUserById(@RequestParam(value="userName") String userName) throws CustomException{
    try {
    return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(),MsgConstant.RECORDS_FETCH_SUCCESS,userService.getUserById(userName)));
    }
    catch(Exception e) {
    log.error("Error occured in class :"+this.getClass().getSimpleName()+"and Method:"+new Object() {
    }.getClass().getEnclosingMethod().getName(),e);
    throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
    }
    }
}