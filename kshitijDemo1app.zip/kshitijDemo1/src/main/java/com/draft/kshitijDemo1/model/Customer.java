package com.draft.kshitijDemo1.model;

import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "CUSTOMER")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Customer {

    @Id
    @Column(name = "CUSTOMER_ID", updatable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "NAME", nullable = false)
    private String name;

    
    
    @Column(name = "GSTIN")
    private String Gstin;
    
    @Column (name = "pan_no")
    private String panNo;
    
    @Column (name = "cst_no")
    private String cstNo;
    
    @Column (name = "voucher_no")
    private String voucherNo;
    
    @Column(name = "A_LINE1")
    private String addressLine1;  
    
    @Column(name = "A_LINE2")
    private String addressLine2;
    
    @Column(name = "A_LINE3")
    private String addressLine3;
    
    @Column(name = "A_LINE4")
    private String addressLine4;
    
    @Column(name = "STATE")
    private String state;
    
    @Column(name = "COUNTRY")
    private String country;
    
    @Column(name = "PINCODE")
    private Integer pincode;
    
    @Column(name="TALLY_STATUS")
    private char isPushedInTally;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Order> orders = new ArrayList<>();


    // Constructors, getters, and setters
    
}