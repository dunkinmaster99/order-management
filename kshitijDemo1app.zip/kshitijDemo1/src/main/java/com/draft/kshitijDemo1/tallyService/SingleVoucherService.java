package com.draft.kshitijDemo1.tallyService;

public class SingleVoucherService {

}
