package com.draft.kshitijDemo1.requestDto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.draft.kshitijDemo1.model.CommunicationLog;
import com.draft.kshitijDemo1.model.Customer;
import com.draft.kshitijDemo1.model.OrderProduct;
import com.draft.kshitijDemo1.model.Status;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Data
public class OrderRequestDto {

	private Long id;
//    private String orderId;
	private String orderNumber;
	private String narration;
	private String priority;
	// private BigDecimal discount;
	private String gst;
	private BigDecimal finalAmount;
	private Long statusId;
	private Long customerId;
	private char isPushedInTally;
	private char isDeliveryAddressSame;
	private String d_AddressLine1;
	private String d_AddressLine2;
	private String d_AddressLine3;
	private String d_AddressLine4;
	private String d_State;
	private String d_Country;
	private Integer d_Pincode;

	private Date orderDate;

	private List<OrderProductRequestDto> products;

}