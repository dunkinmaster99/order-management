package com.draft.kshitijDemo1.service;

import java.util.List;
import java.util.Optional;

import com.draft.kshitijDemo1.model.Customer;
import com.draft.kshitijDemo1.requestDto.CustomerRequestDto;
import com.draft.kshitijDemo1.responseDto.CustomerDto;
import com.draft.kshitijDemo1.responseDto.CustomerResponseDto;

public interface CustomerService {
	List<CustomerResponseDto> listAllCustomers();

	List<CustomerDto> listCustomerListOnly();

	Optional<CustomerResponseDto> getByCustomerId(Long id);

	Optional<Customer> getById(Long id);

	List<CustomerDto> listNewCustomerListNotinTally();

	void changeTallyPushedStatus(Long id) throws Exception;

	void createOrUpdateCustomer(CustomerRequestDto dto);

}