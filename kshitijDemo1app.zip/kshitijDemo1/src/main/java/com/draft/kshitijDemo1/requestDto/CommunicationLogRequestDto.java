package com.draft.kshitijDemo1.requestDto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CommunicationLogRequestDto {
	private Long id;
	private String message;
	private Long orderId;
	private Long statusId;

}