package com.draft.kshitijDemo1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.draft.kshitijDemo1.model.Status;

@Repository
public interface StatusRepository extends JpaRepository<Status, Long> {

	public Status findByValue(String string);

}
