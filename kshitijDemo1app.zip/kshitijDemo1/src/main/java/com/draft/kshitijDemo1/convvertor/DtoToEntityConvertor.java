package com.draft.kshitijDemo1.convvertor;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.draft.kshitijDemo1.model.CommunicationLog;
import com.draft.kshitijDemo1.model.Customer;
import com.draft.kshitijDemo1.model.Order;
import com.draft.kshitijDemo1.model.OrderProduct;
import com.draft.kshitijDemo1.model.Product;
import com.draft.kshitijDemo1.model.Status;
import com.draft.kshitijDemo1.repository.OrderProductRepository;
import com.draft.kshitijDemo1.requestDto.CommunicationLogRequestDto;
import com.draft.kshitijDemo1.requestDto.CustomerRequestDto;
import com.draft.kshitijDemo1.requestDto.OrderProductRequestDto;
import com.draft.kshitijDemo1.requestDto.OrderRequestDto;
import com.draft.kshitijDemo1.requestDto.ProductRequestDto;

@Component
public class DtoToEntityConvertor {
	@Autowired
	private OrderProductRepository orderProductRepo;

	public CommunicationLog toLogEntity(CommunicationLogRequestDto dto, Order parentOrder) {
		CommunicationLog logEntity = new CommunicationLog();
		Status status = new Status();
		BeanUtils.copyProperties(dto, logEntity);
		if (dto.getStatusId() != 0) {
			status.setStatusId(dto.getStatusId());
			logEntity.setStatus(status);
		}
		logEntity.setOrder(parentOrder);
		return logEntity;
	}

	public CommunicationLog toLogEntityByDtoOnly(CommunicationLogRequestDto dto) {
		CommunicationLog logEntity = new CommunicationLog();
		Status status = new Status();
		Order order = new Order();
		BeanUtils.copyProperties(dto, logEntity);
		if (dto.getStatusId() != 0) {
			status.setStatusId(dto.getStatusId());
			logEntity.setStatus(status);
		}
		if (dto.getOrderId() != 0) {
			order.setId(dto.getOrderId());
			logEntity.setOrder(order);
		}
		return logEntity;
	}

	public Customer toCustomerEntity(CustomerRequestDto dto) {
		Customer entity = new Customer();
		BeanUtils.copyProperties(dto, entity);
		return entity;
	}

	public Order toOrderEntity(OrderRequestDto dto) {
		Order entity = new Order();
		Customer customereEntity = new Customer();
		Status status = new Status();
		BeanUtils.copyProperties(dto, entity);
		if (dto.getCustomerId() != 0) {
			customereEntity.setId(dto.getCustomerId());
			entity.setCustomer(customereEntity);
		}
		if (dto.getStatusId() != 0) {
			status.setStatusId(dto.getStatusId());
			entity.setStatus(status);
		}
		return entity;
	}

	public OrderProduct toOrderProductEntity(OrderProductRequestDto dto, Order order) {
		OrderProduct orderProductEntity = new OrderProduct();
//Order orderEntity = new Order();
		Product product = new Product();
		Status status = new Status();
		BeanUtils.copyProperties(dto, orderProductEntity);
		if (dto.getProductId() != 0) {
			product.setProductId(dto.getProductId());
			orderProductEntity.setProduct(product);
		}
		if (dto.getStatus() != 0) {
			status.setStatusId(dto.getStatus());
			orderProductEntity.setStatus(status);
		}
		orderProductEntity.setOrder(order);
//orderProductEntity = orderProductRepo.save(orderProductEntity);
		return orderProductEntity;
	}

	public Product toProductEntity(ProductRequestDto dto) {
// 
		Product entity = new Product();
		BeanUtils.copyProperties(dto, entity);
		return entity;
	}

}