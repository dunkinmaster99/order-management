package com.draft.kshitijDemo1.tallyModel;

import java.util.List;

import lombok.Data;

@Data
public class AllInventoryList {
	private String stockItemName;
	private String isDeemedPositive;
	private String isLastDeemedPositive;
	private String isAutoNegate;
	private String isCustomsClearance;
	private String isTrackComponent;
	private String isTrackProduction;
	private String isPrimaryItem;
	private String isScrap;
	private String rate;
	private String discount;
	private String amount;
	private String actualQty;
	private String billedQty;
	private BatchAllocation batchAllocations;
	private AccountingAllocation accountingAllocations;
	private DutyHeadDetail dutyHeadDetails;
//    private SupplementaryDutyHeadDetail supplementaryDutyHeadDetails;
//    private TaxObjectAllocation taxObjectAllocations;

	private List<ExpenseAllocationList> expenseAllocationList;

	public AllInventoryList() {
		this.isDeemedPositive = "No";
		this.isLastDeemedPositive = "No";
		this.isAutoNegate = "No";
		this.isCustomsClearance = "No";
		this.isTrackComponent = "No";
		this.isTrackProduction = "No";
		this.isPrimaryItem = "No";
		this.isScrap = "No";
	}

}