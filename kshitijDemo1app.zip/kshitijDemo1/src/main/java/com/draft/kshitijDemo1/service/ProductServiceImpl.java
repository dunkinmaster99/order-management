package com.draft.kshitijDemo1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.draft.kshitijDemo1.convvertor.DtoToEntityConvertor;
import com.draft.kshitijDemo1.model.Product;
import com.draft.kshitijDemo1.repository.ProductRepository;
import com.draft.kshitijDemo1.requestDto.ProductRequestDto;

@Service("ProductService")
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private DtoToEntityConvertor dtoToEntityConvertor;

	@Override
	public Optional<Product> getById(Long id) {
// TODO Auto-generated method stub
		return productRepository.findById(id);
	}

	@Override
	public void createOrUpdateProduct(ProductRequestDto dto) {
// TODO Auto-generated method stub
// Product entity = new Product();
		Product entity = dtoToEntityConvertor.toProductEntity(dto);
		productRepository.save(entity);
	}

	@Override
	public List<Product> listAllProducts() {
// TODO Auto-generated method stub
		List<Product> entities = productRepository.findAll();
		return entities;
	}

	@Override
	public List<Product> listAllProductsByCategory(String categoryType) {
// TODO Auto-generated method stub
		List<Product> entities = productRepository.findByCategory(categoryType);
		return entities;
	}

}