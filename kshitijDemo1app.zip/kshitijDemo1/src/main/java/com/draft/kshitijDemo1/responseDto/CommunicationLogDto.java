package com.draft.kshitijDemo1.responseDto;

import lombok.Data;

@Data

public class CommunicationLogDto {

	private Long id;

	private String message;

	private Long orderId;

	private Long statusId;

}