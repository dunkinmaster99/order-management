package com.draft.kshitijDemo1.requestDto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class ProductRequestDto {
	private Long productId;
	private String name;
	private BigDecimal price;
	private String category;

	// getters and setters
}
