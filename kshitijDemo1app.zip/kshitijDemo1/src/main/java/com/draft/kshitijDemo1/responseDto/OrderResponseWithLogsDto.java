package com.draft.kshitijDemo1.responseDto;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

@Data
public class OrderResponseWithLogsDto {

	private Long id;
	private String orderId;
	private String orderNumber;
	private String narration;
	private String priority;
	private BigDecimal discount;
	private BigDecimal finalAmount;
	private String status;
	private String customerName;
	private char isPushedInTally;
	private List<OrderProductResponseDto> orderProducts;
	private List<CommunicationLogDto> communicationLogs;
}