package com.draft.kshitijDemo1.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.draft.kshitijDemo1.model.Order;
import com.draft.kshitijDemo1.model.Status;
import com.draft.kshitijDemo1.requestDto.OrderRequestDto;
import com.draft.kshitijDemo1.responseDto.OrderProductResponseDto;
import com.draft.kshitijDemo1.responseDto.OrderResponseDto;
import com.draft.kshitijDemo1.responseDto.OrderResponseWithLogsDto;

public interface OrderService {

	void updateOrder(OrderRequestDto dto);

	void createOrder(OrderRequestDto dto);

	void changeTallyPushedStatus(Long id) throws Exception;

	Optional<Order> getOrderEntityById(Long id);

	Optional<OrderResponseDto> getOrderResponseById(Long id);

	Optional<OrderResponseWithLogsDto> getOrderResponseWithLogById(Long id);

	List<Order> listAllOrderEntity();

	List<OrderResponseDto> listAllOrderResponse();

	List<OrderResponseDto> listNewOrdersListNotinTally();

	List<OrderResponseDto> listAllOrdersBetweenDateRange(Date startDate, Date endDate);

	List<OrderResponseDto> listAllOrdersOnDate(Date date);

	List<OrderResponseDto> listAllOrdersOfPriority(String priority);

	List<OrderResponseDto> listAllOrdersOfCustomer(Long id);

	List<OrderResponseDto> listAllOrdersByUserId(String customerId);

	List<OrderProductResponseDto> listAllOrdersByCategoryType(String categoryType);

	List<OrderProductResponseDto> listAllOrdersNotCompleted();

	List<OrderProductResponseDto> listAllOrdersNotCompletedByCategoryType(String categoryType);

	List<OrderProductResponseDto> listAllOrdersByStatusAndByCategoryType(String status, String categoryType);

	List<Status> getAllStatus();

	void setOrderStatus(Long orderId, String status);

	void setOrderProductStatus(Long orderProductId, String newStatusId);

}