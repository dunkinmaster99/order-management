package com.draft.kshitijDemo1.tallyModel;

import lombok.Data;

@Data

public class AccountingAllocation {

//hj

// private Integer oldAuditEntryIds;

	private String ledgerName;

	private String classRate;

	private String gstClass;

	private String isDeemedPositive;

	private String ledgerFromItem;

	private String removeZeroEntries;

	private String isPartyLedger;

	private String isLastDeemedPositive;

	private String isCapVatTaxAltered;

	private String isCapVatNotClaimed;

	private String amount;

	public AccountingAllocation() {

		this.ledgerName = "SALES GST";

		this.classRate = "100.00000";

		// this.gstClass = "";

		this.isDeemedPositive = "No";

		this.ledgerFromItem = "No";

		this.removeZeroEntries = "No";

		this.isPartyLedger = "No";

		this.isLastDeemedPositive = "No";

		this.isCapVatTaxAltered = "No";

		this.isCapVatNotClaimed = "No";

	}

}