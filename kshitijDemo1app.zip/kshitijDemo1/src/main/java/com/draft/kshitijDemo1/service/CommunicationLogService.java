package com.draft.kshitijDemo1.service;

import java.util.Date;

import java.util.List;

import com.draft.kshitijDemo1.model.CommunicationLog;

import com.draft.kshitijDemo1.model.Order;

import com.draft.kshitijDemo1.requestDto.CommunicationLogRequestDto;

import com.draft.kshitijDemo1.responseDto.CommunicationLogDto;

public interface CommunicationLogService {

	List<CommunicationLogDto> listAllLogByOrderId(Long orderId);

	List<CommunicationLogDto> listAllLogHistory();

	List<CommunicationLogDto> listAllLogBetweenDateRange(Date startDate, Date endDate);

	public List<CommunicationLogDto> listAllLogsOnDate(Date date);

	void createCommunicationLogByDto(CommunicationLogRequestDto dto);

	public CommunicationLog createCommunicationLog(CommunicationLogRequestDto dto, Order parent);

}