package com.draft.kshitijDemo1.tallyModel;

import lombok.Data;

@Data

public class LedgerEntryLast {

	private String roundType;

	private String ledgerName;

//only for iGst and normal rounding off

	private String methodType;

	private String isDeemedPositive;

	private String ledgerFromItem;

	private String removeZeroEntries;

	private String isPartyLedger;

	private String isLastDeemedPositive;

	private String isCapVatTaxAltered;

	private String isCapVatNotClaimed;

	// for normal rounding off only, 3rd

	private String roundLimit;

	private long amount;

	// only forigst and normal rounding off

	private long vatExpAmount;

	public LedgerEntryLast() {

		this.isCapVatTaxAltered = "NO";

		this.isCapVatNotClaimed = "NO";

	}

}