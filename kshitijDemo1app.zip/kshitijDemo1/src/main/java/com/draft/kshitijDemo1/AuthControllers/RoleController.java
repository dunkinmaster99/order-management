package com.draft.kshitijDemo1.AuthControllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.draft.kshitijDemo1.AuthService.RoleService;
import com.draft.kshitijDemo1.controller.CustomerController;
import com.draft.kshitijDemo1.service.CustomException;
import com.draft.kshitijDemo1.userModel.Role;
import com.draft.kshitijDemo1.util.ApiResponse;
import com.draft.kshitijDemo1.util.ErrorResponse;
import com.draft.kshitijDemo1.util.MsgConstant;

import lombok.extern.slf4j.Slf4j;


@RestController
@Slf4j
@CrossOrigin(origins = "http://localhost:4200/")
public class RoleController {

    @Autowired
    private RoleService roleService;
    

    @PostMapping({"/createNewRole"})
    public Role createNewRole(@RequestBody Role role) {
        return roleService.createNewRole(role);
    }
    
    @GetMapping("/getUserRoles")
    public ResponseEntity<ApiResponse> getRoles() throws CustomException{
    try {
    return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(),MsgConstant.RECORDS_FETCH_SUCCESS,roleService.getRoles()));
    }
    catch(Exception e) {
    log.error("Error occured in class :"+this.getClass().getSimpleName()+"and Method:"+new Object() {
    }.getClass().getEnclosingMethod().getName(),e);
    throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
    }
    }
    
}