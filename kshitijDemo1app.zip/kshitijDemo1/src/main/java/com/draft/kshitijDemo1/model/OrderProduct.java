package com.draft.kshitijDemo1.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "ORDER_PRODUCTS")
@AllArgsConstructor
@NoArgsConstructor
public class OrderProduct extends BaseEntity {

	@Id
	@Column(name = "ORDER_PRODUCTS_ID", updatable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@ManyToOne
	@JoinColumn(name = "ORDER_ID")
	private Order order;

	@ManyToOne
	@JoinColumn(name = "PRODUCT_ID", referencedColumnName = "id")
	private Product product;
	@Column(name = "Properties")
	private String properties;

	@Column(name = "Discount")
	private float discount;
	@Column(name = "Amount")
	private float amount;

	@Column(name = "QUANTITY")
	private Integer quantity;
	@Column(name = "UNIT")
	private String unit;

	@Column(name = "RATE")
	private float rate;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "STATUS_ID")
	private Status status;

	// private String status;

// getters and setters
}