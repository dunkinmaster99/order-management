package com.draft.kshitijDemo1.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.draft.kshitijDemo1.model.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

	@Query(value = "Select * from order_table where customer_id=?1", nativeQuery = true)
	List<Order> findOrdersByCustomerId(Long customerId);

	@Query(value = "SELECT * FROM order_table WHERE tally_status = '0'", nativeQuery = true)
	List<Order> findOrdersWithTallyStatusZero();

	List<Order> findByCreatedDateBetween(Date startDate, Date endDate);

	@Query(value = "SELECT * FROM order_table WHERE created_date = :date", nativeQuery = true)
	List<Order> findByCreatedDate(@Param("date") Date date);

	List<Order> findByPriority(String priority);

	@Query("SELECT entity FROM Order entity where entity.createdBy = :customerId")
	List<Order> findByCustomerId(@Param("customerId") String customerId);

}