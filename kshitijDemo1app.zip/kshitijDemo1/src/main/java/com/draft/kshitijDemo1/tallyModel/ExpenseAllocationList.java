package com.draft.kshitijDemo1.tallyModel;

import lombok.Data;

@Data

public class ExpenseAllocationList {

	private String ledgerName;

}