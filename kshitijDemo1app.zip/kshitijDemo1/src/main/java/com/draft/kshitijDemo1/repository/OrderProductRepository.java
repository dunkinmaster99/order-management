package com.draft.kshitijDemo1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.draft.kshitijDemo1.model.Order;
import com.draft.kshitijDemo1.model.OrderProduct;

@Repository
public interface OrderProductRepository extends JpaRepository<OrderProduct, Long> {

	@Query("SELECT entity FROM OrderProduct entity where entity.order.id = :orderId")
	List<OrderProduct> findOrderProductsByOrderId(Long orderId);

	@Query("SELECT entity FROM OrderProduct entity where entity.product.category = :categoryType AND entity.status.value != 'Completed'")
	List<OrderProduct> findByCategoryType(@Param("categoryType") String categoryType);

	@Query("SELECT entity FROM OrderProduct entity where entity.status.value != 'Completed'")
	List<OrderProduct> findAllNotCompleted();

	@Query("SELECT entity FROM OrderProduct entity where entity.status.value != 'Completed' AND entity.product.category = :categoryType")
	List<OrderProduct> findAllNotCompletedAndCategoryType(@Param("categoryType") String categoryType);

	@Query("SELECT entity FROM OrderProduct entity where entity.status.value != :status AND entity.product.category = :categoryType")
	List<OrderProduct> findAllByStatusAndCategoryType(@Param("status") String status,
			@Param("categoryType") String categoryType);

}