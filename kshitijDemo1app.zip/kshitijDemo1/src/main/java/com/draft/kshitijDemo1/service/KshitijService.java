package com.draft.kshitijDemo1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.draft.kshitijDemo1.model.Customer;
import com.draft.kshitijDemo1.repository.CommunicationLogRepository;
import com.draft.kshitijDemo1.repository.CustomerRepository;
import com.draft.kshitijDemo1.repository.OrderRepository;

import jakarta.persistence.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class KshitijService {
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private CommunicationLogRepository communicationLogRepository;
	private final String RECEIVING_SERVICE_URL = "http://localhost:8080/tally/receive";

	@Autowired
	private RestTemplate restTemplate;

	public String sendData(String data) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> request = new HttpEntity<>(data, headers);
		ResponseEntity<String> response = restTemplate.postForEntity(RECEIVING_SERVICE_URL, request, String.class);
		// handle the response
		return response.getBody();
	}

	public List<Customer> getAllCustomers() {
		return customerRepository.findAll();
	}

	public Customer getCustomerById(Long id) throws Exception {
		Optional<Customer> customer = customerRepository.findById(id);
		if (customer.isPresent()) {
			return customer.get();
		} else {
			throw new Exception("Customer Doesn't exist");
		}
	}

	public Customer createCustomer(Customer customer) throws Exception {
		if (customer.getId() == null)
			return customerRepository.save(customer);
		else
			throw new Exception("Customer cannot be added");
	}

	public Customer updateCustomer(Customer customer) {
		Customer c1 = customerRepository.findById(customer.getId())
				.orElseThrow(() -> new EntityNotFoundException("Customer not found "));
		return customerRepository.save(c1);
	}

	public void deleteCustomer(Long id) {
		Customer customer = customerRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Customer not found"));
		customerRepository.delete(customer);
	}
//

}