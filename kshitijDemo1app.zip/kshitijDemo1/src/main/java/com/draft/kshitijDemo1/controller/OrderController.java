package com.draft.kshitijDemo1.controller;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.draft.kshitijDemo1.requestDto.OrderRequestDto;
import com.draft.kshitijDemo1.service.CustomException;
import com.draft.kshitijDemo1.service.OrderService;
import com.draft.kshitijDemo1.util.ApiResponse;
import com.draft.kshitijDemo1.util.ErrorResponse;
import com.draft.kshitijDemo1.util.MsgConstant;
import com.draft.kshitijDemo1.util.ResponseBodyUtil;

import lombok.extern.slf4j.Slf4j;

@RequestMapping("Order")
@Slf4j
@RestController
@CrossOrigin(origins = "http://localhost:4200/")
public class OrderController {

	@Autowired
	private OrderService orderService;

	@PostMapping("/createOrder")
	public ResponseEntity<String> createOrder(@RequestBody OrderRequestDto dto) throws CustomException {

		try {
			System.out.println("Im here");
			orderService.createOrder(dto);
			return ResponseEntity.ok().body(ResponseBodyUtil.createResponseBody(HttpStatus.CREATED.value(),
					MsgConstant.RECORDS_CREATED_SUCCESS));

		}

		catch (Exception e) {
			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@PostMapping("/updateOrder")

	public ResponseEntity<String> updateOrder(@RequestBody OrderRequestDto dto) throws CustomException {

		try {

			orderService.updateOrder(dto);

			return ResponseEntity.ok().body(ResponseBodyUtil.createResponseBody(HttpStatus.CREATED.value(),
					MsgConstant.RECORDS_CREATED_SUCCESS));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/listAllOrderEntity")

	public ResponseEntity<ApiResponse> listAllOrderEntity() throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listAllOrderEntity()));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/listAllOrderResponse")

	public ResponseEntity<ApiResponse> listAllOrderResponse() throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listAllOrderResponse()));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/listNewOrdersListNotInTally")

	public ResponseEntity<ApiResponse> listNewOrdersListNotInTally() throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listNewOrdersListNotinTally()));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/listAllOrdersBetweenDateRange")

	public ResponseEntity<ApiResponse> listAllOrdersBetweenDateRange(@RequestParam Date startDate, Date endDate)
			throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listAllOrdersBetweenDateRange(startDate, endDate)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/listAllOrdersOnRange")

	public ResponseEntity<ApiResponse> listAllOrdersOnRange(@RequestParam Date date) throws CustomException {

		try {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);

			// Set the time component to the beginning of the day
			calendar.set(Calendar.HOUR_OF_DAY, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			calendar.set(Calendar.MILLISECOND, 0);
			Date startDate = calendar.getTime();

			// Set the time component to the end of the day
			calendar.set(Calendar.HOUR_OF_DAY, 23);
			calendar.set(Calendar.MINUTE, 59);
			calendar.set(Calendar.SECOND, 59);
			calendar.set(Calendar.MILLISECOND, 999);
			Date endDate = calendar.getTime();

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listAllOrdersBetweenDateRange(startDate, endDate)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/listAllOrdersOfPriority")

	public ResponseEntity<ApiResponse> listAllOrdersOfPriority(@RequestParam String priority) throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listAllOrdersOfPriority(priority)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/listAllOrdersOfCustomer")

	public ResponseEntity<ApiResponse> listAllOrdersOfCustomer(@RequestParam Long id) throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listAllOrdersOfCustomer(id)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/getOrderEntityById")

	public ResponseEntity<ApiResponse> getOrderEntityById(@RequestParam Long id) throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.getOrderEntityById(id)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/getOrderResponseById")
	public ResponseEntity<ApiResponse> getOrderResponseById(@RequestParam Long id) throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.getOrderResponseById(id)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/getOrderResponseWithLogById")
	public ResponseEntity<ApiResponse> getOrderResponseWithLogById(@RequestParam Long id) throws CustomException {
		try {
			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.getOrderResponseWithLogById(id)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@PostMapping("/changeTallyPushedStatus")
	public ResponseEntity<String> changeTallyPushedStatus(@RequestParam Long id) throws CustomException {
		try {

			orderService.changeTallyPushedStatus(id);

			return ResponseEntity.ok().body(ResponseBodyUtil.createResponseBody(HttpStatus.CREATED.value(),
					MsgConstant.RECORDS_CREATED_SUCCESS));
		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}
	}

	@GetMapping("/setOrderProductStatus")
	public ResponseEntity<ApiResponse> setOrderProductStatus(@RequestParam Long orderId, @RequestParam String status)
			throws CustomException {
		try {
			orderService.setOrderProductStatus(orderId, status);
			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS));
		} catch (Exception e) {
			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
		}

	}

	@GetMapping("/getOrderByCustomerId")
	public ResponseEntity<ApiResponse> getOrderByCustomerId(@RequestParam String customerId) throws CustomException {
		try {
			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listAllOrdersByUserId(customerId)));
		} catch (Exception e) {
			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
		}

	}

	@GetMapping("/getOrderByCategoryType")
	public ResponseEntity<ApiResponse> getOrderByCategoryType(@RequestParam String categoryType)
			throws CustomException {
		try {
			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listAllOrdersByCategoryType(categoryType)));
		} catch (Exception e) {
			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
		}

	}

	@GetMapping("/listAllOrderProductsNotCompleted")
	public ResponseEntity<ApiResponse> listAllOrderProductssNotCompleted() throws CustomException {
		try {
			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listAllOrdersNotCompleted()));
		} catch (Exception e) {
			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
		}

	}

	@GetMapping("/listAllOrdersNotCompletedByCategoryType")
	public ResponseEntity<ApiResponse> listAllOrdersNotCompletedByCategoryType(@RequestParam String categoryType)
			throws CustomException {
		try {
			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listAllOrdersNotCompletedByCategoryType(categoryType)));
		} catch (Exception e) {
			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
		}

	}

	@GetMapping("/listAllOrdersByStatusAndByCategoryType")
	public ResponseEntity<ApiResponse> listAllOrdersByStatusAndByCategoryType(@RequestParam String status,
			@RequestParam String categoryType) throws CustomException {
		try {
			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.listAllOrdersByStatusAndByCategoryType(status, categoryType)));
		} catch (Exception e) {
			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
		}

	}

	@GetMapping("getAllStatus")
	public ResponseEntity<ApiResponse> getAllStatusList() throws CustomException {
		try {
			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					orderService.getAllStatus()));
		} catch (Exception e) {
			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);
		}

	}

}