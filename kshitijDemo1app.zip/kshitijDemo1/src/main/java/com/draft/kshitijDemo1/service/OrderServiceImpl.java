package com.draft.kshitijDemo1.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.draft.kshitijDemo1.convvertor.DtoToEntityConvertor;
import com.draft.kshitijDemo1.convvertor.EntityToResponseDto;
import com.draft.kshitijDemo1.model.CommunicationLog;
import com.draft.kshitijDemo1.model.Customer;
import com.draft.kshitijDemo1.model.Order;
import com.draft.kshitijDemo1.model.OrderProduct;
import com.draft.kshitijDemo1.model.Status;
import com.draft.kshitijDemo1.repository.CommunicationLogRepository;
import com.draft.kshitijDemo1.repository.OrderProductRepository;
import com.draft.kshitijDemo1.repository.OrderRepository;
import com.draft.kshitijDemo1.repository.StatusRepository;
import com.draft.kshitijDemo1.requestDto.CommunicationLogRequestDto;
import com.draft.kshitijDemo1.requestDto.OrderProductRequestDto;
import com.draft.kshitijDemo1.requestDto.OrderRequestDto;
import com.draft.kshitijDemo1.responseDto.OrderProductResponseDto;
import com.draft.kshitijDemo1.responseDto.OrderResponseDto;
import com.draft.kshitijDemo1.responseDto.OrderResponseWithLogsDto;

import jakarta.persistence.*;

@Service("OrderService")
@Transactional
public class OrderServiceImpl implements OrderService {
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private StatusRepository statusRepository;
	@Autowired
	private EntityToResponseDto entityToDtoConvertor;
	@Autowired
	private DtoToEntityConvertor dtoToEntityConvertor;
	@Autowired
	private CommunicationLogServiceImpl logService;
	@Autowired
	private OrderProductRepository orderProductRepo;
	@Autowired
	private CommunicationLogRepository logRepository;

	@Override
	public void createOrder(OrderRequestDto dto) {
		Order entity = dtoToEntityConvertor.toOrderEntity(dto);
//entity = orderRepository.save(entity);
		List<OrderProduct> orderProductList = new ArrayList<OrderProduct>();
		for (OrderProductRequestDto orderProductDto : dto.getProducts()) {
			OrderProduct orderProductEntity = new OrderProduct();
			orderProductEntity = dtoToEntityConvertor.toOrderProductEntity(orderProductDto, entity);
			Status status = statusRepository.findByValue("Pending");
			status.setStatusId(orderProductDto.getStatus());
			orderProductEntity.setStatus(status);
			System.out.println("my product list " + orderProductEntity);
// orderProductRepo.save(orderProductEntity);
			orderProductList.add(orderProductEntity);
		}
		entity.setOrderProductsList(orderProductList);
		System.out.println("reached till here");
		System.out.println("reached till " + entity);
		entity = orderRepository.save(entity);
		CommunicationLog log = new CommunicationLog((long) 0, "Order Created successfully", entity, entity.getStatus());
		List<CommunicationLog> logList = new ArrayList<CommunicationLog>();
		log = logRepository.save(log);
		System.out.println(log);
		logList.add(log);
		System.out.println(logList);
		entity.setCommunicationLogs(logList);
		entity = orderRepository.save(entity);
		System.out.println(entity);
	}

	@Override
	public void updateOrder(OrderRequestDto dto) {
		Order entity = new Order();
		entity = dtoToEntityConvertor.toOrderEntity(dto);
		List<OrderProduct> orderProductList = new ArrayList<OrderProduct>();
		for (OrderProductRequestDto orderProductDto : dto.getProducts()) {
			OrderProduct orderProductEntity = dtoToEntityConvertor.toOrderProductEntity(orderProductDto, entity);
			orderProductList.add(orderProductEntity);
		}
		entity.setOrderProductsList(orderProductList);
		CommunicationLog log = new CommunicationLog();
		List<CommunicationLog> logList = logRepository.findCommunicationLogsByOrderId(entity.getId());
		CommunicationLogRequestDto logDto = new CommunicationLogRequestDto((long) 0, "Order Updated successfully",
				entity.getId(), entity.getStatus().getStatusId());
		log = logService.createCommunicationLog(logDto, entity);
		logList.add(log);
		entity.setCommunicationLogs(logList);
		orderRepository.save(entity);
	}

//delete order pending
	@Override
	public Optional<Order> getOrderEntityById(Long id) {
		return orderRepository.findById(id);
	}

	@Override
	public Optional<OrderResponseDto> getOrderResponseById(Long id) {
		Optional<Order> entity = orderRepository.findById(id);
		if (entity.isPresent()) {
			OrderResponseDto dto = entityToDtoConvertor.EntityToOrderDto(entity.get());
			return Optional.of(dto);
		}
		return Optional.empty();
	}

	@Override
	public Optional<OrderResponseWithLogsDto> getOrderResponseWithLogById(Long id) {
		Optional<Order> entity = orderRepository.findById(id);
		if (entity.isPresent()) {
			OrderResponseWithLogsDto dto = entityToDtoConvertor.EntityToOrderWithLogs(entity.get());
			return Optional.of(dto);
		}
		return Optional.empty();
	}

	@Override
	public List<Order> listAllOrderEntity() {
		List<Order> orderList = orderRepository.findAll();
		return orderList;
	}

	@Override
	public List<OrderResponseDto> listAllOrderResponse() {
		List<Order> entities = orderRepository.findAll();
		List<OrderResponseDto> dtoList = new ArrayList<OrderResponseDto>();
		for (Order entity : entities) {
			OrderResponseDto dto = entityToDtoConvertor.EntityToOrderDto(entity);
			dtoList.add(dto);
		}
		return dtoList;
	}

	@Override
	public List<OrderResponseDto> listNewOrdersListNotinTally() {
// TODO Auto-generated method stub
		List<Order> entities = orderRepository.findOrdersWithTallyStatusZero();
		List<OrderResponseDto> dtos = new ArrayList<>();

		for (Order entity : entities) {
			OrderResponseDto dto = entityToDtoConvertor.EntityToOrderDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

	@Override
	public List<OrderResponseDto> listAllOrdersBetweenDateRange(Date startDate, Date endDate) {
		List<Order> entities = orderRepository.findByCreatedDateBetween(startDate, endDate);
		List<OrderResponseDto> dtos = new ArrayList<>();

		for (Order entity : entities) {
			OrderResponseDto dto = entityToDtoConvertor.EntityToOrderDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

	@Override
	public List<OrderResponseDto> listAllOrdersOnDate(Date date) {
		List<Order> entities = orderRepository.findByCreatedDate(date);
		List<OrderResponseDto> dtos = new ArrayList<>();

		for (Order entity : entities) {
			OrderResponseDto dto = entityToDtoConvertor.EntityToOrderDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

	@Override
	public List<OrderResponseDto> listAllOrdersOfPriority(String priority) {
		List<Order> entities = orderRepository.findByPriority(priority);
		List<OrderResponseDto> dtos = new ArrayList<>();

		for (Order entity : entities) {
			OrderResponseDto dto = entityToDtoConvertor.EntityToOrderDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

	@Override
	public List<OrderResponseDto> listAllOrdersOfCustomer(Long id) {
		List<Order> entities = orderRepository.findOrdersByCustomerId(id);
		List<OrderResponseDto> dtos = new ArrayList<>();

		for (Order entity : entities) {
			OrderResponseDto dto = entityToDtoConvertor.EntityToOrderDto(entity);
			dtos.add(dto);
		}

		return dtos;
	}

	@Override
	public void setOrderStatus(Long orderId, String status) {
		Status statusEntity = statusRepository.findByValue(status);
		Order order = orderRepository.findById(orderId)
				.orElseThrow(() -> new EntityNotFoundException("Order not found"));

		order.setStatus(statusEntity);
		orderRepository.save(order);
	}

	@Override
	public void setOrderProductStatus(Long orderProductId, String newStatusId) {
		Status status = statusRepository.findByValue(newStatusId);
		OrderProduct orderProduct = orderProductRepo.findById(orderProductId)
				.orElseThrow(() -> new EntityNotFoundException("OrderProduct not found"));

		orderProduct.setStatus(status);
		orderProductRepo.save(orderProduct);
	}

	@Override
	public void changeTallyPushedStatus(Long id) throws Exception {
// TODO Auto-generated method stub
		Optional<Order> entity = orderRepository.findById(id);
		if (entity.isPresent()) {
			entity.get().setIsPushedInTally('1');
			orderRepository.save(entity.get());
		} else {
			throw new Exception("Order not found");
		}
	}

	@Override
	public List<OrderResponseDto> listAllOrdersByUserId(String customerId) {
		List<Order> entities = orderRepository.findByCustomerId(customerId);
		List<OrderResponseDto> dtoList = new ArrayList<OrderResponseDto>();
		for (Order entity : entities) {
			OrderResponseDto dto = entityToDtoConvertor.EntityToOrderDto(entity);
			dtoList.add(dto);
		}
		return dtoList;
	}

	@Override
	public List<OrderProductResponseDto> listAllOrdersByCategoryType(String categoryType) {
// TODO Auto-generated method stub
		List<OrderProduct> entities = orderProductRepo.findByCategoryType(categoryType);
		List<OrderProductResponseDto> dtoList = new ArrayList<OrderProductResponseDto>();
		for (OrderProduct entity : entities) {
			OrderProductResponseDto dto = entityToDtoConvertor.EntityToOrderProductDto(entity);
			dtoList.add(dto);
		}
		return dtoList;
	}

	@Override
	public List<OrderProductResponseDto> listAllOrdersNotCompleted() {
// TODO Auto-generated method stub
		List<OrderProduct> entities = orderProductRepo.findAllNotCompleted();
		List<OrderProductResponseDto> dtoList = new ArrayList<OrderProductResponseDto>();
		for (OrderProduct entity : entities) {
			OrderProductResponseDto dto = entityToDtoConvertor.EntityToOrderProductDto(entity);
			dtoList.add(dto);
		}
		return dtoList;
	}

	@Override
	public List<OrderProductResponseDto> listAllOrdersNotCompletedByCategoryType(String categoryType) {
// TODO Auto-generated method stub
		List<OrderProduct> entities = orderProductRepo.findAllNotCompletedAndCategoryType(categoryType);
		List<OrderProductResponseDto> dtoList = new ArrayList<OrderProductResponseDto>();
		for (OrderProduct entity : entities) {
			OrderProductResponseDto dto = entityToDtoConvertor.EntityToOrderProductDto(entity);
			dtoList.add(dto);
		}
		return dtoList;
	}

	@Override
	public List<OrderProductResponseDto> listAllOrdersByStatusAndByCategoryType(String status, String categoryType) {
// TODO Auto-generated method stub
		List<OrderProduct> entities = orderProductRepo.findAllByStatusAndCategoryType(status, categoryType);
		List<OrderProductResponseDto> dtoList = new ArrayList<OrderProductResponseDto>();
		for (OrderProduct entity : entities) {
			OrderProductResponseDto dto = entityToDtoConvertor.EntityToOrderProductDto(entity);
			dtoList.add(dto);
		}
		return dtoList;
	}

	@Override
	public List<Status> getAllStatus() {
// TODO Auto-generated method stub
		List<Status> entities = statusRepository.findAll();
		return entities;
	}

}