package com.draft.kshitijDemo1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.draft.kshitijDemo1.requestDto.ProductRequestDto;
import com.draft.kshitijDemo1.service.CustomException;
import com.draft.kshitijDemo1.service.ProductService;
import com.draft.kshitijDemo1.util.ApiResponse;
import com.draft.kshitijDemo1.util.ErrorResponse;
import com.draft.kshitijDemo1.util.MsgConstant;
import com.draft.kshitijDemo1.util.ResponseBodyUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/product")
@CrossOrigin(origins = "http://localhost:4200/")
public class ProductController {

	@Autowired
	private ProductService productService;

	@PostMapping("/create")

	public ResponseEntity<String> createOrUpdateProduct(@RequestBody ProductRequestDto dto) throws CustomException {

		try {

			productService.createOrUpdateProduct(dto);

			return ResponseEntity.ok().body(ResponseBodyUtil.createResponseBody(HttpStatus.CREATED.value(),
					MsgConstant.RECORDS_CREATED_SUCCESS));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/getAllProducts")

	public ResponseEntity<ApiResponse> listAllProducts() throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					productService.listAllProducts()));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/getById")

	public ResponseEntity<ApiResponse> getById(@RequestParam Long id) throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					productService.getById(id)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

	@GetMapping("/listAllProductsByCategory")

	public ResponseEntity<ApiResponse> getById(@RequestParam String categoryType) throws CustomException {

		try {

			return ResponseEntity.ok().body(new ApiResponse(HttpStatus.OK.value(), MsgConstant.RECORDS_FETCH_SUCCESS,
					productService.listAllProductsByCategory(categoryType)));

		}

		catch (Exception e) {

			log.error("Error occured in class :" + this.getClass().getSimpleName() + "and Method:" + new Object() {

			}.getClass().getEnclosingMethod().getName(), e);

			throw new CustomException(ErrorResponse.UNKNOWN_ERROR_OCCURED);

		}

	}

}
