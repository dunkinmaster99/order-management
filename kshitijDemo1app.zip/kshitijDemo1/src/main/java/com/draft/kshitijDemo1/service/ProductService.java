package com.draft.kshitijDemo1.service;

import java.util.List;
import java.util.Optional;

import com.draft.kshitijDemo1.model.Product;
import com.draft.kshitijDemo1.requestDto.ProductRequestDto;

public interface ProductService {
	public Optional<Product> getById(Long id);

	public void createOrUpdateProduct(ProductRequestDto dto);

	public List<Product> listAllProducts();

	public List<Product> listAllProductsByCategory(String categoryType);

}