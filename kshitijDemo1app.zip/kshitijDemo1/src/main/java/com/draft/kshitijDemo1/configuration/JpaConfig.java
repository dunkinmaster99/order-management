package com.draft.kshitijDemo1.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
//
//import com.draft.kshitijDemo1.service.AuditorAwareImpl;
//
//@Configuration
//@EnableJpaAuditing(auditorAwareRef = "auditorAware")
public class JpaConfig {

    // Other configuration code

// @Bean
// public AuditorAware<Integer> auditorAware() {
//
// /*
// * if you are using spring security, you can get the currently logged username
// * with following code segment.
// * SecurityContextHolder.getContext().getAuthentication().getName()
// */
// 
// return new AuditorAwareImpl();
// }

    // Other beans and configuration code
}